#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <cpgplot.h>
#include <aris.h>

#define ATM_SECTION   10
#define CNTR_SECTION  30
#define NAME_SECTION  40

/****
#define __DEBUG__
****/


int  ps_model_out(char *, char [][40], int , char *);


int  phase_screen_check(int NMTRX, struct phase_screen_parameter wvc,
                        float  *cursor_pos, int TV_SWT, int *pgid)
{
  int    i, j, I, NOD, idum;
  int    NX, NY;
  int    nx=0, ny=0;
  int    *IX=NULL, *IY=NULL;
  int    corner_position[2][2];
  int    COUNT_NOD;
  int    CONT_SWT_S, CONT_SWT_E;
  double *DS;
  double *seed_dist, seed_end[2];
  float  *DIST;
  float  dmin=0.0, dmax=0.0;
  float  pmin, pmax, noise, err_x, err_y, delta_x=0.0, delta_y=0.0;
  float  *s_x_cnt=NULL, *s_y_cnt=NULL, *s_x_w=NULL, *s_y_w=NULL;
  float  pitch = 0.03;
  float  plot_size_y=0.0;
  double lftmp;

  FILE   *ifp, *ofp;
  float  bttn_box[60][4];
  char   string[100];
  char   param_char[20][40];
  char   fname[40];
  char   ps_model_prm[100];
  char   data_file[100];

  int    PROC_SWT, DISP_SWT;
  double ps_param[20];

  float  tr[6];
  float  pgsvpxmin=0.0, pgsvpxmax=0.0, pgsvpymin=0.0, pgsvpymax=0.0;
  float  *m_dist;
  int    n_bandle=0;
  int    N128=128;
  int    NSCREEN, nscrn, NPLOT=0;
  float  box1=0.01, box2=0.99, box3=0.09, box4=0.62;
  float  plot_space=0.037;

/*
----------------------
*/

  sprintf(ps_model_prm, "aris_input/ps_model.prm");

/*
---------------------- Atmospheric Turbulence 2D
*/

  ps_param[0]  = wvc.H_d;
  ps_param[1]  = vlen2(wvc.v);
  ps_param[2]  = 180.0 / dpi * atan2(wvc.v[1], wvc.v[0]);
  ps_param[3]  = wvc.i_scale[0];
  ps_param[4]  = wvc.o_scale[0];
  ps_param[5]  = wvc.i_expon;
  ps_param[6]  = wvc.o_expon;
  ps_param[7]  = wvc.pixel;
  ps_param[8]  = 1024.0;
  ps_param[9]  = 1024.0;
  ps_param[11] = 100.0;
  ps_param[12] = 1.5;
  ps_param[10] = ps_param[12] * 0.02 / pow(ps_param[11], 0.5*ps_param[5]);

  for (i=0; i<13; i++) {
    sprintf(param_char[i], "%lf", ps_param[i]);
  }
  DISP_SWT = OFF;
  sprintf(fname, "screen.dat");

  if ((ifp = fopen(ps_model_prm, "r")) != NULL) {
    while (1) {
      if (fgets(string, sizeof(string), ifp) == NULL) {
        break;
      } else {
        string[strlen(string)-1] = '\0';
      }
      if (strncmp(string, "SCREEN HEIGHT       ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[0]);
        sscanf(string+20, "%lf", &ps_param[0]);
      } else if (strncmp(string, "WIND VELOCITY       ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[1]);
        sscanf(string+20, "%lf", &ps_param[1]);
      } else if (strncmp(string, "POSITION ANGLE      ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[2]);
        sscanf(string+20, "%lf", &ps_param[2]);
      } else if (strncmp(string, "INNER SCALE LENGTH  ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[3]);
        sscanf(string+20, "%lf", &ps_param[3]);
      } else if (strncmp(string, "OUTER SCALE LENGTH  ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[4]);
        sscanf(string+20, "%lf", &ps_param[4]);
      } else if (strncmp(string, "INNER EXPONENT      ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[5]);
        sscanf(string+20, "%lf", &ps_param[5]);
      } else if (strncmp(string, "OUTER EXPONENT      ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[6]);
        sscanf(string+20, "%lf", &ps_param[6]);
      } else if (strncmp(string, "PIXEL SIZE          ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[7]);
        sscanf(string+20, "%lf", &ps_param[7]);
      } else if (strncmp(string, "SCREEN WIDTH (X)    ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[8]);
        sscanf(string+20, "%lf", &ps_param[8]);
      } else if (strncmp(string, "SCREEN WIDTH (Y)    ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[9]);
        sscanf(string+20, "%lf", &ps_param[9]);
      } else if (strncmp(string, "RMS VALUE           ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[10]);
        sscanf(string+20, "%lf", &ps_param[10]);
      } else if (strncmp(string, "BASELINE OF THE RMS ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[11]);
        sscanf(string+20, "%lf", &ps_param[11]);
      } else if (strncmp(string, "BIAS                ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[12]);
        sscanf(string+20, "%lf", &ps_param[12]);
      } else if (strncmp(string, "DISPLAY SWITCH      ", 20) == 0) {
        sscanf(string+20, "%d",  &DISP_SWT);
      } else if (strncmp(string, "SAVE FILE NAME      ", 20) == 0) {
        sscanf(string+20, "%s", fname);
      }
    }
    fclose (ifp);
  }

/*
----------------------
*/

  if (TV_SWT == ON) {
    cpgslct(pgid[0]);
    cpgpap(1.5*pgpap_prm, 1.0);
    cpgsvp(0.0, 1.0, 0.0, 1.0);
    cpgswin(0.0, 1.0, 0.0, 1.0);
    cpgsch(0.65);

    cpgsci(0);
    cpgrect(0.0, 1.0, 0.0, 1.0);
    cpgsci(1);

    for (i=0; i<13; i++) {
      I = ATM_SECTION + i;
      bttn_box[I][0] = 0.21 + 0.50 * (float)(i/7);
      bttn_box[I][1] = 0.44 + 0.50 * (float)(i/7);
      bttn_box[I][2] = 0.94 - 0.05*(float)(i%7);
      bttn_box[I][3] = bttn_box[I][2] + pitch;

      cpgsci(1);
      if (i == 0) {
        sprintf(string, "Screen Height [m]");
      } else if (i == 1) {
        sprintf(string, "Wind Velocity [m/s]");
      } else if (i == 2) {
        sprintf(string, "Position Angle [deg]");
      } else if (i == 3) {
        sprintf(string, "Inner Scale [m]");
      } else if (i == 4) {
        sprintf(string, "Outer Scale [m]");
      } else if (i == 5) {
        sprintf(string, "Inner Exponent");
      } else if (i == 6) {
        sprintf(string, "Outer Exponent");
      } else if (i == 7) {
        sprintf(string, "Pixel Size [m]");
      } else if (i == 8) {
        sprintf(string, "Width (x) [m]");
      } else if (i == 9) {
        sprintf(string, "Width (y) [m] (x \\(2244) y)");
      } else if (i == 10) {
        sprintf(string, "RMS Value");
      } else if (i == 11) {
        sprintf(string, "Baseline Length [m]");
      } else if (i == 12) {
        sprintf(string, "BIAS");
      }
      cpgtext(bttn_box[I][0]-0.19,
              0.6*bttn_box[I][2]+0.4*bttn_box[I][3], string);
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015,
              0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
              0.0, 1.0, param_char[i]);
      cpgsci(1);
    }

/*
-------------------------------
*/

    TV_menu_hatch(0.00, 0.45, 0.83, 0.98, 7, 4);

/*
-------------------------------
*/

    I = NAME_SECTION;

    i = 13;
    bttn_box[I][0] = 0.21 + 0.50 * (float)(i/7);
    bttn_box[I][1] = 0.44 + 0.50 * (float)(i/7);
    bttn_box[I][2] = 0.94 - 0.05*(float)(i%7);
    bttn_box[I][3] = bttn_box[I][2] + pitch;

    cpgsci(1);
    cpgtext(bttn_box[I][0]-0.19,
            0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
            "Save File Name\0");
    cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
    cpgsci(0);
    cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
            0.0, 1.0, fname);
    cpgsci(1);

/*
-------------------------------
*/

    I = CNTR_SECTION;
    bttn_box[I][0] = 0.14;
    bttn_box[I][1] = 0.32;
    bttn_box[I][2] = 0.05;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    if (DISP_SWT == ON) {
      on_button(&idum, "DISPLAY SCREEN\0", bttn_box[I]);
      cpgsci(15);
      cpgrect(box1, box2, box3, box4);
    } else {
      off_button(&idum, "DISPLAY SCREEN\0", bttn_box[I]);
      cpgsci(0);
      cpgrect(box1, box2, box3, box4);
    }
    I++;
    bttn_box[I][0] = 0.54;
    bttn_box[I][1] = 0.70;
    bttn_box[I][2] = 0.05;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "SAVE\0", bttn_box[I]);
    I++;
    bttn_box[I][0] = 0.75;
    bttn_box[I][1] = 0.91;
    bttn_box[I][2] = 0.05;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "Return\0", bttn_box[I]);
  }

/*
-------------------------------
*/

  while (1) {

    PROC_SWT = OFF;

    if (TV_SWT == ON) {
      cpgcurs(cursor_pos, cursor_pos+1, string);

      for (i=3; i<13; i++) {
        I = ATM_SECTION + i;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          char_copy(string, param_char[i]);
          tv_get_param("char", cursor_pos, bttn_box[I],
                       pitch, string, 0.0, 0.0);
          char_copy(param_char[i], string);
          str_init(string, sizeof(string));
          sscanf(param_char[i], "%lf", &ps_param[i]);
        }
      }

/*
-------------------------------
*/

      I = CNTR_SECTION;
      if (button_chk(cursor_pos, bttn_box[I]) == ON) {
        toggle_button(&DISP_SWT, "DISPLAY SCREEN\0", bttn_box[I]);
        if (DISP_SWT == ON) {
          cpgsci(15);
        } else if (DISP_SWT == OFF) {
          cpgsci(0);
        }
        cpgrect(box1, box2, box3, box4);
      }

      I = CNTR_SECTION + 1;
      if (button_chk(cursor_pos, bttn_box[I]) == ON) {
        on_button(&idum, "Calculating...\0", bttn_box[I]);
        cpgebuf();
        PROC_SWT = ON;
      }

      I = CNTR_SECTION + 2;
      if (button_chk(cursor_pos, bttn_box[I]) == ON) {
        on_button(&idum, "EXIT\0", bttn_box[I]);
        break;
      }

/*
-------------------------------
*/

      I = NAME_SECTION;
      if (button_chk(cursor_pos, bttn_box[I]) == ON) {
        tv_get_param("char", cursor_pos, bttn_box[I],
                     pitch, fname, 0, 0);
      }

/*
-------------------------------
*/

    } else if (TV_SWT == OFF) {
      while (1) {
        printf("#### Parameter Input Menu ####\n");
        printf("1. Screen Height [m] (%f)\n",    (float)ps_param[0]);
        printf("2. Wind Velocity [m/s] (%f)\n",  (float)ps_param[1]);
        printf("3. Position Angle [deg] (%f)\n", (float)ps_param[2]);
        printf("4. Inner Scale [m] (%f)\n",      (float)ps_param[3]);
        printf("5. Outer Scale [m] (%f)\n",      (float)ps_param[4]);
        printf("6. Inner Exponent (%f)\n",       (float)ps_param[5]);
        printf("7. Outer Exponent (%f)\n",       (float)ps_param[6]);
        printf("8. Pixel Size [m] (%f)\n",       (float)ps_param[7]);
        printf("9. Width (x) [m] (%f)\n",        (float)ps_param[8]);
        printf("a. Width (y) [m] (%f) (x<=y)\n", (float)ps_param[9]);
        printf("b. RMS Value (%f)\n",            (float)ps_param[10]);
        printf("c. Baseline Length [m] (%f)\n",  (float)ps_param[11]);
        printf("d. BIAS (%f)\n",                 (float)ps_param[12]);
        printf("\n");
        printf("e. SAVE\n");
        printf("0. EXIT\n");
        printf("\n");
        printf("Input Number : ");
        if (fgets(string, sizeof(string), stdin) == NULL) {
          printf("ERROR: PHASE_SCREEN_CHECK: Invalid input.\n");
          ps_model_out(ps_model_prm, param_char, DISP_SWT, fname);
          return (-1);
        }
        if (string[0] == '0') {
          break;
        } else if (string[0] == 'e') {
          if (DISP_SWT == ON) {
            sprintf(string, "y");
          } else if (DISP_SWT == OFF) {
            sprintf(string, "n");
          }
          printf("DISPLAY MODE (y/n) [CR->%s] : ", string);
          if (fgets(string, sizeof(string), stdin) == NULL) {
            printf("ERROR: PHASE_SCREEN_CHECK: Invalid input.\n");
            ps_model_out(ps_model_prm, param_char, DISP_SWT, fname);
            return (-1);
          }
          if (string[0] == 'y') {
            DISP_SWT = ON;
          } else if (string[0] == 'n') {
            DISP_SWT = OFF;
          }
          printf("SAVE FILE NAME [CR->%s] : ", fname);
          if (fgets(string, sizeof(string), stdin) == NULL) {
            printf("ERROR: PHASE_SCREEN_CHECK: Invalid input.\n");
            ps_model_out(ps_model_prm, param_char, DISP_SWT, fname);
            return (-1);
          }
          if (string[0] != '\n') {
            char_copy(fname, string);
          }

          PROC_SWT = ON;
          break;
        } else if (string[0] >= '1' && string[0] <= '9' ||
                   string[0] >= 'a' && string[0] <= 'd') {
          if (string[0] >= '1' && string[0] <= '9') {
            i = string[0] - '1';
          } else if (string[0] >= 'a' && string[0] <= 'd') {
            i = string[0] - 'a' + 9;
          }
          printf("Input parameter : ");
          if (fgets(string, sizeof(string), stdin) == NULL) {
            printf("ERROR: PHASE_SCREEN_CHECK: Invalid input.\n");
            ps_model_out(ps_model_prm, param_char, DISP_SWT, fname);
            return (-1);
          }
          sscanf(string, "%lf", &ps_param[i]);
          sprintf(param_char[i], "%lf", ps_param[i]);
        }
      }
      if (string[0] == '0') {
        break;
      }
    }

/*
-------------------------------
*/

    if (PROC_SWT == ON) {

      if (ps_param[8] < ps_param[9]) {
        printf("CAUTION: PHASE_SCREEN_CHECK: ");
        printf("Width(y) is greater than Width(x).");
        printf("Please check Width (x) and Width (y).\n");
        lftmp = ps_param[9];
        ps_param[9] = ps_param[8];
        ps_param[8] = lftmp;
        sprintf(param_char[8], "%lf", ps_param[8]);
        sprintf(param_char[9], "%lf", ps_param[9]);
      }

      wvc.H_d        = ps_param[0];
      wvc.v[0]       = ps_param[1] * cos(ps_param[2] / 180.0 * dpi);
      wvc.v[1]       = ps_param[1] * sin(ps_param[2] / 180.0 * dpi);
      wvc.i_scale[0] = ps_param[3];
      wvc.o_scale[0] = ps_param[4];
      wvc.i_expon    = ps_param[5];
      wvc.o_expon    = ps_param[6];
      wvc.pixel      = ps_param[7];

/*
--------
*/

      NX             = (int)lrint(ps_param[8] / ps_param[7]);
      NY             = (int)lrint(ps_param[9] / ps_param[7]);

      nx = NX;
      while (nx%2 == 0)
        nx /= 2;
      if (nx != 1) {
        nx = 1;
        while (nx < NX)
          nx *= 2;
        NX = nx;
      }

      ny = NY;
      while (ny%2 == 0)
        ny /= 2;
      if (ny != 1) {
        ny = 1;
        while (ny < NY)
          ny *= 2;
        NY = ny;
      }

/*
--------
*/

      ps_param[8]    = ps_param[7] * (double)NX;
      ps_param[9]    = ps_param[7] * (double)NY;

      wvc.i_coeffi   = ps_param[10] / pow(ps_param[11], 0.5*ps_param[5]);
      wvc.o_coeffi   = 0.0;
      wvc.c_coeffi   = 0.0;

/*
-------------------------------
*/

      fit_power_two_number(wvc.o_scale[0], wvc.pixel,
                           &(wvc.o_scale[0]), &i);
      ps_param[4] = wvc.o_scale[0];

/*
-------------------------------
*/

      NSCREEN = (int)ceil(ps_param[8] / wvc.o_scale[0]);
      if (NSCREEN > 1) {
        NX = (int)lrint(wvc.o_scale[0] / wvc.pixel);
      }

#ifdef __DEBUG__
      printf("__DEBUG__: Phase_Screen_Check: NSCREEN: %d   NX:%d\n",
             NSCREEN, NX);
#endif /* __DEBUG__ */

      if (DISP_SWT == ON) {
        if (NY >= 128) {
          ny = N128;
          n_bandle = NY / N128;
          if (NY % N128 != 0) {
            n_bandle++;
          }
        } else {
          ny = NY;
          n_bandle = 1;
        }

        nx = NX / n_bandle;
        if (NX % n_bandle != 0) {
          nx++;
        }

        if (nx == ny) {
          pgsvpxmin = 0.30;
          pgsvpxmax = 0.70;
          plot_size_y = pgsvpxmax - pgsvpxmin;
          pgsvpymin = 0.38 - 0.50 * plot_size_y;
          pgsvpymax = 0.38 + 0.50 * plot_size_y;
        } else {
          pgsvpxmin = 0.12;
          pgsvpxmax = 0.92;
          plot_size_y = (pgsvpxmax - pgsvpxmin) * ((float)ny / (float)nx);
          pgsvpymin = 0.38 - 0.50 * plot_size_y;
          pgsvpymax = 0.38 + 0.50 * plot_size_y;
        }

        NPLOT = (int)((box4-box3) / (plot_size_y + plot_space));

        delta_x = wvc.pixel * (float)n_bandle;
        delta_y = wvc.pixel * (float)n_bandle;

        tr[0] = -0.5 * delta_x;
        tr[1] = 0.0;
        tr[2] = delta_y;
        tr[3] = -0.5 * delta_y;
        tr[4] = delta_x;
        tr[5] = 0.0;
      }

      NOD         = NX * NY;
      seed_dist   = (double *)calloc(NX+1, sizeof(double));
      DS          = (double *)calloc(NOD,  sizeof(double));

      CONT_SWT_S = OFF;
      if (NSCREEN == 1) {
        CONT_SWT_E = OFF;
      } else {
        CONT_SWT_E = ON;
      }

      for (nscrn=0; nscrn<NSCREEN; nscrn++) {

#ifdef __DEBUG__
        printf("__DEBUG__: Phase_Screen_Check: nscrn/NSCREEN : (%3d/%3d)\n",
                nscrn+1, NSCREEN);
#endif /* __DEBUG__ */

        corner_position[0][0] = NMTRX/2 - NX/2;
        corner_position[0][1] = NMTRX/2 - NY/2;
        corner_position[1][0] = NMTRX/2 + NX/2 - 1;
        corner_position[1][1] = NMTRX/2 + NY/2 - 1;

        if (corner_position[1][0] > NX - 1) {
          idum = corner_position[0][0];
          corner_position[0][0] -= idum;
          corner_position[1][0] -= idum;
        }
        if (corner_position[1][1] > NX - 1) {
          idum = corner_position[0][1];
          corner_position[0][1] -= idum;
          corner_position[1][1] -= idum;
        }

#ifdef __DEBUG__
        printf("__DEBUG__: Phase_Screen_Check: (%d, %d, %d, %d)\n",
                          corner_position[0][0], corner_position[0][1],
                          corner_position[1][0], corner_position[1][1]);
               
#endif /* __DEBUG__ */

        seed_end[0] = gauss_dev();
        seed_end[1] = gauss_dev();

        if ((COUNT_NOD = turbulent_phase_screen
               (NX, 0, seed_dist, seed_end, &wvc,
                CONT_SWT_S, CONT_SWT_E, 0, IX, IY, DS,
                corner_position, 0)) == -1) {
          free (seed_dist);
          free (DS);
          printf("ERROR: PHASE_SCREEN_CHECK: ");
          printf("generating phase screen failed ");
          printf("in TURBULENT_PHASE_SCREEN.\n");
          ps_model_out(ps_model_prm, param_char, DISP_SWT, fname);
          return (-1);
        } else {
          NOD = COUNT_NOD;
          ps_param[3] = wvc.i_scale[1];
          ps_param[4] = wvc.o_scale[1];
          for (i=3; i<5; i++) {
            I = ATM_SECTION + i;
            sprintf(param_char[i], "%lf", ps_param[i]);
            if (TV_SWT == ON) {
              cpgsvp(0.0, 1.0, 0.0, 1.0);
              cpgswin(0.0, 1.0, 0.0, 1.0);
              cpgsci(1);
              cpgrect(bttn_box[I][0], bttn_box[I][1],
                      bttn_box[I][2], bttn_box[I][3]);
              cpgsci(0);
              cpgptxt(bttn_box[I][1]-0.015,
                      0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
                      0.0, 1.0, param_char[i]);
              cpgsci(1);
            }
          }

          for (i=8; i<10; i++) {
            I = ATM_SECTION + i;
            sprintf(param_char[i], "%lf", ps_param[i]);
            if (TV_SWT == ON) {
              cpgsvp(0.0, 1.0, 0.0, 1.0);
              cpgswin(0.0, 1.0, 0.0, 1.0);
              cpgsci(1);
              cpgrect(bttn_box[I][0], bttn_box[I][1],
                      bttn_box[I][2], bttn_box[I][3]);
              cpgsci(0);
              cpgptxt(bttn_box[I][1]-0.015,
                      0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
                      0.0, 1.0, param_char[i]);
              cpgsci(1);
            }
          }
        }

/*
--------
*/

        if (NSCREEN == 1) {
          sprintf(data_file, "%s", fname);
        } else {
          sprintf(data_file, "%s-%3d", fname, nscrn);
        }
        for (i=0; i<strlen(data_file); i++) {
          if (data_file[i] == '\0') {
            break;
          }
          if (data_file[i] == ' ') {
            data_file[i] = '0';
          }
        }

        if (ps_model_out(data_file, param_char, DISP_SWT, fname) == -1) {
          printf("ERROR: phase_screen_check: cannot open file: %s\n",
                 data_file);
          ps_model_out(ps_model_prm, param_char, DISP_SWT, fname);
          return (-1);
        } else {
          ofp = fopen(data_file, "a");
          fprintf(ofp, "# END OF HEADER\n");
          for (i=0; i<NX; i++) {
            for (j=0; j<NY; j++) {
              fprintf(ofp, "%d,%d,%lf\n", NX*nscrn+i, j, DS[NY*i+j]+ps_param[12]);
            }
          }
          fclose (ofp);
        }

/*
------------------------------------------------
*/

        if (DISP_SWT == ON) {

          DIST = (float *)calloc(NOD, sizeof(float));
          for (i=0; i<NOD; i++) {
            DIST[i] = (float)DS[i];
          }

/*
--
*/

          if ((m_dist = (float *)calloc(nx*ny, sizeof (float))) == NULL) {
            printf("WARNING: ");
            printf("Memory alloc error for showing phase screen map.\n");
            return 1;
          }
          modified_distribution_XY(NX, NY, DIST, nx, ny, n_bandle, m_dist);

          if (NPLOT == 0 || nscrn % NPLOT == 0) {
            cpgsci(15);
            cpgrect(box1, box2, box3, box4);
            cpgsci(1);
          }

          if (NSCREEN == 1 || NPLOT == 0 || NPLOT == 1) {
            pgsvpymin = 0.38 - 0.50 * plot_size_y;
            pgsvpymax = 0.38 + 0.50 * plot_size_y;
          } else {
            pgsvpymax = 0.60
                      - (float)(nscrn%NPLOT) * (plot_size_y + plot_space);
            pgsvpymin = pgsvpymax - plot_size_y;
            sprintf(string, "%3d/%d", nscrn+1, NSCREEN);
            cpgtext(0.02, pgsvpymin, string);
          }

/*
-- The first screen color gradation is applied to the following screen.
*/

          if (nscrn % NPLOT == 0) {
            dmin = m_dist[0];
            dmax = m_dist[0];
            for (i=0; i<nx*ny; i++) {
              if (m_dist[i] < dmin) {
                dmin = m_dist[i];
              }
              if (m_dist[i] > dmax) {
                dmax = m_dist[i];
              }
            }
            dmax -= dmin;
          }
          for (i=0; i<nx*ny; i++) {
            m_dist[i] -= dmin;
            m_dist[i] /= dmax;
          }

/*
--
*/

          cpgsvp(pgsvpxmin, pgsvpxmax, pgsvpymin, pgsvpymax);
          cpgswin(0.0, delta_x*nx, 0.0, delta_y*ny);

          palett(2, 1.0, 0.5);
          cpgimag(m_dist, ny, nx, 1, ny, 1, nx, 0.0, 1.0, tr);
          if (NPLOT <= 4) {
            cpgbox("BN", 0, 0, "BN", 0, 0);
          } else {
            cpgbox("BN", 0, 0, "B", 0, 0);
          }

          free (DIST);
          free (m_dist);
        }

        CONT_SWT_S = ON;
      }

/*
------------------------------------------------
*/

      free (seed_dist);
      free (DS);

/*
------------------------------------------------
*/

      ps_model_out(ps_model_prm, param_char, DISP_SWT, fname);

/*
------------------------------------------------
*/

      if (TV_SWT == ON) {
        cpgsvp(0.0, 1.0, 0.0, 1.0);
        cpgswin(0.0, 1.0, 0.0, 1.0);
        I = CNTR_SECTION + 1;
        off_button(&idum, "SAVE\0", bttn_box[I]);
      }
    }
  }

/*
------------------------------------------------
*/

  return ( 1);
}


int  ps_model_out(char *prm_fname, char param_char[][40],
                  int DISP_SWT, char *save_fname)
{
  FILE   *ifp;

  if ((ifp = fopen(prm_fname, "w")) != NULL) {
    fprintf(ifp, "SCREEN HEIGHT       %s\n", param_char[0]);
    fprintf(ifp, "WIND VELOCITY       %s\n", param_char[1]);
    fprintf(ifp, "POSITION ANGLE      %s\n", param_char[2]);
    fprintf(ifp, "INNER SCALE LENGTH  %s\n", param_char[3]);
    fprintf(ifp, "OUTER SCALE LENGTH  %s\n", param_char[4]);
    fprintf(ifp, "INNER EXPONENT      %s\n", param_char[5]);
    fprintf(ifp, "OUTER EXPONENT      %s\n", param_char[6]);
    fprintf(ifp, "PIXEL SIZE          %s\n", param_char[7]);
    fprintf(ifp, "SCREEN WIDTH (X)    %s\n", param_char[8]);
    fprintf(ifp, "SCREEN WIDTH (Y)    %s\n", param_char[9]);
    fprintf(ifp, "RMS VALUE           %s\n", param_char[10]);
    fprintf(ifp, "BASELINE OF THE RMS %s\n", param_char[11]);
    fprintf(ifp, "BIAS                %s\n", param_char[12]);
    fprintf(ifp, "DISPLAY SWITCH      %1d\n", DISP_SWT);
    fprintf(ifp, "SAVE FILE NAME      %s\n", save_fname);
    fclose (ifp);
    return ( 1);
  } else {
    printf("CAUTION: PHASE_SCREEN_CHECK: ");
    printf("Input parameters cannot be saved in %s.", prm_fname);
    return (-1);
  }
}
