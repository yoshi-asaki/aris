#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <aris.h>

int  baseline_check(int I,         int J,     int ns,
                    int BGN_ANT_I, int END_ANT_I,
                    int BGN_ANT_J, int END_ANT_J,
                    struct antenna_parameter *ant_prm)
{
  if (I >= BGN_ANT_I && I <  END_ANT_I
      &&
      J >= BGN_ANT_J && J <  END_ANT_J) {
    if (ns == -1) {
      return ON;
    } else {
      if (ant_prm[I].WID[ns] >= 0 && ant_prm[J].WID[ns] >= 0) {
        return ON;
      } else {
        return OFF;
      }
    }
  } else {
    return OFF;
  }
}
