#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <aris.h>

int  out_src_proc(int SEP_MODE, int POS_MODE)
{
  return (2 * SEP_MODE + POS_MODE);
}
