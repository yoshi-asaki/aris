#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <aris.h>

#include <Crecipes.h>
#include <nrutil.h>

void gaussian_floar(float , float [], float *, float [], int );

#define  NBH        242
#define  MDL_RSLT   0.250e-3

#define  ALAMDA_LIM 1.0e-10

int   bhs_model(float *dist, int dmax, double *pix_mas, double *pix_uvl,
                char  *ch_bhs_file)
{
  static int    i, j, k, l;
  static int    N_OFF, M, M2;
  static FILE   *fp;
  static float  fdum1, fdum2, fdum3;
  static char   string[100];
  static int    hdmax;
  static int    scale_factor;
  static float  scale_factor_sq;
  static float  *bhm;

  static float  x[NBH], y[NBH], sig[NBH];
  static int    ma = 4;
  static int    ia[10];
  static float  chisq[10], dyda[10];
  static float  A[10], B[10];
  static float  A_tmp[10], B_tmp[10];
  static float  alamda, alamda_tmp;
  static float  **alpha, **covar;
  static float  r;
  static int    ndat;

  hdmax = dmax / 2;

/*
-----------------------------------------
*/

  for (i=0; i<dmax*dmax; i++) {
    dist[i] = -1.0;
    dist[i] =  0.0;
  }

  if ((bhm = (float *)calloc(NBH*NBH, sizeof(float))) == NULL) {
    printf("ERROR: data array for Blackhole model cannot be allocated.\n");
    return (NG);
  }

  if ((fp=fopen(ch_bhs_file, "r")) == NULL) {
    printf("ERROR: data file cannot be found.\n");
    free (bhm);
    return (NG);
  }

/********
  fp = fopen("bhs_data_20080225_Folder/bhs_a00_i20.dat", "r");
  fp = fopen("bhs_data_20080225_Folder/bhs_a00_i45.dat", "r");
  fp = fopen("bhs_data_20080225_Folder/bhs_a00_i90.dat", "r");
  fp = fopen("bhs_data_20080225_Folder/bhs_a10_i20.dat", "r");
  fp = fopen("bhs_data_20080225_Folder/bhs_a10_i45.dat", "r");
  fp = fopen("bhs_data_20080225_Folder/bhs_a10_i90.dat", "r");
********/
  for (i=0; i<NBH; i++) {
    for (j=0; j<NBH; j++) {
      fgets(string, sizeof(string), fp);
      sscanf(string, "%f %f %f\n", &fdum1, &fdum2, &fdum3);
      bhm[NBH*i + j] = fdum3;
    }
    fgets(string, sizeof(string), fp);
  }
  fclose (fp);

/*
----------------------------------------------
*/

  scale_factor = (int)(*pix_mas / (double)MDL_RSLT);
  if (scale_factor == 0) {
    printf("ERROR: Model resolution is not enough. \n");
    exit (0);
  }

  *pix_uvl    /= ((double)MDL_RSLT * (double)scale_factor / *pix_mas);
  *pix_mas     =  (double)MDL_RSLT * (double)scale_factor;
  scale_factor_sq = (float)(scale_factor * scale_factor);

/*
----------------------------------------------
*/

  M     =  NBH / 2 / scale_factor;
  N_OFF = (NBH / 2) % M;
  M2    = 2 * M;

  for (i=0; i<M2; i++) {
    for (j=0; j<M2; j++) {
      fdum1 = 0.0;
      for (k=0; k<scale_factor; k++) {
        for (l=0; l<scale_factor; l++) {
          fdum1 += bhm[NBH * (N_OFF + i*scale_factor + k)
                           + (N_OFF + j*scale_factor + l)];
        }
      }
      dist[dmax*(hdmax-M+i) + hdmax-M+j] = fdum1 / scale_factor_sq;
    }
  }

/*
------------------------------
*/

  alpha = matrix(1, ma, 1, ma);
  covar = matrix(1, ma, 1, ma);
  N_OFF = 50;

  fdum1 = 0.0;
  for (i=0; i<NBH; i++) {
    for (j=0; j<NBH; j++) {
      if (bhm[NBH*i + j] > fdum1) {
        fdum1 = bhm[NBH*i + j];
      }
    }
  }
  fdum1 *= 0.3;

  ndat = 1;
  for (i=0; i<NBH/2-N_OFF; i++) {
    x[ndat]   = (float)(i - NBH/2);
    y[ndat]   = bhm[NBH*i + NBH/2];
    sig[ndat] = 0.2 * y[1];
    ndat++;
  }
  for (i=NBH/2+N_OFF; i<NBH; i++) {
    x[ndat] = (float)(i - NBH/2);
    y[ndat] = bhm[NBH*i + NBH/2];
    sig[ndat] = 0.2 * y[1];
    ndat++;
  }
  ndat -= 1;

  A[1] = fdum1;
  A[2] = -log(y[1] / A[1]) / x[1] / x[1];
  A[3] = 0.0;
  A[4] = 0.20 * y[1];
  alamda = -1.0;
  alamda_tmp = 0.1;

  for (i=1; i<=ma; i++) {
    A_tmp[i] = A[i];
  }
  while (1) {
    mrqmin(x, y, sig, ndat, A_tmp, ia, ma, covar, alpha, chisq,
           gaussian_floar, &alamda);
    if (alamda > alamda_tmp || alamda <= ALAMDA_LIM) {
      break;
    } else {
      alamda_tmp = alamda;
      for (i=1; i<=ma; i++) {
        A[i] = A_tmp[i];
      }
    }
  }

  ndat = 1;
  for (i=0; i<NBH/2-N_OFF; i++) {
    x[ndat]   = (float)(i - NBH/2);
    y[ndat]   = bhm[NBH*NBH/2 + i];
    sig[ndat] = 0.2 * y[1];
    ndat++;
  }
  for (i=NBH/2+N_OFF; i<NBH; i++) {
    x[ndat] = (float)(i - NBH/2);
    y[ndat]   = bhm[NBH*NBH/2 + i];
    sig[ndat] = 0.2 * y[1];
    ndat++;
  }
  ndat -= 1;

  B[1] = fdum1;
  B[2] = -log(y[1] / B[1]) / x[1] / x[1];
  B[3] = 0.0;
  B[4] = 0.20 * y[1];
  alamda = -1.0;
  alamda_tmp = 0.1;

  for (i=1; i<=ma; i++) {
    B_tmp[i] = B[i];
  }
  while (1) {
    mrqmin(x, y, sig, ndat, A_tmp, ia, ma, covar, alpha, chisq,
           gaussian_floar, &alamda);
    if (alamda > alamda_tmp || alamda <= ALAMDA_LIM) {
      break;
    } else {
      alamda_tmp = alamda;
      for (i=1; i<=ma; i++) {
        B[i] = B_tmp[i];
      }
    }
  }

  free_matrix(alpha, 1, ma, 1, ma);
  free_matrix(covar, 1, ma, 1, ma);

  A[1] = sqrt(A[1] * B[1]);
  A[4] = 0.5 * (A[4] + B[4]);

  for (i=0; i<dmax; i++) {
    if (i < hdmax - M || i >= hdmax + M) {
      for (j=0; j<dmax; j++) {
          r = pow((float)((i-hdmax)*scale_factor)-A[3], 2.0) * A[2]
            + pow((float)((j-hdmax)*scale_factor)-B[3], 2.0) * B[2];
          dist[dmax*i + j] = A[1] * exp(-r) + A[4];
      }
    }
  }

  for (j=0; j<dmax; j++) {
    if (j < hdmax - M || j >= hdmax + M) {
      for (i=0; i<dmax; i++) {
          r = pow((float)((i-hdmax)*scale_factor)-A[3], 2.0) * A[2]
            + pow((float)((j-hdmax)*scale_factor)-B[3], 2.0) * B[2];
          dist[dmax*i + j] = A[1] * exp(-r) + A[4];
      }
    }
  }

  free (bhm);

  return 1;
}


void gaussian_floar(float x, float a[], float *y, float dyda[], int na)
{
  static float E;

  E = exp(-a[2]*(x-a[3])*(x-a[3]));

  *y = a[1] * E + a[4];

  dyda[1] = E;
  dyda[2] =  -(x-a[3]) * (x-a[3]) * *y;
  dyda[3] = 2.0 * a[2] * (x-a[3]) * *y;
  dyda[4] = 0.0;

  return;
}
