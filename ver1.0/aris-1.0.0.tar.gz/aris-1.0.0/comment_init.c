#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>


void comment_init(int  N, char comment[][NCOMLEN], int TVSWT,
                  float pgxmin, float pgxmax, float pgymin, float pgymax)
{
  static int    i, j;

  for (i=0; i<N; i++) {
    for (j=0; j<NCOMLEN; j++) {
      comment[i][j] = 0;
    }
  }
  if (TVSWT == ON) {
    cpgsci(4);
    cpgrect(pgxmin, pgxmax, pgymin, pgymax);
    cpgsci(1);
  }
}
