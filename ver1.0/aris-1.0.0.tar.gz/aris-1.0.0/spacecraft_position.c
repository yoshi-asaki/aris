#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>


#define __TRUE_ANOMALY__
#ifndef __TRUE_ANOMALY__
  #define __ECCENTRIC_ANOMALY__
#endif

#define __KEPLERS_EQUATION__
#ifndef __KEPLERS_EQUATION__
  #define __EASY_CALC__
#endif

void spacecraft_position(struct srt_orbit_parameter srt,
                         int    *TimUTC, double UT1_UTC,
                         double *P_xyz,
                         double *Pe_xyz, double *Oe_rac,
                         double *V_xyz)
{
  static double n, l, f, r, u, q;
  static double u_tmp;
  static double E, E1, E2;
  static double cos_u, sin_u;
  static double omega, Omega;
  static double d_day, delta;

/*
--------
*/

  d_day = MJD(TimUTC[0], TimUTC[1], TimUTC[2],
              TimUTC[3], TimUTC[4], TimUTC[5], UT1_UTC) - srt.t0;
  n = sqrt(GM /srt.a/srt.a/srt.a);
  l = n * 86400.0 * d_day;

/*
-------- SATELLITE POSITION --------------------------
*/

#ifdef __KEPLERS_EQUATION__
  u_tmp = l;
  delta = dpi / 180.0 / 3600.0 * 1.0e-3;
  cos_u = cos(u_tmp);
  sin_u = sin(u_tmp);

  while (1) {
    u = u_tmp - (u_tmp - srt.e * sin_u - l) / (1.0 - srt.e * cos_u);
    if (fabs(u - u_tmp) < delta) {
      break;
    } else {
      u_tmp = u;
      cos_u = cos(u_tmp);
      sin_u = sin(u_tmp);
    }
  }
#elif defined __EASY_CALC__
  u = l + (    1.0            * srt.epow[1]
             - 1.0/8.0        * srt.epow[3]
             + 1.0/192.0      * srt.epow[5]
             - 1.0/9216.0     * srt.epow[7]) * sin(l)

        + (    1.0/2.0        * srt.epow[2]
             - 1.0/6.0        * srt.epow[4]
             + 1.0/48.0       * srt.epow[6]) * sin(2.0*l)

        + (    3.0/8.0        * srt.epow[3]
             - 27.0/128.0     * srt.epow[5]
             + 243.0/5120.0   * srt.epow[7]) * sin(3.0*l)

        + (    1.0/3.0        * srt.epow[4]
             - 4.0/15.0       * srt.epow[6]) * sin(4.0*l)

        + (  125.0/384.0      * srt.epow[5]
           - 3125.0/9216.0    * srt.epow[7]) * sin(5.0*l)

        + (    27.0/80.0      * srt.epow[6]) * sin(6.0*l)

        + (16807.0/46080.0    * srt.epow[7]) * sin(7.0*l);

  cos_u = cos(u);
  sin_u = sin(u);
#endif /* __KEPLERS_EQUATION__ */

  r = srt.a * (1.0 - srt.e*cos_u);
  f = atan2(srt.ef*sin_u, cos_u-srt.e);
  f += 0.05 * d_day;
  q = sqrt(GM * srt.a) / r;

  P_xyz[0] = srt.a          * (cos_u - srt.e);
  P_xyz[1] = srt.a * srt.ef *  sin_u;
  P_xyz[2] = 0.0;

  V_xyz[0] = -q          * sin_u;
  V_xyz[1] =  q * srt.ef * cos_u;
  V_xyz[2] = 0.0;

/*
-------- ERROR VECTOR --------------------------------
*/

  E1 = srt.ODDA * sin(0.5 * l          );
  E2 = srt.ODDP * sin(0.5 * l + dpi/2.0);
  E = sqrt(E1*E1 + E2*E2);

  Oe_rac[0] = 0.0;
  Oe_rac[1] = E;
  Oe_rac[2] = 0.0;

#ifdef __TRUE_ANOMALY__
  drotate(Oe_rac,  f + srt.initial_phase,  "x");
#elif defined __ECCENTRIC_ANOMALY__
  drotate(Oe_rac,  l + srt.initial_phase,  "x");
#endif /* ANOMALY */

  drotate(Oe_rac, atan2(E2, fabs(E1)),     "y");
  Pe_xyz[0] = Oe_rac[0];
  Pe_xyz[1] = Oe_rac[1];
  Pe_xyz[2] = Oe_rac[2];
  drotate(Pe_xyz, f,                       "z");

/*
------------------------------------------------------
*/

  omega = srt.omega + srt.d_omega * d_day;
  Omega = srt.Omega + srt.d_Omega * d_day;

/*
------------------------------------------------------
*/

  drotate(P_xyz, omega,            "z");
  drotate(P_xyz, srt.inclination,  "x");
  drotate(P_xyz, Omega,            "z");

  drotate(V_xyz, omega,            "z");
  drotate(V_xyz, srt.inclination,  "x");
  drotate(V_xyz, Omega,            "z");

  drotate(Pe_xyz, omega,           "z");
  drotate(Pe_xyz, srt.inclination, "x");
  drotate(Pe_xyz, Omega,           "z");

/*
------------------------------------------------------
*/

  return;
}
