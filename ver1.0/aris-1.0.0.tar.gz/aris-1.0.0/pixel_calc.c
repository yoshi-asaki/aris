#include <stdio.h>
#include <aris.h>


int  pixel_calc(double *pix_uvl, double *pix_mas,
                double wave_length, double uv_max,
                double uv_factor, int FIELD_SIZE)
{
  *pix_uvl = uv_factor * uv_max / (float)(FIELD_SIZE/2);
  *pix_mas = 1.0 / (2.0 * uv_factor * uv_max / wave_length)
                        / dpi * 180.0 * 3600.0e3;

/********
  *pix_mas = 0.0005;
  *pix_uvl = 1.0 / (2.0 * *pix_mas / wave_length)
                        / dpi * 180.0 * 3600.0e3 / (float)(FIELD_SIZE/2);
  printf("AAAAAAAAAA  %lf  %lf\n", *pix_mas, *pix_uvl);
********/


  return 1;
}
