#include <math.h>

void  funcs(float x, float a[], float *y, float dyda[], int na)
{
  int i;
  float fac, ex, arg, base;

  *y = 0.0;
  arg = (x - 22.23408) / a[1];
  base = pow(x, 2.0);
  ex = exp(-arg*arg);
  fac = a[2] * ex * 2.0 * arg;
  *y = a[2]*ex + a[3]*base;

  dyda[1] = fac * arg / a[1];
  dyda[2] = ex;
  dyda[3] = base;
}
