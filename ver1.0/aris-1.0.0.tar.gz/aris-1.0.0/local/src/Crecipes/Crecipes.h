void covsrt(float **, int   , int [], int);
void gaussj(float **, int   , float **, int );


void  spline(float [], float [], int ,     float , float ,   float []);
void  splint(float [], float [], float [], int   , float ,   float *);
void  lfit(  float [], float [], float [], int   , float [], int [],
             int     , float **, float  *, void *);

void mrqmin(float [], float [], float [], int , float [], int [],
            int , float **, float **, float *, void *, float *);
void mrqcof(float [], float [], float [], int , float [], int [],
            int , float **, float [], float *, void *);
float gasdev(int  *);
void  ksone(float [], unsigned long , float (*func)(float), float *,
            float *);
void  kstwo(float [], unsigned long  , float [], unsigned long ,
            float *, float *);
float probks(float  );
void  sort(int  , float []);

void mrqmin2(float [], float [], float [], int , float [], int [], int [],
             int , float **, float **, float *, void *, float *);
void mrqcof2(float [], float [], float [], int , float [], int [], int [],
             int , float **, float [], float *, void *);
void mrqmin3(float [], float [], float [],
             float [], float [], int , float [], int [], int [],
             int , float **, float **, float *, void *, float *);
void mrqcof3(float [], float [], float [],
             float [], float [], int , float [], int [], int [],
             int , float **, float [], float *, void *);
