#include <stdio.h>
#include <math.h>
#include "astrotools.h"


double EPSIRON(double t)
{
  static double epsiron;
  static double dpi = 3.141592653589793238462643;

  epsiron = 23.44253 - 0.00013*t + 0.00256 * cos((249.0 - 19.3*t)/180.0*dpi)
             + 0.00015 * cos((198.0 + 720.0*t)/180.0*dpi);

  return epsiron/180.0*dpi;
}
