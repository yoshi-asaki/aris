#include <stdio.h>
#include <math.h>
#include "astrotools.h"

/*
----  MJD = JD - 2400000.5 ----
*/

double MJD(int  Y, int  M, int  D, int  h, int  m, int  s, double d_sec)
{
  static int    B;
  static double mjd;

  if (Y <  1582 ||              /* until 4 Oct. 1582 (Julian Calendarn) */
     (Y == 1582 && M < 10) ||
     (Y == 1582 && M == 10 && D <= 4)) {
    B = -2 + (int)((Y + 4716)/4) - 1179;
  } else if (Y >  1582 ||       /* from 10 Oct. 1582 (Gregorian Calendarn) */
            (Y == 1582 && M > 10) ||
            (Y == 1582 && M == 10 && D >= 10)) {
    B = (int)(Y/400) - (int)(Y/100) + (int)(Y/4);
  }

  if (M <= 2) {
    M += 12;
    Y--;
  }

  mjd = (double)(
          365*Y - 679004 + B + (int)((double)30.6001*(double)(M+1)) + D);
  mjd += ((double)(3600*h + 60*m + s) + d_sec) / 86400.0;

  return mjd;
}
