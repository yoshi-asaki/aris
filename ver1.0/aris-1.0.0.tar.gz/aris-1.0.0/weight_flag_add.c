#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>


int  weight_flag_add(float src_flag, float *weight, float flag)
{
  static int    i, N, nflag, npart, obs_flag[6];
  static float  wt, add_wt;

  for (i=0; i<6; i++) {
    obs_flag[i] = OFF;
  }

  nflag = (int)fabs(flag);
  N = 32;
  for (i=5; i>=0; i--) {
    npart = nflag / N;
    if (npart == 1) {
      obs_flag[i] = ON;
    }
    nflag %= N;
    N /= 2;
  }

  wt = *weight - src_flag;
  if (wt < 0.0) {
    nflag = (int)fabs(wt);
    N = 32;
    for (i=5; i>=0; i--) {
      npart = nflag / N;
      if (npart == 1) {
        obs_flag[i] = ON;
      }
      nflag %= N;
      N /= 2;
    }
  }

  add_wt = 0.0;
  for (i=0; i<6; i++) {
    if (obs_flag[i] == ON) {
      add_wt += pow(2.0, (float)i);
    }
  }

  if (add_wt > 0.0) {
    *weight = src_flag - add_wt;
  } else {
    *weight = src_flag + wt;
  }

  return ( ON);
}
