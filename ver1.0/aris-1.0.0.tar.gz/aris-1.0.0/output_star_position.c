#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>


void output_star_position(char *RA,  char *DC,  double *s)
{
  static int    i;
  static int    rahh, ramm, dcdd, dcmm;
  static double rass, dcss;

/*
----------------------------
*/

  xyz2radec(s, &rahh, &ramm, &rass, &dcdd, &dcmm, &dcss);
  sprintf(RA, "%2d %2d %9.6lf\0", rahh, ramm, rass);
  while ((i=strlen(RA)-1) >= 10) {
    if (RA[i] == '0') {
      RA[i] = '\0';
    } else {
      break;
    }
  }

/*
----------------------------
*/

  if (dcdd >= 0) {
    DC[0] = '+';
  } else if (dcdd < 0) {
    DC[0] = '-';
  }

  if (abs(dcdd) < 10) {
    sprintf(DC+1, "0%1d %2d %9.6lf\0", abs(dcdd), abs(dcmm), fabs(dcss));
  } else if (abs(dcdd) >= 10) {
    sprintf(DC+1,  "%2d %2d %9.6lf\0", abs(dcdd), abs(dcmm), fabs(dcss));
  }
  while ((i=strlen(DC)-1) >= 11) {
    if (DC[i] == '0') {
      DC[i] = '\0';
    } else {
      break;
    }
  }

/*
----------------------------
*/

  return;
}
