#include <stdio.h>
#include <math.h>
#include <Crecipes.h>
#include <aris.h>


int   TEC_fluctuation_amp(double Ci[][86400], int    *TimUTC)
{
  static int    i, imonth, ihour, I, Ihem;
  static FILE   *fp;
  static float  C[30], sec[30], spl[30], fdum;
  static double lfdum1, lfdum2;
  static double CI, fm;
  static double ci[12][24];
  static char   string[100];

/*
============================================
*/

  CI = 0.0;
  if ((fp=fopen("aris_input/tecfluc.dat", "r")) == NULL) {
    printf("ERROR: aris: cannot open tecfluc.dat.\n");
    return (-1);
  } else {
    for (imonth=0; imonth<12; imonth++) {
      for (ihour=0; ihour<24; ihour++) {
        fgets(string, sizeof(string), fp);
        sscanf(string, "%lf %lf %lf", &lfdum1, &lfdum2, &ci[imonth][ihour]);
        ci[imonth][ihour] *= 1.0e10;
        if (ci[imonth][ihour] > CI) {
          CI = ci[imonth][ihour];
        }
      }
      fgets(string, sizeof(string), fp);
    }
    fclose (fp);
  }

  for (imonth=0; imonth<12; imonth++) {
    for (ihour=0; ihour<24; ihour++) {
      ci[imonth][ihour] /= CI;
    }
  }

/****************
  if ((fp=fopen("tecfluc.dat", "w")) == NULL) {
    printf("ERROR: aris: cannot open tecfluc.dat.\n");
    return (-1);
  } else {
    for (imonth=0; imonth<12; imonth++) {
      for (ihour=0; ihour<24; ihour++) {
        fprintf(fp, "%2d %2d %lf\n", imonth+1, ihour+1, ci[imonth][ihour]);
      }
      fprintf(fp, "\n");
    }
    fclose (fp);
  }
****************/

/*
============================================
*/

  for (Ihem=0; Ihem<2; Ihem++) {
    for (ihour=0; ihour<24; ihour++) {
      fm = (double)TimUTC[2] / 30.0;
      if (Ihem == 0) {
        I = TimUTC[1] - 1;
      } else {
        I = TimUTC[1] - 1 + 6;
        if (I > 11) {
          I -= 12;
        }
      }
      if (I == 11) {
        C[ihour+1] = (1.0 - fm) * ci[11][ihour] + fm * ci[0][ihour];
      } else {
        C[ihour+1] = (1.0 - fm) * ci[ I][ihour] + fm * ci[I+1][ihour];
      }
      sec[ihour+1] = (float)ihour * 3600.0;
    }
    C[25] = C[1];
    sec[25] = 86400.0;

    spline(sec, C, 25, 1.0e30, 1.0e30, spl);
    for (i=0; i<86400; i++) {
      splint(sec, C, spl, 25, (float)i, &fdum);
      Ci[Ihem][i] = (double)fdum;
    }
  }

  return ( 1);
}
