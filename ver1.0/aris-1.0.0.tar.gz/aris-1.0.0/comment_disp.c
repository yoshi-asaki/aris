#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>


void comment_disp(int N, char comment[][NCOMLEN], char *add_comment,
                  int NEW_ADD,
                  float comxmin, float comxmax, float comymin, float comymax,
                  float pitch)
{
  static int    i, MMN;
  static float  pgx, pgyr, pgyt;

  MMN = (int)((comymax - comymin) / pitch);

  pgx = comxmin + 0.02;

  if (NEW_ADD == ON) {
    if (strlen(comment[MMN-1]) == 0) {
      for (i=0; i<MMN; i++) {
        if (strlen(comment[i]) == 0) {
          char_copy(comment[i], add_comment);
          pgyr = comymax - (i + 1) * pitch + 0.4 * pitch;
          cpgsci(7);
          cpgtext(pgx, pgyr, comment[i]);
          break;
        }
      }
    } else if (strlen(comment[MMN-1]) != 0) {
      for (i=0; i<MMN-1; i++) {
        pgyt = comymax - (float)(i + 1) * pitch + 0.4 * pitch;
        cpgsci(4);
        pgyr = comymax - (float)(i + 1) * pitch;
        cpgrect(comxmin, comxmax, pgyr, pgyr+pitch);
        if (strlen(comment[i+1]) != 0) {
          char_copy(comment[i], comment[i+1]);
          cpgsci(7);
          cpgtext(pgx, pgyt, comment[i]);
        } else {
          break;
        }
      }

      char_copy(comment[i], add_comment);
      pgyt = comymax - (float)(i + 1) * pitch + 0.4 * pitch;
      cpgsci(4);
      pgyr = comymax - (float)(i + 1) * pitch;
      cpgrect(comxmin, comxmax, pgyr, pgyr+pitch);
      cpgsci(7);
      cpgtext(pgx, pgyt, comment[i]);
      cpgsci(1);
    }
  } else if (NEW_ADD == OFF) {
    if (strlen(comment[MMN-1]) == 0) {
      for (i=0; i<MMN; i++) {
        if (strlen(comment[i]) == 0) {
          strcat(comment[i-1], add_comment);
          pgyt = comymax - (float)i * pitch + 0.4 * pitch;
          cpgsci(7);
          cpgtext(pgx, pgyt, comment[i-1]);
          cpgsci(1);
          break;
        }
      }
    } else if (strlen(comment[MMN-1]) != 0) {
      strcat(comment[MMN-1], add_comment);
      pgyt = comymax - (float)MMN * pitch + 0.4 * pitch;
      cpgsci(7);
      cpgtext(pgx, pgyt, comment[MMN-1]);
      cpgsci(1);
    }
  }

  return;
}
