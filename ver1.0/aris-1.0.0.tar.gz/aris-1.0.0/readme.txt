------------------------------------------------------
------------------------------------------------------
            ****  A R I S  ****

Astronomical Radio Interferometer Simulator

      Last Update : 2009-12-10 04:00 UT

------------------------------------------------------
------------------------------------------------------

-----------------------
HOW TO INSTALL
-----------------------

1. Install CFITSIO library as follows. 
   NOTE : the source files are not included in this distribution. 

    a: % cd $(SIMTMP)/local/src/cfitsio/
    b: % ./configure --prefix=$(SIMTMP)/local
    c: % make
    d: % make install

2. Install PGPLOT library. 

3. Uncompress tar-ball with tar command: 

    % tar xvfz simtmp.tar.gz

   You can see a new directory, simtmp. This directory is here called 
   $(SIMTMP). 

4. Install local libraries as follows.

    a: % cd $(SIMTMP)/local/src/mathtools/ ; make
    b: % cd $(SIMTMP)/local/src/astrotools/ ; make
    c: % cd $(SIMTMP)/local/src/Crecipes/ ; make
    d: % cd $(SIMTMP)/local/src/pgtools/ ; make

5. Now you can compile the simulation program, aris.
   (Astronomical Radio Interferometer Simulator) 

    a. % cd $(SIMTMP)/source/
    b. Modify Imakefile if needed. You may need to modify directory 
       information of include files and libraries. 
       (PGPLOT_LIBDIR, PGPLOT_INCDIR, CFITIO_LIBDIR, CFITIO_INCDIR,
        LOCAL_LIBDIR, LOCAL_INCDIR, F77, and CC)
    c. % xmkmf
    d. % make aris


-----------------------
BEFORE USING
-----------------------

You have to copy directories of $(SIMTMP)/source/aris_input/ 
and $(SIMTMP)/source/aris_log/ to your working directory unless 
you use aris in the directory in which there is the executable 
command file. 


-----------------------
HOW TO USE
-----------------------

If you succeed the compilation, you can run the simulator. 

% aris

Or, if you want to run aris with its GUI, run aris with -g option.

% aris -g

I will describe how to use aris in the text user interface mode.

---- ERROR PROC MODE ----
1. Antenna Position Error
2. Reference Position Error
3. EOP error
4. Trospospheric Error
5. Ionospheric Error
6. Water Vapor Turbulence
7. TEC Turbulence
8. Thermal Noise Error
9. Antenna Gain Bias Error
---- Current ERROR FLAG Status : 000000000
Input ERROR FLAG: 

     Select error sources which you would like to consider in 
     your simulation. If you want to turn off all the error 
     sources, input 000000000 or just type RETURN key. If you 
     want to turn on all the error, input 111111111. If you 
     want to turn on the antenna position error and thermal 
     noise error, input 100000010. 

Input ERROR FLAG: 111111111
---- New ERROR FLAG Status : 111111111
Which input type for the source positions?
1. R.A.       -   DEC.
2. Delta_R.A. -   Delta_DEC.
3. Sep_ang    -   P.A.
(CR->1)
Input number: 

    Select number which you prefer. If you select 1, you 
    have to input the phase referencing pair of sources 
    which you would like to simulate in right ascension and 
    declination. We here give you an example when you select 
    2. 

**** MID-POTINT OF SOURCES (J2000) ****
Input RA (CR->02 00 00.0) : 

     Input the mid point between a target and reference 
     source. If you don't need a phase-referencing simulation, 
     input your target source position. 

Input RA (CR->02 00 00.0) : 02 00 00                   -> hh mm ss
Input DEC (CR->60 00 00.0) : 60 00 00                  -> dd mm ss
Separation Angle (RA) [deg] (CR->2.0) : 

     Input the separation angle between the sources. If you don't 
     need the phase-referencing, input 0 for RA and DEC. 

Separation Angle (RA) [deg] (CR->2.000000) : 2
Separation Angle (DC) [deg] (CR->1.000000) : 1
Separation Angle [deg]: 2.236045
Input Observation Date [yyyymmdd] (CR->20101121) : 20101121

     Input the observation date when the simulatioted observation 
     will start. 

Input Start UTC (hhmmss) (CR->060000) : 060000

     Input the start UTC time. 


Observing Duration [hour] (CR->8.000000) : 8

     Input the observation duration. 

GRT MINIMUM elevation (CR->20 [def]) : 20

     Input the minimum elevation angle of the telescopes which 
     attend the simulated observation. If you set too low elevation 
     angle, the simulation may not work with the error option of 
     ``Water Vapor Turbulence" and/or ``TEC Turbulence". We recommend 
     to use an elevation angle higher than 10-15 degrees. 

Which ARRAY:
 0. NO CHANGE in ANTENNA
 1. RESET       2. VLBA        3. EVN         4. HSA         5. VERA       
 6. J-NET       7. KVN         8. LBA        
(CR->VLBA) : 2

     Select array. ``RESET" means that you do not select any array, 
     so that you have to select each of telecopes listed later. 
     Note that the antenna parameters of the VLBA and VERA are 
     set based on their official observation status report. We are 
     not sure whether the other array antenna parameters are correct, 
     although those parameters are based on SCHED information. 

     Then, you can see the antenna list which has been selected: 

SELECTED Antennas:
 1. VLBASC      2. VLBAHN      3. VLBANL      4. VLBAFD      5. VLBALA     
 6. VLBAPT      7. VLBAKP      8. VLBAOV      9. VLBABR     10. VLBAMK     
11.            12.            13.            14.            15.            
16.            17.            18.            19.            20.            
21.            22.            23.            24.            25.            
26.            27.            28.            29.            30.            
31.            32.            33.            34.            35.            
36.            37.            38.            39.            40.            
41.            42.            43.            44.            45.            
46.            47.            48.            49.            50.            


Antenna List:
 1.             2.             3.             4.             5.            
 6.             7.             8.             9.            10.            
11. GBT        12. VLA_Y27    13. ARECIBO    14. EVNJb-1    15. EVNJb-2    
16. EVNCm      17. EVNWb      18. EVNEb/Ef   19. EVNMc      20. EVNNt      
21. EVNOn-85   22. EVNOn-60   23. EVNSh      24. EVNUr      25. EVNTr      
26. EVNMh      27. EVNYb      28. EVNAr      29. EVNHh      30. EVNWz      
31. VERAMZ     32. VERAIR     33. VERAOG     34. VERAIS     35. KASHIM34   
36. NRO45      37. USUDA64    38. KVNSEO     39. KVNULS     40. KVNJEJ     
41. TAEDUK     42. LBANAR     43. LBAMOP     44. LBAPKS     45. LBATID     
46. LBAHBT     47. LBACED     48. HARTRO     49. SEST       50. ALMA       

Input number (0, CR->Exit) : 

    If you would like to add or delete a specified antenna, input 
    the number. If you are satisfied by the list, input 0 or carriage 
    return. 

How many space telescopes [0-2] (CR->1) : 0

    If you want to add a space telescope such like HALCA or 
    ASTRO-G satellite to form a space-VLBI observation, input 
    the number of the satellite. Otherwise, input 0. At this 
    moment, we are not goint to explain the space-VLBI function 
    at this moment. 

ARIS starts....
REF Position Shift [sec] : (RA, Dec)=(-0.000007453,  0.000008554)
TGT Position Shift [sec] : (RA, Dec)=(-0.000007422,  0.000008581)

    If you have selected the error source of ``Reference Position 
    Error", the minor position shift is added to the reference 
    source. The quantity is ramdomly selected. Target position 
    is not changed while the position shift of the reference 
    source occurs. ARIS just shows the prediction of the apparent 
    position shift of the target source in the case that the 
    reference position is not correct. 

    If you have selected the error source of the TROPOSPHERIC 
    disturbance, the phase-screen simlation starts. It takes 
    a few minutes, depending on the observing duration and 
    CPU power. 

**** Tropospheric Phase Screen ****
Frozen Flow  SITE :   VLBA_SC   0-10-20-30-
Frozen Flow  SITE :   VLBA_HN   0-10-20-30-
Frozen Flow  SITE :   VLBA_NL   0-10-20-30-
Frozen Flow  SITE :   VLBA_FD   0-10-20-30-
Frozen Flow  SITE :   VLBA_LA   0-10-20-30-
Frozen Flow  SITE :   VLBA_PT   0-10-20-30-
Frozen Flow  SITE :   VLBA_KP   0-10-20-30-
Frozen Flow  SITE :   VLBA_OV   0-10-20-30-
Frozen Flow  SITE :   VLBA_BR   0-10-20-30-
Frozen Flow  SITE :   VLBA_MK   0-10-20-30-

     If you have selected the error source of the IONOSPHERIC 
     disturbance, the phase-screen simlation starts. It takes 
     a few minutes, depending on the observing duration and 
     CPU power. 

**** Ionospheric Phase Screen ****
Frozen Flow  SITE :  VLBA_SC   0-10
Frozen Flow  SITE :  VLBA_HN   0-10
Frozen Flow  SITE :  VLBA_NL   0-10
Frozen Flow  SITE :  VLBA_FD   0-10
Frozen Flow  SITE :  VLBA_LA   0-10
Frozen Flow  SITE :  VLBA_PT   0-10
Frozen Flow  SITE :  VLBA_KP   0-10
Frozen Flow  SITE :  VLBA_OV   0-10
Frozen Flow  SITE :  VLBA_BR   0-10
Frozen Flow  SITE :  VLBA_MK   0-10

     If you have selected the error source of the TEC TID
     (Total Electron Content / Traveling Ionospheric Disturbance),
     the simlation starts. 

**** TEC TID Simulation ****
**** UVW Calculation ****
1. Ground-Ground    0. EXIT (CR->1) : 

     Select baseline set which you need. 

1. All    2. Ground-Ground    3.Space-Ground    0. EXIT (CR->1) : 1
Tropospheric Noise Power:
1. Good Condition  2. Typical Codition  3. Poor Condition (CR->1) : 

     Select the tropospheric condition for the trpospheric phase 
     fluctuations. The difinition of GOOD, TYPICAL, and BAD 
     is based on the documents written by Ulvestad (VLBA Scientific 
     memo, No.20, 1999), and by Beasley and Conway (VLBI Phase-
     Referencing, Very Long Baseline Interferometry and the VLBA, 
     1995). 

1. Good   2. Typical   3. Poor (CR->1) : 2
Ionospheric Noise Power:
1. Half Condition  2. Normal Codition  3. Double Condition (CR->2) : 

     Select the ionospheric condition as shown in the above. 

Input Tropospheric Zenith Error [cm] (CR->6.000000[cm]) : 6

     Input the excess path length error due to the troposphere. 
     We consider that 3-10 cm is a usual selection. 

Input Ionospheric Zenith Error [TECU] (CR->6.000000[TECU]) : 6

     Input the TEC error causing the excess path legth error. 
     We consider that 6-20 TECU is a usual selection. 

Target Wave Band
1.L   2.S   3.C   4.X   5.Ku  6.Ka  7.Q   8.BAND3  9.BAND4  (CR->6) : 

     Select the receiver for the target source. 

Reference Wave Band
1.L   2.S   3.C   4.X   5.Ku  6.Ka  7.Q   8.BAND3  9.BAND4  (CR->6) : 

     Select the receiver for the reference source. 

Observing Band Width
[1.2MHz 2.8MHz 3.16MHz 4.32MHz 5.64MHz 6.128MHz 7.256MHz 8.512MHz]
(CR->3) : 

    Select the observing band width both for the target and reference 
    sources. 

Frequency Channel
[1. 1CH   2. 4CH   3. 8CH   4. 16CH  5. 32CH ]
(CR->3) : 

    Select the number of the frequency channels in the bandwidth.
    Note that the larger you select, the havier the load. If you 
    do not need the delay search in the following analysis, select 
    ``1CH" option. Even if you want to carry our the delay search 
    later in the data analysis, select as small number as possible. 

Sampling Bit Number [1.1-bit  2.2-bit] (CR->2) : 

     Select the sampling bit number to set the quantization level. 

Switching Cycle Time [sec] (CR->60.000000) : 

     Input the switching cycle time for the phase-referencing. 
     ON-source duration is automatically calculated in the 
     simulator from the antenna slew parameters mentioned in 
     the source code. If you don't need the switching observations, 
     input 0. 0-sec of the switching cycle time does not kill 
     the phase-referecing mode, but simulate an in-beam mode or 
     dual beam mode. 

Target Morphology :
1. Single Point
2. Two-Component
3. Disk & Jet-CJet
4. Disk & VSOP2-Jet
5. AIPS CC Table
Select number (CR->1) : 1

    Select the morphology of the target source. 

Target Total Flux [Jy]   (CR->0.100000) : 

    Input the total flux density of the target source. 

Reference Morphology :
1. Single Point
2. Two-Component
3. Disk & Jet-CJet
4. Disk & VSOP2-Jet
5. AIPS CC Table
Select number (CR->1) : 
Reference Total Flux [Jy]   (CR->0.400000) : 

    Do the same thing for the reference source as you did 
    for the target source. 

ARIS continues...
SEFD (VLBASC) :   888.11 Jy      888.11 Jy
SEFD (VLBAHN) :   888.11 Jy      888.11 Jy
SEFD (VLBANL) :   888.11 Jy      888.11 Jy
SEFD (VLBAFD) :   888.11 Jy      888.11 Jy
SEFD (VLBALA) :   888.11 Jy      888.11 Jy
SEFD (VLBAPT) :   888.11 Jy      888.11 Jy
SEFD (VLBAKP) :   888.11 Jy      888.11 Jy
SEFD (VLBAOV) :   888.11 Jy      888.11 Jy
SEFD (VLBABR) :   888.11 Jy      888.11 Jy
SEFD (VLBAMK) :   888.11 Jy      888.11 Jy
**** Target data processed.      ****
**** Reference data processed.   ****
**** plot : OBSERVING RESULTS ****
1. ON source duration
2. GRT error quantities
3. Az-El plot
4. (u, v) Plane
5. Fringe Phase & Amplitude
6. FITS-IDI save
7. Simple FFT Imaging (no CLEAN)
g. XXXX GPS - Link Conditions (statistics) XXXX
h. Error Path Length time series
i. Error Path Length power spectrum (target)

0. RETURN
-. EXIT
Select number: 

     You can see the menu. Please try them if you are interested. 
     If you just want to make FITS-IDI format file, select 6.

Select number: 6
which data
[1.target without P-R  2.Cal source  3.target with P-R  0.RETURN] :

     Select what you want. Then, input the file name of the newly 
     created fits file.

which data
[1.target without P-R  2.Cal source  3.target with P-R  0.RETURN] : 3
File name (CR->ARIS-03.FITS) : J0200+60-PR.FITS


-----------------------
CHANGE LOG
-----------------------
2009-12-10 04:00 UTC
2007-11-24 11:05 UTC
2005-04-25 09:55 UTC
2004-11-04 08:30 UTC
    Update
