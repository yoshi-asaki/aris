#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>


int  ref_pos_shift(struct source_parameter *src,
                   char  comment[][NCOMLEN], int NCOM,
                   float comxmin, float comxmax, float comymin, float comymax,
                   float pitch,   int   TV_SWT,  int  PGMENU_ID)
/********
    src[0] : TARGET SOURCE
    src[1] : REFERENCE SOURCE
********/
{
  static int    i;
  static char   string[100];
  static double theta1, theta2, DS, p[3];
  static double s_e[3];
  static double dra, ddc;
  static double RA_e, DC_e;
  static double DPI_sec;
  static double q[4], A[9];

/*
===================================================================
*/

  DPI_sec = dpi / 180.0 / 3600.0;

  theta1 = 2.0 * dpi * random_val0();
  theta2 = 2.0 * dpi * random_val0();
  p[0] = cos(theta1) * cos(theta2);
  p[1] = cos(theta1) * sin(theta2);
  p[2] = sin(theta1);
  DS = 0.3e-3 * DPI_sec * gauss_dev();
  vector_rotation(src[1].s_e, p, DS);

  src[1].RA_e  = atan2(src[1].s_e[1], src[1].s_e[0]);
  src[1].DC_e  = atan2(src[1].s_e[2], vlen2(src[1].s_e));

  dra = (src[1].RA_e - src[1].RA2k) / DPI_sec * cos(src[1].DC_e);
  ddc = (src[1].DC_e - src[1].DC2k) / DPI_sec;
  sprintf(string,
       "REF Position Shift [sec] : (RA, Dec)=(%12.9lf, %12.9lf)\0", dra, ddc);
  if (TV_SWT == ON) {
    comment_disp(1, comment, string, ON, comxmin, comxmax, comymin, comymax,
                 pitch);
  } else {
    printf("%s\n", string);
  }

/*
----------------
*/

  minor_shift_refpos(src[1].s2k, src[1].s_e, src[0].s2k, s_e, q, A);

  RA_e = atan2(s_e[1], s_e[0]);
  DC_e = atan2(s_e[2], vlen2(s_e));

  dra = (RA_e - src[0].RA2k) / DPI_sec * cos(src[0].DC2k);
  ddc = (DC_e - src[0].DC2k) / DPI_sec;
  sprintf(string,
       "TGT Position Shift [sec] : (RA, Dec)=(%12.9lf, %12.9lf)\0", dra, ddc);
  if (TV_SWT == ON) {
    comment_disp(1, comment, string, ON, comxmin, comxmax, comymin, comymax,
                 pitch);
  } else {
    printf("%s\n", string);
  }

  return 1;
}
