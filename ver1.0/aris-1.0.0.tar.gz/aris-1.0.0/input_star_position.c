#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>


void input_star_position(char *RA,  char *DC,  double *ra, double *dc)
{
  static int    i;
  static double ras, dcs;
  static int    rah, ram, dcd, dcm;
  static char   string[30];

/*
----------------------------
*/

  sscanf(RA, "%d %d %lf", &rah, &ram, &ras);
  *ra = ((double)rah + (double)ram/60.0 + (double)ras/3600.0) * 15.0;
  *ra *= (dpi / 180.0);

/*
----
*/

  sscanf(DC, "%d %d %lf", &dcd, &dcm, &dcs);
  i = 0;
  while (1) {
    if (DC[i] != ' ') {
      break;
    }
    i++;
  }
  if (DC[i] == '-') {
    *dc = -1.0*(double)dcd + (double)dcm/60.0 + (double)dcs/3600.0;
    *dc *= -1.0;
  } else {
    *dc =      (double)dcd + (double)dcm/60.0 + (double)dcs/3600.0;
  }
  *dc *= (dpi / 180.0);

/*
----
*/

  return;
}
