#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>

#define ERROR_SECTION    10
#define SRCPROC_SECTION  30
#define SOURCE_SECTION   40
#define TIME_SECTION     50
#define GRT_SECTION      60
#define ARRAY_SECTION    70
#define ANTENNA_SECTION  90
#define SRT_SECTION     190

#define CHAR_LEN         30

#define SECT_DAT        250

#define ARRAY_MAX        20


int  obs_param_input(int  *ERROR_FLAG, int  *ARRAY_ID, int  *wave_id,
                     int  *ANT_NUM,    int  *GRT_NUM,  int  *SRT_NUM,
                     struct srt_orbit_parameter *srt,
                     double *grt_elevation_limit,
                     double sep_angle_limit_from_earth_limb,
                     int  *TimUTC, double *UT1_UTC, double *obs_duration,
                     struct source_parameter *src,
                     struct source_parameter *sun,
                     struct antenna_parameter  *ant_prm,
                     struct comment_param      *cmnt,
                     char comment[][NCOMLEN],
                     int  TV_SWT, float *cursor_pos, int  *pgid)
{
  int     i, j, k, I, J;
  int     idum, nstr;
  char    string[500];
  int     timUTC[6];
  int     ERROR_MENU_NUM;
  int     ALL_ERROR_FLAG;
  int     SEPANG_UPDATE;
  struct  char_obs_time  ch_obs_t;

  char    error_source[ERROR_NUM_P2][CHAR_LEN], srtaer[CHAR_LEN];
  float   y_pos, source_y_pos;
  float   bttn_box[SECT_DAT][4];

  int     SRT_SWT, START_FLAG, ARRAY_NUM;
  int     array_flag[ARRAY_MAX], array_id[ARRAY_MAX];
  char    array_name[ARRAY_MAX][10];
  int     *antenna_ufl;

  int     grt_num;
  int     BASIC_SEP_MODE=3, SRCPROC_MODE, SRCPROC_SWT;
  int     POS_MODE, SEP_MODE;
  int     srcproc_flag[NSRCPROC];
  char    srcproc_name[NSRCPROC][20];
  struct  char_src_info  ch_src;
  struct  pair_src_info pair_src;
  struct  antenna_parameter ant_prm_tmp;

  char    ch_grt_el_lim[20];
  struct  char_srt_info  ch_srt[SRTMAX];
  float   pitch=0.03;

/*
-----------------------------------------------------
*/

  START_FLAG     = OFF;
  SRCPROC_MODE   = SRCPROC1;
  ERROR_MENU_NUM = ERROR_NUM - 1;
  nstr           = sizeof(string);

/*
-----------------------------------------------------
*/

  *ANT_NUM = array_config(*ARRAY_ID, wave_id, *SRT_NUM, GRT_NUM,
                          "",        ant_prm,           OFF,
                          "aris_input/antenna.prm",     ON);

/*
-----------------------------------------------------
*/

  if ((antenna_ufl=(int *)calloc(*GRT_NUM, sizeof(int))) == NULL) {
    printf("ERROR: obs_param_input: memory allocation error.\n");
    return ( NG);
  }

/*
-----------------------------------------------------
*/

  obs_param_file_io(ERROR_FLAG,
                    ARRAY_ID, ANT_NUM, GRT_NUM, SRT_NUM,
                    srt, grt_elevation_limit,
                    sep_angle_limit_from_earth_limb,
                    TimUTC, UT1_UTC, obs_duration,
                    antenna_ufl, &SRCPROC_MODE, src, sun, ant_prm,
                    ch_grt_el_lim, &pair_src, &ch_src,
                    ch_srt, &ch_obs_t, 0);

/*
--------
*/

  in__src_proc(SRCPROC_MODE, &SEP_MODE, &POS_MODE);
  if (SEP_MODE == SRC__RA__DEC) {
    if (strlen(ch_src.tgt_ra) == 0 || strlen(ch_src.tgt_dc) == 0 ||
        strlen(ch_src.ref_ra) == 0 || strlen(ch_src.ref_dc) == 0) {
      if (strlen(ch_src.tgt_ra) != 0 && strlen(ch_src.tgt_dc) != 0) {
        if (strlen(ch_src.dlt_ra) != 0 && strlen(ch_src.dlt_dc) != 0) {
          SEP_MODE = SRC_dRA_dDEC;
          POS_MODE = SRC_POS1;
        } else if (strlen(ch_src.sepang) != 0 && strlen(ch_src.posang) != 0) {
          SEP_MODE = SRC_dRA_dDEC;
          POS_MODE = SRC_POS2;
        }
      } else if (strlen(ch_src.mid_ra) != 0 && strlen(ch_src.mid_dc) != 0) {
        if (strlen(ch_src.dlt_ra) != 0 && strlen(ch_src.dlt_dc) != 0) {
          SEP_MODE = SRC_SEP_POSA;
          POS_MODE = SRC_POS1;
        } else if (strlen(ch_src.sepang) != 0 && strlen(ch_src.posang) != 0) {
          SEP_MODE = SRC_SEP_POSA;
          POS_MODE = SRC_POS2;
        }
      }
    }
  } else if (SEP_MODE == SRC_dRA_dDEC) {
    if (strlen(ch_src.tgt_ra) == 0 || strlen(ch_src.tgt_dc) == 0) {
      if (strlen(ch_src.mid_ra) != 0 && strlen(ch_src.mid_dc) != 0) {
        if (strlen(ch_src.dlt_ra) != 0 && strlen(ch_src.dlt_dc) != 0) {
          SEP_MODE = SRC_SEP_POSA;
          POS_MODE = SRC_POS1;
        } else if (strlen(ch_src.sepang) != 0 && strlen(ch_src.posang) != 0) {
          SEP_MODE = SRC_SEP_POSA;
          POS_MODE = SRC_POS2;
        }
      }
    }
  } else if (SEP_MODE == SRC_SEP_POSA) {
    if (strlen(ch_src.mid_ra) == 0 || strlen(ch_src.mid_dc) == 0) {
      if (strlen(ch_src.tgt_ra) != 0 && strlen(ch_src.tgt_dc) != 0) {
        if (strlen(ch_src.ref_ra) != 0 && strlen(ch_src.ref_dc) != 0) {
          SEP_MODE = SRC__RA__DEC;
        } else if (strlen(ch_src.dlt_ra) != 0 && strlen(ch_src.dlt_dc) != 0) {
          SEP_MODE = SRC_dRA_dDEC;
          POS_MODE = SRC_POS1;
        } else if (strlen(ch_src.posang) != 0 && strlen(ch_src.sepang) != 0) {
          SEP_MODE = SRC_dRA_dDEC;
          POS_MODE = SRC_POS2;
        }
      }
    }
  }

  SRCPROC_MODE = out_src_proc(SEP_MODE, POS_MODE);
  source_position(src, &pair_src, &ch_src, SEP_MODE, POS_MODE);

  for (i=0; i<NSRCPROC; i++) {
    srcproc_flag[i] = OFF;
  }
  srcproc_flag[SRCPROC_MODE] = ON;

/*
-----------------------------------------------------
*/

  sprintf(error_source[APOSER], "Antenna Position Error\0");
  sprintf(error_source[TPOSER], "Source-1 Position Error\0");
  sprintf(error_source[RPOSER], "Source-2 Position Error\0");
  sprintf(error_source[EOPERR], "EOP error\0");
  sprintf(error_source[TDSECZ], "Trospospheric Error\0");
  sprintf(error_source[IDSECZ], "Ionospheric Error\0");
  sprintf(error_source[TWVTRB], "Water Vapor Turbulence\0");
  sprintf(error_source[IONTRB], "TEC Turbulence\0");
  sprintf(error_source[THRMNS], "Thermal Noise Error\0");
  sprintf(error_source[FQSERR], "Frequency Standard Error\0");
  sprintf(error_source[LOPOFS], "L-O Phase Offset\0");
  sprintf(error_source[AMPERR], "Antenna Gain Bias Error\0");
  sprintf(srtaer,               "SRT Attitude Error\0");

  sprintf(error_source[ERROR_MENU_NUM],   "ALL ON\0");
  sprintf(error_source[ERROR_MENU_NUM+1], "ALL OFF\0");

/*
-------------------------------------------
*/

  array_id[ 0] = NO_ANT;
  array_id[ 1] = VLBA;
  array_id[ 2] = EVN;
  array_id[ 3] = HSA;
  array_id[ 4] = VERA;
  array_id[ 5] = JVN;
  array_id[ 6] = KVN;
  array_id[ 7] = LBA;
  array_id[ 8] = KAVA;
  array_id[ 9] = ALMA;
  array_id[10] = ACA;
  array_id[11] = EALMA;
  sprintf(array_name[ 0], "RESET\0");
  sprintf(array_name[ 1], "VLBA\0");
  sprintf(array_name[ 2], "EVN\0");
  sprintf(array_name[ 3], "HSA\0");
  sprintf(array_name[ 4], "VERA\0");
  sprintf(array_name[ 5], "JVN\0");
  sprintf(array_name[ 6], "KVN\0");
  sprintf(array_name[ 7], "LBA\0");
  sprintf(array_name[ 8], "KERA\0");
  sprintf(array_name[ 9], "ALMA\0");
  sprintf(array_name[10], "ACA\0");
  sprintf(array_name[11], "EALMA\0");
  array_flag[ 0] = OFF;
  array_flag[ 1] = OFF;
  array_flag[ 2] = OFF;
  array_flag[ 3] = OFF;
  array_flag[ 4] = OFF;
  array_flag[ 5] = OFF;
  array_flag[ 6] = OFF;
  array_flag[ 7] = OFF;
  array_flag[ 8] = OFF;
  array_flag[ 9] = OFF;
  array_flag[10] = OFF;
  array_flag[11] = OFF;
  ARRAY_NUM = 12;

/*
-------------------------------------------
*/

  sprintf(srcproc_name[0], "R.A.-DEC.\0");
  sprintf(srcproc_name[1], "\\gDR.A.-\\gDDEC.\0");
  sprintf(srcproc_name[2], "\\gD\\gh-P.A.\0");

  sprintf(srcproc_name[3], "Source-1 Position\0");
  sprintf(srcproc_name[4], "MID Point\0");

/*
-------------------------------------------
*/

  if (TV_SWT == OFF) {
    START_FLAG = ON;

    printf("---- ERROR PROC MODE ----\n");
    for (i=0; i<ERROR_MENU_NUM; i++) {
      printf("%2d. %s\n", i+1, error_source[i]);
    }
    printf("---- Current ERROR FLAG Status : ");
    for (i=0; i<ERROR_MENU_NUM; i++) {
      printf("%1d", ERROR_FLAG[i]);
    }
    printf("\n");
    printf("Input ERROR FLAG: ");
    if (fgets(string, nstr, stdin) == NULL) {
      printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
      free (antenna_ufl);
      return (-1);
    }
    for (i=0; i<ERROR_MENU_NUM; i++) {
      if (string[i] == '1') {
        ERROR_FLAG[i] = ON;
      } else if (string[i] == '0') {
        ERROR_FLAG[i] = OFF;
      } else if (string[i] == '-') {
        ERROR_FLAG[i] = ERROR_FLAG[i];
      } else if (string[i] == '\n') {
        break;
      }
    }
    printf("---- New ERROR FLAG Status : ");
    for (i=0; i<ERROR_MENU_NUM; i++) {
      printf("%1d", ERROR_FLAG[i]);
    }
    printf("\n");

/*
------------------------------
*/

    printf("Which input type for the source positions?\n");
    in__src_proc(SRCPROC_MODE, &SEP_MODE, &POS_MODE);
    printf("1. R.A.       -   DEC.\n");
    printf("2. Delta_R.A. -   Delta_DEC.\n");
    printf("3. Sep_ang    -   P.A.\n");
    printf("(CR->%d)\n", SEP_MODE + 1);
    while (1) {
      printf("Input number: ");
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == '\n') {
        break;
      } else {
        sscanf(string, "%d", &i);
        if        (i == 1) {
          SEP_MODE = SRC__RA__DEC;
          break;
        } else if (i == 2) {
          SEP_MODE = SRC_dRA_dDEC;
          break;
        } else if (i == 3) {
          SEP_MODE = SRC_SEP_POSA;
          break;
        }
      }
    }

    if (SEP_MODE == SRC_dRA_dDEC || SEP_MODE == SRC_SEP_POSA) {
      printf("Which position for the input?\n");
      printf("1. Source-1 Position\n");
      printf("2. MID Point\n");
      printf("(CR->%d)\n", POS_MODE + 1);
      while (1) {
        printf("Input number: ");
        if (fgets(string, nstr, stdin) == NULL) {
          printf("ERROR: OBS_PARAM_INPUT : Input may have a problem.\n");
          free (antenna_ufl);
          return (-1);
        }
        if (string[0] == '\n') {
          break;
        } else {
          sscanf(string, "%d", &i);
          if        (i == 1) {
            POS_MODE = SRC_POS1;
            break;
          } else if (i == 2) {
            POS_MODE = SRC_POS2;
            break;
          } else {
            printf("Invalid number as an input type. Select again: ");
          }
        }
      }
    }
    SRCPROC_MODE = out_src_proc(SEP_MODE, POS_MODE);

/*
------------------------------
*/

    if (SRCPROC_MODE == SRCPROC1 || SRCPROC_MODE == SRCPROC2) {
      printf("**** Source-1 (J2000) ****\n");
      printf("Input RA (CR->%s) : ", ch_src.tgt_ra);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.tgt_ra, string);
      }
      printf("Input DEC(CR->%s) : ", ch_src.tgt_dc);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.tgt_dc, string);
      }
      input_star_position(ch_src.tgt_ra, ch_src.tgt_dc,
                          &src[0].RA2k, &src[0].DC2k);

      printf("**** Source-2 (J2000) ****\n");
      printf("Input RA (CR->%s) : ", ch_src.ref_ra);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.ref_ra, string);
      }
      printf("Input DEC(CR->%s) : ", ch_src.ref_dc);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.ref_dc, string);
      }
      input_star_position(ch_src.ref_ra, ch_src.ref_dc,
                          &src[1].RA2k, &src[1].DC2k);

    } else if (SRCPROC_MODE == SRCPROC3) {
      printf("**** Source-1 (J2000) ****\n");
      printf("Input RA (CR->%s) : ", ch_src.tgt_ra);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.tgt_ra, string);
      }
      printf("Input DEC(CR->%s) : ", ch_src.tgt_dc);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.tgt_dc, string);
      }
      input_star_position(ch_src.tgt_ra, ch_src.tgt_dc,
                          &src[0].RA2k, &src[0].DC2k);

      printf("Separation Angle (RA) [deg] (CR->%lf) : ", pair_src.dlt_ra);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == '\n') {
        sprintf(ch_src.dlt_ra, "%lf\0", pair_src.dlt_ra);
      } else {
        char_copy(ch_src.dlt_ra, string);
      }

      printf("Separation Angle (DC) [deg] (CR->%lf) : ", pair_src.dlt_dc);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == '\n') {
        sprintf(ch_src.dlt_dc, "%lf\0", pair_src.dlt_dc);
      } else {
        char_copy(ch_src.dlt_dc, string);
      }

    } else if (SRCPROC_MODE == SRCPROC4) {
      printf("**** MID-POTINT OF SOURCES (J2000) ****\n");
      printf("Input RA (CR->%s) : ", ch_src.mid_ra);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.mid_ra, string);
      }

      printf("Input DEC (CR->%s) : ", ch_src.mid_dc);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.mid_dc, string);
      }

      input_star_position(ch_src.mid_ra, ch_src.mid_dc,
                          &pair_src.mid_ra, &pair_src.mid_dc);

      printf("Separation Angle (RA) [deg] (CR->%lf) : ", pair_src.dlt_ra);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == '\n') {
        sprintf(ch_src.dlt_ra, "%lf\0", pair_src.dlt_ra);
      } else {
        char_copy(ch_src.dlt_ra, string);
      }

      printf("Separation Angle (DC) [deg] (CR->%lf) : ", pair_src.dlt_dc);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == '\n') {
        sprintf(ch_src.dlt_dc, "%lf\0", pair_src.dlt_dc);
      } else {
        char_copy(ch_src.dlt_dc, string);
      }

    } else if (SRCPROC_MODE == SRCPROC5) {
      printf("**** Source-1 (J2000) ****\n");
      printf("Input RA (CR->%s) : ", ch_src.tgt_ra);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.tgt_ra, string);
      }
      printf("Input DEC(CR->%s) : ", ch_src.tgt_dc);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.tgt_dc, string);
      }
      input_star_position(ch_src.tgt_ra, ch_src.tgt_dc,
                          &src[0].RA2k, &src[0].DC2k);

      printf("Separation Angle [deg] (CR->%lf) : ", pair_src.sepang);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == '\n') {
        sprintf(ch_src.sepang, "%lf\0", pair_src.sepang);
      } else {
        char_copy(ch_src.sepang, string);
      }

      printf("Position Angle   [deg] (CR->%lf) : ", pair_src.posang);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == '\n') {
        sprintf(ch_src.posang, "%lf\0", pair_src.posang);
      } else {
        char_copy(ch_src.posang, string);
      }

    } else if (SRCPROC_MODE == SRCPROC6) {
      printf("**** MID-POTINT OF SOURCES (J2000) ****\n");
      printf("Input RA (CR->%s) : ", ch_src.mid_ra);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.mid_ra, string);
      }

      printf("Input DEC (CR->%s) : ", ch_src.mid_dc);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        char_copy(ch_src.mid_dc, string);
      }

      input_star_position(ch_src.mid_ra, ch_src.mid_dc,
                          &pair_src.mid_ra, &pair_src.mid_dc);

      printf("Separation Angle [deg] (CR->%lf) : ", pair_src.sepang);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == '\n') {
        sprintf(ch_src.sepang, "%lf\0", pair_src.sepang);
      } else {
        char_copy(ch_src.sepang, string);
      }

      printf("Position Angle   [deg] (CR->%lf) : ", pair_src.posang);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == '\n') {
        sprintf(ch_src.posang, "%lf\0", pair_src.posang);
      } else {
        char_copy(ch_src.posang, string);
      }
    }
    source_position(src, &pair_src, &ch_src, SEP_MODE, POS_MODE);
    printf("Separation Angle [deg]: %s\n", ch_src.sepang);

/*
------------------------------
*/

    printf("Input Observation Date (YYYYMMDD) (CR->%4s%2s%2s) : ",
            ch_obs_t.start_t[0], ch_obs_t.start_t[1], ch_obs_t.start_t[2]);
    if (fgets(string, nstr, stdin) == NULL) {
      printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
      free (antenna_ufl);
      return (-1);
    }
    if (string[0] != '\n') {
      char_ncopy(ch_obs_t.start_t[0], string,   4);
      char_ncopy(ch_obs_t.start_t[1], string+4, 2);
      char_ncopy(ch_obs_t.start_t[2], string+6, 2);
    }

    printf("Input Start UTC (hhmmss) (CR->%s%s%s) : ",
            ch_obs_t.start_t[3], ch_obs_t.start_t[4], ch_obs_t.start_t[5]);
    if (fgets(string, nstr, stdin) == NULL) {
      printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
      free (antenna_ufl);
      return (-1);
    }
    if (string[0] != '\n') {
      char_ncopy(ch_obs_t.start_t[3], string,   2);
      char_ncopy(ch_obs_t.start_t[4], string+2, 2);
      char_ncopy(ch_obs_t.start_t[5], string+4, 2);
    }

    printf("Observing Duration [hour] (CR->%s) : ", ch_obs_t.obsd);
    if (fgets(string, nstr, stdin) == NULL) {
      printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
      free (antenna_ufl);
      return (-1);
    }
    if (string[0] != '\n') {
      char_copy(ch_obs_t.obsd, string);
      sscanf(ch_obs_t.obsd, "%lf", obs_duration);
    }

/*
------------------------------
*/

    while (1) {
      printf("GRT MINIMUM elevation (CR->%s [deg]) : ", ch_grt_el_lim);
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] != '\n') {
        sscanf(string, "%lf", grt_elevation_limit);
        char_copy(ch_grt_el_lim, string);
        if (*grt_elevation_limit < 5.0) {
          printf("WARNING: The lowest elevation angle must be above 5 deg.\n");
          printf("WARNING: Limit elevation is set to 5 deg.\n");
          *grt_elevation_limit = 5.0;
          sprintf(ch_grt_el_lim, "5.0\0");
          break;
        } else if (*grt_elevation_limit >= 90.0) {
          printf("WARNING: Wrong number for the limit elevation.\n");
        } else {
          break;
        }
      } else {
        break;
      }
    }

/*
------------------------------
*/

    printf("\n");
    while (1) {
      printf("SELECTED Antennas:\n");
      for (i=0; i<*GRT_NUM; i++) {
        if (antenna_ufl[i] == ON) {
          printf("%2d. %s", i+1, ant_prm[i].IDC);
          k = strlen(ant_prm[i].IDC);
          if (k > 10) {
            k = 10;
          }
          for (j=0; j<11-k; j++) {
            printf(" ");
          }
          if (i % 5 == 4) {
            printf("\n");
          }
        } else {
          printf("%2d.            ", i+1);
          if (i % 5 == 4) {
            printf("\n");
          }
        }
      }
      printf("\n");

      printf("Array List:\n");
      for (i=0; i<ARRAY_NUM; i++) {
        string[0] = ' ';
        string[1] = 'a' + i;
        string[2] = 0;

        printf("%s. %s", string, array_name[i]);
        k = strlen(array_name[i]);
        if (k > 10) {
          k = 10;
        }
        for (j=0; j<11-k; j++) {
          printf(" ");
        }
        if (i % 5 == 4) {
          printf("\n");
        }
      }
      printf("\n");

      printf("Antenna List:\n");
      for (i=0; i<*GRT_NUM; i++) {
        if (antenna_ufl[i] == OFF) {
          printf("%2d. %s", i+1, ant_prm[i].IDC);
          k = strlen(ant_prm[i].IDC);
          if (k > 10) {
            k = 10;
          }
          for (j=0; j<11-k; j++) {
            printf(" ");
          }
          if (i % 5 == 4) {
            printf("\n");
          }
        } else {
          printf("%2d.            ", i+1);
          if (i % 5 == 4) {
            printf("\n");
          }
        }
      }
      printf("\n");

      printf("Input array character or antenna number (0 or CR->Exit) : ");
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }

      if (string[0] == '0' || string[0] == '\n') {
        break;
      } else if (string[0] >= 'a' && string[0] <= 'a' + ARRAY_NUM) {
        *ARRAY_ID = string[0] - 'a';
        if (*ARRAY_ID == ACA) {
          break;
        } else if (*ARRAY_ID == 0) {
          for (i=0; i<*GRT_NUM; i++) {
            antenna_ufl[i] = OFF;
          }
        } else {
          for (i=0; i<*GRT_NUM; i++) {
            if (ant_prm[i].ARRAY == *ARRAY_ID) {
              antenna_ufl[i] = ON;
            }
          }
        }
      } else {
        sscanf(string, "%d", &k);
        k--;
        if (antenna_ufl[k] == OFF) {
          antenna_ufl[k] = ON;
        } else if (antenna_ufl[k] == ON) {
          antenna_ufl[k] = OFF;
        }
      }
    }

    for (i=0; i<*GRT_NUM; i++) {
      if (antenna_ufl[i] == ON) {
        ant_prm[i].UFL = ON;
      } else {
        ant_prm[i].UFL = OFF;
      }
    }

/*
------------------------------
*/

    if (*ARRAY_ID != ACA) {
      idum = *SRT_NUM;
      while (1) {
        printf("How many space telescopes [0-%d] (CR->%d) : ",
               SRTMAX, *SRT_NUM);
        if (fgets(string, nstr, stdin) == NULL) {
          printf(
            "ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
          free (antenna_ufl);
          return (-1);
        }
        if (string[0] != '\n') {
          sscanf(string, "%d", &idum);
        }
        if (idum < 0 || idum > SRTMAX) {
          printf("Input the number btween 0 and %d: ", SRTMAX);
        } else {
          break;
        }
      }
      *SRT_NUM = idum;
    }

    if (*SRT_NUM > 0) {
      if (ERROR_FLAG[SRTAER] == ON) {
        printf("SRT pointing error (y/n; CR->y) : ");
      } else {
        printf("SRT pointing error (y/n; CR->n) : ");
      }
      if (fgets(string, nstr, stdin) == NULL) {
        printf("ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
        free (antenna_ufl);
        return (-1);
      }
      if (string[0] == 'y') {
        ERROR_FLAG[SRTAER] = ON;
      } else if (string[0] == 'n') {
        ERROR_FLAG[SRTAER] = OFF;
      }

      for (i=0; i<*SRT_NUM; i++) {
        printf("Input orbit parameters for SRT %d\n", i + 1);
        printf("Apogee altitude  [km] (CR->%s km) : ", ch_srt[i].apo);
        if (fgets(string, nstr, stdin) == NULL) {
          printf(
            "ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
          free (antenna_ufl);
          return (-1);
        }
        if (string[0] != '\n') {
          char_copy(ch_srt[i].apo, string);
        }

        printf("Perigee altitude [km] (CR->%s km) : ", ch_srt[i].per);
        if (fgets(string, nstr, stdin) == NULL) {
          printf(
            "ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
          free (antenna_ufl);
          return (-1);
        }
        if (string[0] != '\n') {
          char_copy(ch_srt[i].per, string);
        }

        printf("Inclination     [deg] (CR->%s deg) : ", ch_srt[i].inc);
        if (fgets(string, nstr, stdin) == NULL) {
          printf(
            "ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
          free (antenna_ufl);
          return (-1);
        }
        if (string[0] != '\n') {
          char_copy(ch_srt[i].inc, string);
        }

        printf("Omega           [deg] (CR->%s deg) : ", ch_srt[i].OMG);
        if (fgets(string, nstr, stdin) == NULL) {
          printf(
            "ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
          free (antenna_ufl);
          return (-1);
        }
        if (string[0] != '\n') {
          char_copy(ch_srt[i].OMG, string);
        }

        printf("omega           [deg] (CR->%s deg) : ", ch_srt[i].omg);
        if (fgets(string, nstr, stdin) == NULL) {
          printf(
            "ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
          free (antenna_ufl);
          return (-1);
        }
        if (string[0] != '\n') {
          char_copy(ch_srt[i].omg, string);
        }

        printf("time of the passage at perigee (YYYYMMDDhhmmss)\n");
        printf("(CR->%s) : ", ch_srt[i].t_0); 
        if (fgets(string, nstr, stdin) == NULL) {
          printf(
            "ERROR: OBS_PARAM_INPUT : Standar Input may have a problem.\n");
          free (antenna_ufl);
          return (-1);
        }
        if (string[0] != '\n') {
          char_copy(ch_srt[i].t_0, string);
        }
      }
    }

/*
============================================================
*/

  } else if (TV_SWT == ON) {

    cpgslct(pgid[0]);
    cpgpap(2.00*pgpap_prm, 1.0/1.4);
    cpgsch(1.5*pgpap_prm/13.0);
    cpgsvp(0.0,  1.0, 0.0, 1.0);
    cpgswin(0.0, 1.4, 0.0, 1.0);
    comment_init(cmnt, comment, ON);

/*
-----
*/

    y_pos = 0.21;

    I = 0;
    bttn_box[I][0] = 0.02;
    bttn_box[I][1] = 0.20;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "START\0", bttn_box[I]);

    I = 1;
    bttn_box[I][0] = 0.26;
    bttn_box[I][1] = 0.44;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "ANTENNA VISIBILITY\0", bttn_box[I]);

    I = 2;
    bttn_box[I][0] = 0.45;
    bttn_box[I][1] = 0.63;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "PHASE SCREEN\0", bttn_box[I]);

    I = 3;
    bttn_box[I][0] = 0.80;
    bttn_box[I][1] = 0.98;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "EXIT\0", bttn_box[I]);

/*
-----
*/

    y_pos = 0.910;

    cpgsci(1);
    cpgsfs(2);
    cpgrect(0.010, 1.400, y_pos-0.040, y_pos+0.080);
    cpgsfs(1);

    for (i=0; i<ERROR_MENU_NUM; i++) {
      I = ERROR_SECTION + i;
      bttn_box[I][0] = 0.020 + 0.229 * (float)(i % 6);
      bttn_box[I][1] = 0.246 + 0.229 * (float)(i % 6);
      bttn_box[I][2] = y_pos - 0.033 * (float)(i / 6);
      bttn_box[I][3] = bttn_box[I][2] + pitch;
    }
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM  ][0] = 0.02;
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM  ][1] = 0.32;
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM  ][2] = y_pos + 0.040;
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM  ][3] = y_pos + 0.040 + pitch;

    bttn_box[ERROR_SECTION+ERROR_MENU_NUM+1][0] =
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM  ][0] + 0.33;
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM+1][1] =
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM  ][1] + 0.33;
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM+1][2] =
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM  ][2];
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM+1][3] =
    bttn_box[ERROR_SECTION+ERROR_MENU_NUM  ][3];

    for (i=0; i<ERROR_MENU_NUM; i++) {
      I = ERROR_SECTION + i;
      if (ERROR_FLAG[i] == ON) {
        on_button(&ALL_ERROR_FLAG, error_source[i], bttn_box[I]);
      } else if (ERROR_FLAG[i] == OFF) {
        off_button(&ALL_ERROR_FLAG, error_source[i], bttn_box[I]);
      }
    }
    for (i=ERROR_MENU_NUM; i<ERROR_MENU_NUM+2; i++) {
      I = ERROR_SECTION + i;
      off_button(&ALL_ERROR_FLAG, error_source[i], bttn_box[I]);
    }

/*
----
*/

    y_pos -= ((float)(ERROR_MENU_NUM / 6) * 0.030 + 0.008);

    cpgsci(1);
    cpgsfs(2);
    cpgrect(0.010, 1.400, y_pos-0.111, y_pos+0.020);
    cpgsfs(1);

    in__src_proc(SRCPROC_MODE, &SEP_MODE, &POS_MODE);
    for (i=0; i<BASIC_SEP_MODE; i++) {
      I = SRCPROC_SECTION + i;
      bttn_box[I][0] = 0.02 + 0.2 * (float)i;
      bttn_box[I][1] = 0.03 + 0.2 * (float)i;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = y_pos + 0.01;
      if (i == SEP_MODE) {
        on_button( &srcproc_flag[i], "", bttn_box[I]);
      } else {
        off_button(&srcproc_flag[i], "", bttn_box[I]);
      }
      cpgsci(1);
      cpgtext(bttn_box[I][0]+0.02, y_pos, srcproc_name[i]);
    }
    y_pos -= 0.020;
    for (i=0; i<2; i++) {
      I = SRCPROC_SECTION + BASIC_SEP_MODE + i;
      bttn_box[I][0] = 0.02 + 0.2 * (float)i;
      bttn_box[I][1] = 0.03 + 0.2 * (float)i;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = y_pos + 0.01;
    }

/****
  SRCPROC_MODE = 0;
  SEP_MODE = 0;
  POS_MODE = 0;
****/

    if (SEP_MODE == SRC_dRA_dDEC || SEP_MODE == SRC_SEP_POSA) {
      if (       POS_MODE == SRC_POS1) {
        I = SRCPROC_SECTION + BASIC_SEP_MODE;
        on_button (&srcproc_flag[BASIC_SEP_MODE], "", bttn_box[I]);
        cpgsci(1);
        cpgtext(bttn_box[I][0]+0.02, y_pos, srcproc_name[BASIC_SEP_MODE]);
        I++;
        off_button(&srcproc_flag[BASIC_SEP_MODE+1], "", bttn_box[I]);
        cpgsci(1);
        cpgtext(bttn_box[I][0]+0.02, y_pos, srcproc_name[BASIC_SEP_MODE+1]);
      } else if (POS_MODE == SRC_POS2) {
        I = SRCPROC_SECTION + BASIC_SEP_MODE;
        off_button(&srcproc_flag[BASIC_SEP_MODE], "", bttn_box[I]);
        cpgsci(1);
        cpgtext(bttn_box[I][0]+0.02, y_pos, srcproc_name[BASIC_SEP_MODE]);
        I++;
        on_button (&srcproc_flag[BASIC_SEP_MODE+1], "", bttn_box[I]);
        cpgsci(1);
        cpgtext(bttn_box[I][0]+0.02, y_pos, srcproc_name[BASIC_SEP_MODE+1]);
      }
    }

/*
--------
*/

    source_y_pos = y_pos - 0.045;
    sprintf(string, "Separation Angle [deg]: %5.2lf\0",
            sepang(src[0].s2k, src[1].s2k) * 180.0 / dpi);
    source_info_disp(SEP_MODE, POS_MODE, pitch,  &bttn_box[SOURCE_SECTION],
                     source_y_pos,   &ch_src);

/*
----
*/

/****
    y_pos = source_y_pos - 0.100;
    y_pos = source_y_pos - 0.085;
****/
    y_pos = source_y_pos - 0.095;

    cpgsci(1);
    cpgsfs(2);
    cpgrect(0.010, 1.400, y_pos-0.005, y_pos+0.040);
    cpgsfs(1);

    I = TIME_SECTION;
    bttn_box[I][0] = 0.21;
    bttn_box[I][1] = 0.28;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgsci(1);
    cpgptxt(bttn_box[I][0], text_bottom(bttn_box[I][2], bttn_box[I][3]),
            0.0, 1.05, "Obs Date (YYYYMMDD)");
    tv_button_disp(bttn_box[I], ch_obs_t.start_t[0]);
    I++;

    bttn_box[I][0] = 0.29;
    bttn_box[I][1] = 0.34;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgsci(1);
    tv_button_disp(bttn_box[I], ch_obs_t.start_t[1]);
    I++;

    bttn_box[I][0] = 0.35;
    bttn_box[I][1] = 0.40;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgsci(1);
    tv_button_disp(bttn_box[I], ch_obs_t.start_t[2]);
    I++;

    bttn_box[I][0] = 0.60;
    bttn_box[I][1] = 0.65;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgsci(1);
    cpgptxt(bttn_box[I][0], text_bottom(bttn_box[I][2], bttn_box[I][3]),
            0.0, 1.05, "Start UTC (hhmmss)");
    tv_button_disp(bttn_box[I],  ch_obs_t.start_t[3]);
    cpgsci(1);
    I++;

    bttn_box[I][0] = 0.66;
    bttn_box[I][1] = 0.71;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgsci(1);
    tv_button_disp(bttn_box[I],  ch_obs_t.start_t[4]);
    cpgsci(1);
    I++;

    bttn_box[I][0] = 0.72;
    bttn_box[I][1] = 0.77;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgsci(1);
    tv_button_disp(bttn_box[I],  ch_obs_t.start_t[5]);
    cpgsci(1);
    I++;

    bttn_box[I][0] = 0.96;
    bttn_box[I][1] = 1.03;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgsci(1);
    cpgptxt(bttn_box[I][0], text_bottom(bttn_box[I][2], bttn_box[I][3]),
            0.0, 1.05, "Obs Duration [h]");
    tv_button_disp(bttn_box[I], ch_obs_t.obsd);
    cpgsci(1);
    I++;

/*
----
*/

    I = GRT_SECTION;
    bttn_box[I][0] = 1.29;
    bttn_box[I][1] = 1.37;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgsci(1);
    cpgptxt(bttn_box[I][0], text_bottom(bttn_box[I][2], bttn_box[I][3]),
            0.0, 1.05, "GRT Elevation Limit [deg]");
    tv_button_disp(bttn_box[I], ch_grt_el_lim);
    cpgsci(1);

/*
----
*/

    y_pos -= 0.070;
    cpgsci(8);
    cpgptxt(0.025, y_pos+1.2*pitch,
            0.0, 0.0, "Antenna list: ./aris_input/antenna.prm\0");
    cpgsci(1);

    SRT_SWT = OFF;
    I = ARRAY_SECTION;
    for (i=0; i<ARRAY_NUM; i++) {
      I = ARRAY_SECTION + i;
      bttn_box[I][0] = 0.020 + 0.075 * (float)i;
      bttn_box[I][1] = 0.090 + 0.075 * (float)i;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
    }

    for (i=0; i<ARRAY_NUM; i++) {
      array_flag[i] = OFF;
      I = ARRAY_SECTION + i;
      off_button(&array_flag[i], array_name[i], bttn_box[I]);
    }

/*
----
*/

    y_pos -= 0.035;

    for (i=0; i<*GRT_NUM; i++) {
      I = ANTENNA_SECTION + i;
      bttn_box[I][0] = 0.023 + 0.097 * (float)(i % 14);
      bttn_box[I][1] = 0.120 + 0.097 * (float)(i % 14);
      bttn_box[I][2] = y_pos - pitch * (float)(i / 14);
      bttn_box[I][3] = bttn_box[I][2] + pitch;
    }
    for (i=0; i<*GRT_NUM; i++) {
      I = ANTENNA_SECTION + i;
      if (antenna_ufl[i] == ON) {
        on_button(&ant_prm[i].UFL, &ant_prm[i].IDC[0], bttn_box[I]);
      } else {
        off_button(&ant_prm[i].UFL, &ant_prm[i].IDC[0], bttn_box[I]);
      }
    }

    cpgsci(1);
    cpgsfs(2);
    cpgrect(0.010, 1.400,
            bttn_box[ARRAY_SECTION][3]+0.025,
            bttn_box[ANTENNA_SECTION+*GRT_NUM-1][3]-pitch-0.007);
    cpgsci(1);
    cpgsfs(1);

/*
----
*/

    if (*ARRAY_ID == ACA) {
      SRT_SWT = OFF;
    } else {
      SRT_SWT = ON;
    }

/*
----
*/

    I = ANTENNA_SECTION + *GRT_NUM;
    bttn_box[I][0] = 0.195;
    bttn_box[I][1] = 0.255;
    bttn_box[I][2] = bttn_box[I - 1][2] - 0.05;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    if (SRT_SWT == ON) {
      sprintf(string, "SRT Number (0-%d)", SRTMAX);
      cpgsci(1);
      cpgtext(0.02, text_bottom(bttn_box[I][2], bttn_box[I][3]), string);
      sprintf(string, "%d\0", *SRT_NUM);
      tv_button_disp(bttn_box[I], string);
    }

/*
----
*/

    srt_info_disp(*SRT_NUM,  pitch, &bttn_box[SRT_SECTION],
                  bttn_box[ANTENNA_SECTION + *GRT_NUM][2],
                  srtaer, &ERROR_FLAG[SRTAER], ch_srt);

/*
----
*/

    sprintf(string,
     "ARIS: Observation Parameter Setup --GRAPHICAL USER INTERFACE MODE--\0");
    comment_disp(cmnt, comment, string, ON);
    sprintf(string, "Welcome!! Please set the observing parameters.\0");
    comment_disp(cmnt, comment, string, ON);

/*
----
*/

    cursor_pos[0] = 0.5 * (bttn_box[0][0] + bttn_box[0][1]);
    cursor_pos[1] = 0.5 * (bttn_box[0][2] + bttn_box[0][3]);

    while (1) {

      cpgcurs(cursor_pos, cursor_pos+1, string);

/*
---------------------------------
*/

      if (button_chk(cursor_pos, bttn_box[0]) == ON) {
        I = 0;
        on_button(&idum, "START\0", bttn_box[I]);
        START_FLAG = ON;
        break;
      }

      if (button_chk(cursor_pos, bttn_box[1]) == ON) {
        I = 1;
        on_button(&idum, "ANTENNA VISIBILITY\0", bttn_box[I]);
        START_FLAG = OFF;

        if (obs_param_set(ERROR_FLAG, ARRAY_ID,
                          ANT_NUM,  GRT_NUM,  SRT_NUM, ch_srt, srt,
                          ch_grt_el_lim, grt_elevation_limit,
                          sep_angle_limit_from_earth_limb,
                          &ch_obs_t, TimUTC, UT1_UTC,
                          obs_duration, SRCPROC_MODE,
                          &ch_src, &pair_src, src, sun) == -1) {
          printf("WARNING: OBS_PARAMETER_INPUT: SUN ANGLE CHECK.\n");
        }
        obs_param_file_io(ERROR_FLAG,
                          ARRAY_ID, ANT_NUM, GRT_NUM, SRT_NUM,
                          srt, grt_elevation_limit,
                          sep_angle_limit_from_earth_limb,
                          TimUTC, UT1_UTC, obs_duration,
                          antenna_ufl, &SRCPROC_MODE, src, sun, ant_prm,
                          ch_grt_el_lim, &pair_src, &ch_src,
                          ch_srt, &ch_obs_t, 1);
        return (ANT_VIS);
      }

      if (button_chk(cursor_pos, bttn_box[2]) == ON) {
        I = 2;
        on_button(&idum, "PHASE SCREEN\0", bttn_box[I]);
        START_FLAG = OFF;
        return (PHS_SCR);
      }

      if (button_chk(cursor_pos, bttn_box[3]) == ON) {
        I = 3;
        on_button(&idum, "EXIT\0", bttn_box[I]);
        START_FLAG = OFF;
        break;
      }

/*
---------------------------------
*/

      for (i=0; i<ERROR_MENU_NUM+2; i++) {
        I = ERROR_SECTION + i;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          if (i < ERROR_MENU_NUM) {
            toggle_button(&ERROR_FLAG[i], error_source[i], bttn_box[I]);
            break;
          } else if (i == ERROR_MENU_NUM) {
            for (j=0; j<ERROR_MENU_NUM; j++) {
              J = ERROR_SECTION + j;
              on_button(&ERROR_FLAG[j], error_source[j], bttn_box[J]);
            }
            break;
          } else if (i == ERROR_MENU_NUM+1) {
            for (j=0; j<ERROR_MENU_NUM; j++) {
              J = ERROR_SECTION + j;
              off_button(&ERROR_FLAG[j], error_source[j], bttn_box[J]);
            }
            break;
          }
        }
      }

/*
-----------------------------------------
*/

      SRCPROC_SWT = OFF;
      for (i=0; i<3; i++) {
        I = SRCPROC_SECTION + i;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          SEP_MODE = i;
          SRCPROC_SWT = ON;
          break;
        }
      }

      if (SEP_MODE == SRC_dRA_dDEC || SEP_MODE == SRC_SEP_POSA) {
        for (i=0; i<2; i++) {
          I = SRCPROC_SECTION + BASIC_SEP_MODE + i;
          if (button_chk(cursor_pos, bttn_box[I]) == ON) {
            POS_MODE = i;
            SRCPROC_SWT = ON;
          }
        }
      }

      if (SRCPROC_SWT == ON) {
        for (i=0; i<3; i++) {
          I = SRCPROC_SECTION + i;
          if (i == SEP_MODE) {
            on_button( &srcproc_flag[i], "", bttn_box[I]);
          } else {
            off_button(&srcproc_flag[i], "", bttn_box[I]);
          }
        }

        y_pos = source_y_pos + 0.045;
        if (SEP_MODE == SRC__RA__DEC) {
          TV_menu_hatch(0.010, 0.550, y_pos, y_pos+0.012, 0, 1);
        } else {
          if (       POS_MODE == SRC_POS1) {
            I = SRCPROC_SECTION + BASIC_SEP_MODE;
            on_button (&srcproc_flag[BASIC_SEP_MODE], "", bttn_box[I]);
            cpgsci(1);
            cpgtext(bttn_box[I][0]+0.02, y_pos, srcproc_name[BASIC_SEP_MODE]);
            I++;
            off_button(&srcproc_flag[BASIC_SEP_MODE+1], "", bttn_box[I]);
            cpgsci(1);
            cpgtext(bttn_box[I][0]+0.02, y_pos, srcproc_name[BASIC_SEP_MODE+1]);
          } else if (POS_MODE == SRC_POS2) {
            I = SRCPROC_SECTION + BASIC_SEP_MODE;
            off_button(&srcproc_flag[BASIC_SEP_MODE], "", bttn_box[I]);
            cpgsci(1);
            cpgtext(bttn_box[I][0]+0.02, y_pos, srcproc_name[BASIC_SEP_MODE]);
            I++;
            on_button (&srcproc_flag[BASIC_SEP_MODE+1], "", bttn_box[I]);
            cpgsci(1);
            cpgtext(bttn_box[I][0]+0.02, y_pos, srcproc_name[BASIC_SEP_MODE+1]);
          }
        }

        SRCPROC_MODE = out_src_proc(SEP_MODE, POS_MODE);
        TV_menu_hatch(0.010, 1.00, bttn_box[SOURCE_SECTION+1][2],
                                  bttn_box[SOURCE_SECTION+2][3], 0, 1);
        source_info_disp(SEP_MODE, POS_MODE, pitch, &bttn_box[SOURCE_SECTION],
                         source_y_pos, &ch_src);
        SRCPROC_SWT = OFF;
      }

/*
-----------------------------------------
*/

      SEPANG_UPDATE = OFF;
      if (button_chk(cursor_pos, bttn_box[I=SOURCE_SECTION]) == ON) {
        if (SEP_MODE == SRC__RA__DEC ||
           (SEP_MODE != SRC__RA__DEC && POS_MODE == SRC_POS1)) {
          char_copy(string, ch_src.tgt_ra);
          tv_get_param("char", cursor_pos, bttn_box[I],
                       pitch, string, 0.0, 0.0);
          char_copy(ch_src.tgt_ra, string);
          str_init(string, nstr);
          input_star_position(ch_src.tgt_ra, ch_src.tgt_dc,
                              &src[0].RA2k, &src[0].DC2k);
        } else {
          char_copy(string, ch_src.mid_ra);
          tv_get_param("char", cursor_pos, bttn_box[I],
                       pitch, string, 0.0, 0.0);
          char_copy(ch_src.mid_ra, string);
          str_init(string, nstr);
          input_star_position(ch_src.mid_ra, ch_src.mid_dc,
                              &pair_src.mid_ra, &pair_src.mid_dc);
        }
        SEPANG_UPDATE = ON;
      }

      if (button_chk(cursor_pos, bttn_box[I=SOURCE_SECTION+1]) == ON) {
        if (SEP_MODE == SRC__RA__DEC ||
           (SEP_MODE != SRC__RA__DEC && POS_MODE == SRC_POS1)) {
          char_copy(string, ch_src.tgt_dc);
          tv_get_param("char", cursor_pos, bttn_box[I],
                       pitch, string, 0.0, 0.0);
          char_copy(ch_src.tgt_dc, string);
          str_init(string, nstr);
          input_star_position(ch_src.tgt_ra, ch_src.tgt_dc,
                              &src[0].RA2k, &src[0].DC2k);
        } else {
          char_copy(string, ch_src.mid_dc);
          tv_get_param("char", cursor_pos, bttn_box[I],
                       pitch, string, 0.0, 0.0);
          char_copy(ch_src.mid_dc, string);
          str_init(string, nstr);
          input_star_position(ch_src.mid_ra, ch_src.mid_dc,
                              &pair_src.mid_ra, &pair_src.mid_dc);
        }
        SEPANG_UPDATE = ON;
      }

      if (button_chk(cursor_pos, bttn_box[I=SOURCE_SECTION+2]) == ON) {
        if (SEP_MODE == SRC__RA__DEC) {
          char_copy(string, ch_src.ref_ra);
          tv_get_param("char", cursor_pos, bttn_box[I],
                       pitch, string, 0.0, 0.0);
          char_copy(ch_src.ref_ra, string);
          str_init(string, nstr);
          input_star_position(ch_src.ref_ra, ch_src.ref_dc,
                              &src[1].RA2k, &src[1].DC2k);
        } else if (SEP_MODE == SRC_dRA_dDEC) {
          tv_get_param("double", cursor_pos, bttn_box[I],
                       pitch, ch_src.dlt_ra, -10.0, 10.0);
          sscanf(ch_src.dlt_ra, "%lf", &pair_src.dlt_ra);
          sprintf(string, "Delta RA is set to %lf [deg].\0", pair_src.dlt_ra);
          comment_disp(cmnt, comment, string, ON);
        } else if (SEP_MODE == SRC_SEP_POSA) {
          tv_get_param("double", cursor_pos, bttn_box[I],
                       pitch, ch_src.sepang, 0.0, 10.0);
          sscanf(ch_src.sepang, "%lf", &pair_src.sepang);
          sprintf(string, "Separation angle is set to %lf [deg].\0",
                  pair_src.sepang);
          comment_disp(cmnt, comment, string, ON);
        }
        SEPANG_UPDATE = ON;
      }

      if (button_chk(cursor_pos, bttn_box[I=SOURCE_SECTION+3]) == ON) {
        if (SEP_MODE == SRC__RA__DEC) {
          char_copy(string, ch_src.ref_dc);
          tv_get_param("double", cursor_pos, bttn_box[I],
                       pitch, string, 0.0, 0.0);
          char_copy(ch_src.ref_dc, string);
          str_init(string, nstr);
          input_star_position(ch_src.ref_ra, ch_src.ref_dc,
                              &src[1].RA2k, &src[1].DC2k);
        } else if (SEP_MODE == SRC_dRA_dDEC) {
          tv_get_param("double", cursor_pos, bttn_box[I],
                       pitch, ch_src.dlt_dc, -10.0, 10.0);
          sscanf(ch_src.dlt_dc, "%lf", &pair_src.dlt_dc);
          sprintf(string, "Delta DEC is set to %lf [deg].\0", pair_src.dlt_dc);
          comment_disp(cmnt, comment, string, ON);
        } else if (SEP_MODE == SRC_SEP_POSA) {
          tv_get_param("double", cursor_pos, bttn_box[I],
                       pitch, ch_src.posang, 0.0, 0.0);
          sscanf(ch_src.posang, "%lf", &pair_src.posang);
          sprintf(string, "Position angle is set to %lf [deg].\0",
                  pair_src.posang);
          comment_disp(cmnt, comment, string, ON);
        }
        SEPANG_UPDATE = ON;
      }

      if (SEPANG_UPDATE == ON) {
        source_position(src, &pair_src, &ch_src, SEP_MODE, POS_MODE);
        source_info_disp(SEP_MODE,  POS_MODE,  pitch,
                         &bttn_box[SOURCE_SECTION], source_y_pos, &ch_src);
        SEPANG_UPDATE = OFF;
      }

/*
-----------------------------------------
*/

      if (button_chk(cursor_pos, bttn_box[I=GRT_SECTION]) == ON) {
        tv_get_param("double", cursor_pos, bttn_box[I],
                     pitch, ch_grt_el_lim, 0.0, 0.0);
        sscanf(ch_grt_el_lim, "%lf", grt_elevation_limit);
        sprintf(string, "GRT minimum elevation is set to %lf [deg].\0",
                *grt_elevation_limit);
        comment_disp(cmnt, comment, string, ON);
      }

/*
-----------------------------------------
*/

      for (i=ARRAY_SECTION; i<ARRAY_SECTION+ARRAY_NUM; i++) {
        if (button_chk(cursor_pos, bttn_box[i]) == ON) {
          I = i - ARRAY_SECTION;
          *ARRAY_ID = array_id[I];
          toggle_button(&array_flag[I], array_name[I], bttn_box[i]);
          if (*ARRAY_ID == NO_ANT) {
            for (j=0; j<ARRAY_NUM; j++) {
              J = ARRAY_SECTION + j;
              off_button(&array_flag[j], array_name[j], bttn_box[J]);
            }
            for (j=0; j<*GRT_NUM; j++) {
              J = ANTENNA_SECTION + j;
              off_button(&ant_prm[j].UFL, &ant_prm[j].IDC[0], bttn_box[J]);
            }
          } else {
            for (j=0; j<*GRT_NUM; j++) {
              idum = array_config(*ARRAY_ID, wave_id, 0, &grt_num,
                                  ant_prm[j].IDC, &ant_prm_tmp, ON,
                                  "aris_input/antenna.prm",     ON);
              J = ANTENNA_SECTION + j;
              if (idum == 1 &&
                  strncmp(ant_prm_tmp.IDC,
                          ant_prm[j].IDC, strlen(ant_prm[j].IDC)) == 0) {
                if (array_flag[I] == ON) {
                  on_button(&ant_prm[j].UFL,  &ant_prm[j].IDC[0], bttn_box[J]);
                } else if (array_flag[I] == OFF) {
                  off_button(&ant_prm[j].UFL, &ant_prm[j].IDC[0], bttn_box[J]);
                }
              }
            }
          }

          if (*ARRAY_ID == ACA) {
            cpgsci(0);
          } else {
            cpgsci(1);
          }
          I = ANTENNA_SECTION + *GRT_NUM;
          sprintf(string, "SRT Number (0-%d)", SRTMAX);
          cpgsci(1);
          cpgtext(0.02, text_bottom(bttn_box[I][2], bttn_box[I][3]), string);
          cpgrect(bttn_box[I][0], bttn_box[I][1],
                  bttn_box[I][2], bttn_box[I][3]);
          if (*ARRAY_ID == ACA) {
            *SRT_NUM = 0;
            SRT_SWT = OFF;
          } else {
            sprintf(string, "%d\0", *SRT_NUM);
            cpgsci(0);
            cpgptxt(bttn_box[I][1] - 0.015,
                    text_bottom(bttn_box[I][2], bttn_box[I][3]),
                    0.0, 1.0, string);
            cpgsci(1);
            SRT_SWT = ON;
          }
        }
      }

      for (i=ANTENNA_SECTION; i<ANTENNA_SECTION+*GRT_NUM; i++) {
        if (button_chk(cursor_pos, bttn_box[i]) == ON) {
          I = i - ANTENNA_SECTION;
          toggle_button(&ant_prm[I].UFL, &ant_prm[I].IDC[0], bttn_box[i]);
        }
      }

      if (button_chk(cursor_pos, bttn_box[ANTENNA_SECTION+*GRT_NUM]) == ON &&
          SRT_SWT == ON) {
        str_init(string, nstr);
        I = ANTENNA_SECTION + *GRT_NUM;
        sprintf(string, "%d\0", *SRT_NUM);
        tv_get_param("int", cursor_pos, bttn_box[I], pitch, string,
                     0.0, (double)SRTMAX);
        sscanf(string, "%d", SRT_NUM);
        str_init(string, nstr);
        TV_menu_hatch(0.250, 1.000, bttn_box[0][3],
                  bttn_box[ANTENNA_SECTION + *GRT_NUM][2] + 0.030, 0, 1);
        TV_menu_hatch(0.010, 0.250, bttn_box[0][3],
                  bttn_box[ANTENNA_SECTION + *GRT_NUM][2] + 0.000, 0, 1);
        if (*SRT_NUM != 0) {
          srt_info_disp(*SRT_NUM,  pitch, &bttn_box[SRT_SECTION],
                        bttn_box[ANTENNA_SECTION + *GRT_NUM][2],
                        srtaer, &ERROR_FLAG[SRTAER], ch_srt);
        }
      }

/*
-----------------------------------------
*/

      if (button_chk(cursor_pos, bttn_box[I=TIME_SECTION  ]) == ON) {
        sprintf(string, "%s\0", ch_obs_t.start_t[0]);
        tv_get_param("char", cursor_pos, bttn_box[I],
                     pitch, string, 0.0, 0.0);
        sprintf(ch_obs_t.start_t[0], "%s\0", string);
        char_ncopy(ch_obs_t.start_t[0], string, 4);
        str_init(string, nstr);
      }

      if (button_chk(cursor_pos, bttn_box[I=TIME_SECTION+1]) == ON) {
        sprintf(string, "%s\0", ch_obs_t.start_t[1]);
        tv_get_param("char", cursor_pos, bttn_box[I],
                     pitch, string, 0.0, 0.0);
        sprintf(ch_obs_t.start_t[1], "%s\0", string);
        char_ncopy(ch_obs_t.start_t[1], string, 2);
        str_init(string, nstr);
      }

      if (button_chk(cursor_pos, bttn_box[I=TIME_SECTION+2]) == ON) {
        sprintf(string, "%s\0", ch_obs_t.start_t[2]);
        tv_get_param("char", cursor_pos, bttn_box[I],
                     pitch, string, 0.0, 0.0);
        sprintf(ch_obs_t.start_t[2], "%s\0", string);
        char_ncopy(ch_obs_t.start_t[2], string, 2);
        str_init(string, nstr);
      }

      if (button_chk(cursor_pos, bttn_box[I=TIME_SECTION+3]) == ON) {
        sprintf(string, "%s\0", ch_obs_t.start_t[3]);
        tv_get_param("char", cursor_pos, bttn_box[I],
                     pitch, string, 0.0, 0.0);
        sprintf(ch_obs_t.start_t[3], "%s\0",  string);
        char_ncopy(ch_obs_t.start_t[3], string, 2);
        str_init(string, nstr);
      }

      if (button_chk(cursor_pos, bttn_box[I=TIME_SECTION+4]) == ON) {
        sprintf(string, "%s\0", ch_obs_t.start_t[4]);
        tv_get_param("char", cursor_pos, bttn_box[I],
                     pitch, string, 0.0, 0.0);
        sprintf(ch_obs_t.start_t[4], "%s\0",  string);
        char_ncopy(ch_obs_t.start_t[4], string, 2);
        str_init(string, nstr);
      }

      if (button_chk(cursor_pos, bttn_box[I=TIME_SECTION+5]) == ON) {
        sprintf(string, "%s\0", ch_obs_t.start_t[5]);
        tv_get_param("char", cursor_pos, bttn_box[I],
                     pitch, string, 0.0, 0.0);
        sprintf(ch_obs_t.start_t[5], "%s\0",  string);
        char_ncopy(ch_obs_t.start_t[5], string, 2);
        str_init(string, nstr);
      }

      if (button_chk(cursor_pos, bttn_box[I=TIME_SECTION+6]) == ON) {
        tv_get_param("double", cursor_pos, bttn_box[I],
                     pitch, ch_obs_t.obsd, 0.0, 0.0);
        sscanf(ch_obs_t.obsd, "%lf", obs_duration);
        sprintf(string, "Oberving duration is set to %lf [h].\0",
                *obs_duration);
        comment_disp(cmnt, comment, string, ON);
      }

/*
-----------------------------------------
*/

      if (*SRT_NUM != 0) {
        I = SRT_SECTION;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          toggle_button(&ERROR_FLAG[SRTAER], srtaer, bttn_box[I]);
        }

        for (i=0; i<*SRT_NUM; i++) {
          for (j=0; j<6; j++) {
            I++;
            if (button_chk(cursor_pos, bttn_box[I]) == ON) {
              if (j == 0) {
                tv_get_param("char", cursor_pos, bttn_box[I],
                             pitch, ch_srt[i].apo, 0.0, 0.0);
              } else if (j == 1) {
                tv_get_param("char", cursor_pos, bttn_box[I],
                             pitch, ch_srt[i].per, 0.0, 0.0);
              } else if (j == 2) {
                tv_get_param("char", cursor_pos, bttn_box[I],
                             pitch, ch_srt[i].inc, 0.0, 0.0);
              } else if (j == 3) {
                tv_get_param("char", cursor_pos, bttn_box[I],
                             pitch, ch_srt[i].OMG, 0.0, 0.0);
              } else if (j == 4) {
                tv_get_param("char", cursor_pos, bttn_box[I],
                             pitch, ch_srt[i].omg, 0.0, 0.0);
              } else if (j == 5) {
                tv_get_param("char", cursor_pos, bttn_box[I],
                             pitch, ch_srt[i].t_0, 0.0, 0.0);
              }
            }
          }
        }
      }

/*
----
*/

    }
  }

/*
============================================================
*/

  if (TV_SWT == OFF) {
    printf("ARIS starts....\n");
  } else if (TV_SWT == ON) {
    if (START_FLAG == ON) {
      comment_disp(cmnt, comment, "ARIS starts...\0", ON);
    } else if (START_FLAG == OFF) {
      comment_disp(cmnt, comment, "EXIT.\0", ON);
    }
  }

/*
============================================================
*/

  if (obs_param_set(ERROR_FLAG, ARRAY_ID,
                    ANT_NUM,  GRT_NUM,  SRT_NUM, ch_srt, srt,
                    ch_grt_el_lim, grt_elevation_limit,
                    sep_angle_limit_from_earth_limb,
                    &ch_obs_t, TimUTC, UT1_UTC,
                    obs_duration, SRCPROC_MODE,
                    &ch_src, &pair_src, src, sun) == -1) {
    printf("ERROR: OBS_PARAMETER_INPUT: SUN ANGLE CHECK.\n");
    free (antenna_ufl);
    return -1;
  }

/*
============================================================
*/

  obs_param_file_io(ERROR_FLAG,
                    ARRAY_ID, ANT_NUM, GRT_NUM, SRT_NUM,
                    srt, grt_elevation_limit,
                    sep_angle_limit_from_earth_limb,
                    TimUTC, UT1_UTC, obs_duration,
                    antenna_ufl, &SRCPROC_MODE, src, sun, ant_prm,
                    ch_grt_el_lim, &pair_src, &ch_src,
                    ch_srt, &ch_obs_t, 1);

/*
-----------------------------------------------------
*/

  if (START_FLAG == ON) {
    j = 0;
    for (i=0; i<*GRT_NUM; i++) {
      if (ant_prm[i].UFL == ON) {
        j++;
      }
    }
    if (j + *SRT_NUM == 0) {
      sprintf(string, "ERROR: OBS_PARAMETER_SET: NO ANTENNA selected.\0");
      printf("%s\n", string);
      if (TV_SWT == ON) {
        comment_disp(cmnt, comment, string, ON);
      }
      free (antenna_ufl);
      return ( NG);
    } else if (j + *SRT_NUM == 1) {
      sprintf(string, "WARNING: OBS_PARAMETER_SET: NO BASELINE selected.\0");
      printf("%s\n", string);
      if (TV_SWT == ON) {
        comment_disp(cmnt, comment, string, ON);
      }
      free (antenna_ufl);
      return ( ON);
    } else {
      free (antenna_ufl);
      return ( ON);
    }
  } else if (START_FLAG == OFF) {
    free (antenna_ufl);
    return (OFF);
  }
}
