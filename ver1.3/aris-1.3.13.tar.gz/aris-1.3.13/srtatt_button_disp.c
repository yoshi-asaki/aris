#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>


void  srtatt_button_disp(int SRT_NUM,
                         int srtatt_num, int *srtatt_code,
                         int trk_num, float y_pos, float pitch,
                         char srtatt_name[][10], float bttn_box[][4])
{
  int    i, I, iant, idum;
  float  pgxmin[SRTMAX], pgxmax[SRTMAX], pgymin[SRTMAX], pgymax[SRTMAX];
  char   string[20];

/*
--------------------
*/

  I = 0;
  for (iant=0; iant<SRT_NUM; iant++) {
    for (i=0; i<srtatt_num; i++) {
      bttn_box[I][0] = 0.64 + 0.11 * (float)i;
      bttn_box[I][1] = bttn_box[I][0] + 0.10;
      bttn_box[I][2] = y_pos + 0.006 - (float)iant * 0.033;
      bttn_box[I][3] = bttn_box[I][2] + 0.9 * pitch;
      I++;
    }

    pgxmin[iant] = bttn_box[3*iant][0]              - 0.130;
    pgxmax[iant] = bttn_box[3*iant+srtatt_num-1][1] + 0.000;
    pgymin[iant] = bttn_box[3*iant][2]              - 0.002;
    pgymax[iant] = bttn_box[3*iant][3]              + 0.002;

    TV_menu_hatch(pgxmin[iant], pgxmax[iant], pgymin[iant], pgymax[iant], 0, 1);
    cpgsci(1);
    if (SRT_NUM == 1) {
      sprintf(string, "SRT Attitud\0");
      cpgtext(pgxmin[iant]+0.025,
              y_pos + 0.55 * pitch - (float)iant * 0.03, string);
    } else {
      sprintf(string, "SRT [%d] Attitud\0", iant+1);
      cpgtext(pgxmin[iant]+0.005,
              y_pos + 0.55 * pitch - (float)iant * 0.03, string);
    }
    for (i=0; i<srtatt_num; i++) {
      if (i == srtatt_code[iant]) {
        on_button(&idum, srtatt_name[i], bttn_box[3*iant+i]);
      } else {
        off_button(&idum, srtatt_name[i], bttn_box[3*iant+i]);
      }
    }
  }

  if (trk_num == 0) {
    TV_menu_hatch(pgxmin[0], pgxmax[0], pgymin[SRT_NUM-1], pgymax[0], 7, 4);
  }

  return;
}
