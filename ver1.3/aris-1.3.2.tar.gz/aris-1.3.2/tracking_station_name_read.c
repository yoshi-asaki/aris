#include <stdio.h>
#include <stdlib.h>


int  tracking_station_name_read(int trk_num,
                                char *station_name,
                                char trk_name[][10],
                                int *priority)
{
  int    i, j, idum;

  idum = 0;
  for (i=0; i<strlen(station_name); i++) {
    if (station_name[i] == ',' || station_name[i] == ' ') {
      station_name[i] = '\0';
      for (j=0; j<strlen(station_name+i+1); j++) {
        if (station_name[i+1+j] == '\n') {
          idum = 0;
          break;
        } else if (station_name[i+1+j] != ' ') {
          sscanf(station_name + i + 1 + j, "%d", &idum);
          break;
        }
      }
      break;
    } else if (station_name[i] == '\n') {
      station_name[i] = '\0';
      idum = 0;
      break;
    }
  }
  sprintf(trk_name[trk_num], "%s\0", station_name);
  priority[trk_num] = idum;
  trk_num++;

  return trk_num;
}
