#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <cpgplot.h>
#include <aris.h>

#define ATM_SECTION   10
#define CNTR_SECTION  30
#define NAME_SECTION  40


int  phase_screen_check(int NMTRX,
                        struct phase_screen_parameter wvc,
                        float  *cursor_pos,
                        int TV_SWT, int *pgid)
{
  int    i, j, I, NOD, idum;
  int    NX, NY;
  int    *IX, *IY;
  int    corner_position[2][2];
  int    COUNT_NOD;
  char   *title[2];
  double *DS;
  double *wvdist, *seed_dist, seed_end[2];
  float  *DIST[2], dmin, dmax;
  float  pmin, pmax, noise, err_x, err_y, delta_x, delta_y;
  float  *s_x_cnt, *s_y_cnt, *s_x_w, *s_y_w;
  float  pitch = 0.03;

  FILE   *ifp, *ofp;
  float  bttn_box[60][4];
  char   string[100];
  char   param_char[20][40];
  char   fname[40];

  int    PROC_SWT, DISP_SWT;
  double ps_param[20];

/*
---------------------- Atmospheric Turbulence 2D
*/

  ps_param[0]  = wvc.H_d;
  ps_param[1]  = vlen2(wvc.v);
  ps_param[2]  = 180.0 / dpi * atan2(wvc.v[1], wvc.v[0]);
  ps_param[3]  = wvc.i_scale[0];
  ps_param[4]  = wvc.o_scale[0];
  ps_param[5]  = wvc.i_expon;
  ps_param[6]  = wvc.o_expon;
  ps_param[7]  = wvc.pixel;
  ps_param[8]  = 1024.0;
  ps_param[9]  = 1024.0;
  ps_param[11] = 100.0;
  ps_param[12] = 1.5;
  ps_param[10] = ps_param[12] * 0.02 / pow(ps_param[11], 0.5*ps_param[5]);

  for (i=0; i<13; i++) {
    sprintf(param_char[i], "%lf", ps_param[i]);
  }
  DISP_SWT = OFF;
  sprintf(fname, "screen.dat\0");

  if ((ifp = fopen("aris_input/ps_model.prm", "r")) != NULL) {
    while (1) {
      if (fgets(string, sizeof(string), ifp) == NULL) {
        break;
      } else {
        string[strlen(string)-1] = '\0';
      }
      if (strncmp(string, "SCREEN HEIGHT       ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[0]);
        sscanf(string+20, "%lf", &ps_param[0]);
      } else if (strncmp(string, "WIND VELOCITY       ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[1]);
        sscanf(string+20, "%lf", &ps_param[1]);
      } else if (strncmp(string, "POSITION ANGLE      ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[2]);
        sscanf(string+20, "%lf", &ps_param[2]);
      } else if (strncmp(string, "INNER SCALE LENGTH  ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[3]);
        sscanf(string+20, "%lf", &ps_param[3]);
      } else if (strncmp(string, "OUTER SCALE LENGTH  ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[4]);
        sscanf(string+20, "%lf", &ps_param[4]);
      } else if (strncmp(string, "INNER EXPONENT      ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[5]);
        sscanf(string+20, "%lf", &ps_param[5]);
      } else if (strncmp(string, "OUTER EXPONENT      ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[6]);
        sscanf(string+20, "%lf", &ps_param[6]);
      } else if (strncmp(string, "GRID                ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[7]);
        sscanf(string+20, "%lf", &ps_param[7]);
      } else if (strncmp(string, "SCREEN WIDTH (X)    ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[8]);
        sscanf(string+20, "%lf", &ps_param[8]);
      } else if (strncmp(string, "SCREEN WIDTH (Y)    ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[9]);
        sscanf(string+20, "%lf", &ps_param[9]);
      } else if (strncmp(string, "RMS VALUE           ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[10]);
        sscanf(string+20, "%lf", &ps_param[10]);
      } else if (strncmp(string, "BASELINE OF THE RMS ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[11]);
        sscanf(string+20, "%lf", &ps_param[11]);
      } else if (strncmp(string, "BIAS                ", 20) == 0) {
        sscanf(string+20, "%s",  param_char[12]);
        sscanf(string+20, "%lf", &ps_param[12]);
      } else if (strncmp(string, "DISPLAY SWITCH      ", 20) == 0) {
        sscanf(string+20, "%d",  &DISP_SWT);
      } else if (strncmp(string, "SAVE FILE NAME      ", 20) == 0) {
        sscanf(string+20, "%s", fname);
      }
    }
    fclose (ifp);
  }

/*
----------------------
*/

  if (TV_SWT == ON) {
    cpgslct(pgid[0]);
    cpgpap(1.5*pgpap_prm, 1.0);
    cpgsvp(0.0, 1.0, 0.0, 1.0);
    cpgswin(0.0, 1.0, 0.0, 1.0);
    cpgsch(0.65);

    cpgsci(0);
    cpgrect(0.0, 1.0, 0.0, 1.0);
    cpgsci(1);

    for (i=0; i<13; i++) {
      I = ATM_SECTION + i;
      bttn_box[I][0] = 0.30;
      bttn_box[I][1] = 0.50;
      bttn_box[I][2] = 0.94 - 0.05*(float)i;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      cpgsci(1);
      if (i == 0) {
        sprintf(string, "Screen Height [m]\0");
      } else if (i == 1) {
        sprintf(string, "Wind Velocity [m/s]\0");
      } else if (i == 2) {
        sprintf(string, "Position Angle [deg]\0");
      } else if (i == 3) {
        sprintf(string, "Inner Scale [m]\0");
      } else if (i == 4) {
        sprintf(string, "Outer Scale [m]\0");
      } else if (i == 5) {
        sprintf(string, "Inner Exponent\0");
      } else if (i == 6) {
        sprintf(string, "Outer Exponent\0");
      } else if (i == 7) {
        sprintf(string, "Grid [m]\0");
      } else if (i == 8) {
        sprintf(string, "Width (x) [m]\0");
      } else if (i == 9) {
        sprintf(string, "Width (y) [m]\0");
      } else if (i == 10) {
        sprintf(string, "RMS Value\0");
      } else if (i == 11) {
        sprintf(string, "Baseline Length [m]\0");
      } else if (i == 12) {
        sprintf(string, "BIAS\0");
      }
      cpgtext(0.02, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3], string);
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
              0.0, 1.0, param_char[i]);
      cpgsci(1);
    }

/*
-------------------------------
*/

    TV_menu_hatch(0.00, 0.51, 0.78, 0.98, 7, 4);

/*
-------------------------------
*/

    I = NAME_SECTION;
    bttn_box[I][0] = 0.60;
    bttn_box[I][1] = 0.85;
    bttn_box[I][2] = 0.50;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgsci(1);
    cpgtext(0.54, -0.4*bttn_box[I][2]+1.4*bttn_box[I][3], "Save File Name\0");
    cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
    cpgsci(0);
    cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
            0.0, 1.0, fname);
    cpgsci(1);

/*
-------------------------------
*/

    I = CNTR_SECTION;
    bttn_box[I][0] = 0.54;
    bttn_box[I][1] = 0.91;
    bttn_box[I][2] = 0.20;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    if (DISP_SWT == ON) {
      on_button(&idum, "SCREEN DISPLAY\0", bttn_box[I]);
    } else {
      off_button(&idum, "DISPLAY SWITCH\0", bttn_box[I]);
    }
    I++;
    bttn_box[I][0] = 0.54;
    bttn_box[I][1] = 0.70;
    bttn_box[I][2] = 0.10;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "SAVE\0", bttn_box[I]);
    I++;
    bttn_box[I][0] = 0.75;
    bttn_box[I][1] = 0.91;
    bttn_box[I][2] = 0.10;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "Return\0", bttn_box[I]);
  }

/*
-------------------------------
*/

  while (1) {

    PROC_SWT = OFF;

    if (TV_SWT == ON) {
      cpgcurs(cursor_pos, cursor_pos+1, string);

      for (i=3; i<13; i++) {
        I = ATM_SECTION + i;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          char_copy(string, param_char[i]);
          tv_get_param("char", cursor_pos, bttn_box[I],
                       pitch, string, 0.0, 0.0);
          char_copy(param_char[i], string);
          str_init(string, sizeof(string));
          sscanf(param_char[i], "%lf", &ps_param[i]);
        }
      }

/*
-------------------------------
*/

      I = CNTR_SECTION;
      if (button_chk(cursor_pos, bttn_box[I]) == ON) {
        toggle_button(&DISP_SWT, "DISPLAY SWITCH\0", bttn_box[I]);
      }

      I = CNTR_SECTION + 1;
      if (button_chk(cursor_pos, bttn_box[I]) == ON) {
        on_button(&idum, "SAVE\0", bttn_box[I]);
        PROC_SWT = ON;
      }

      I = CNTR_SECTION + 2;
      if (button_chk(cursor_pos, bttn_box[I]) == ON) {
        on_button(&idum, "EXIT\0", bttn_box[I]);
        break;
      }

/*
-------------------------------
*/

      I = NAME_SECTION;
      if (button_chk(cursor_pos, bttn_box[I]) == ON) {
        tv_get_param("char", cursor_pos, bttn_box[I],
                     pitch, fname, 0, 0);
      }

/*
-------------------------------
*/

    } else if (TV_SWT == OFF) {
      while (1) {
        printf("#### Parameter Input Menu ####\n");
        printf("1. Screen Height [m] (%f)\n",    (float)ps_param[0]);
        printf("2. Wind Velocity [m/s] (%f)\n",  (float)ps_param[1]);
        printf("3. Position Angle [deg] (%f)\n", (float)ps_param[2]);
        printf("4. Inner Scale [m] (%f)\n",      (float)ps_param[3]);
        printf("5. Outer Scale [m] (%f)\n",      (float)ps_param[4]);
        printf("6. Inner Exponent (%f)\n",       (float)ps_param[5]);
        printf("7. Outer Exponent (%f)\n",       (float)ps_param[6]);
        printf("8. Grid [m] (%f)\n",             (float)ps_param[7]);
        printf("9. Width (x) [m] (%f)\n",        (float)ps_param[8]);
        printf("a. Width (y) [m] (%f)\n",        (float)ps_param[9]);
        printf("b. RMS Value (%f)\n",            (float)ps_param[10]);
        printf("c. Baseline Length [m] (%f)\n",  (float)ps_param[11]);
        printf("d. BIAS (%f)\n",                 (float)ps_param[12]);
        printf("\n");
        printf("e. SAVE\n");
        printf("0. EXIT\n");
        printf("\n");
        printf("Input Number : ");
        if (fgets(string, sizeof(string), stdin) == NULL) {
          printf("ERROR: PHASE_SCREEN_CHECK: Invalid input.\n");
          return (-1);
        }
        if (string[0] == '0') {
          break;
        } else if (string[0] == 'e') {
          if (DISP_SWT == ON) {
            sprintf(string, "y\0");
          } else if (DISP_SWT == OFF) {
            sprintf(string, "n\0");
          }
          printf("DISPLAY MODE (y/n) [CR->%s] : ", string);
          if (fgets(string, sizeof(string), stdin) == NULL) {
            printf("ERROR: PHASE_SCREEN_CHECK: Invalid input.\n");
            return (-1);
          }
          if (string[0] == 'y') {
            DISP_SWT = ON;
          } else if (string[0] == 'n') {
            DISP_SWT = OFF;
          }
          printf("SAVE FILE NAME [CR->%s] : ", fname);
          if (fgets(string, sizeof(string), stdin) == NULL) {
            printf("ERROR: PHASE_SCREEN_CHECK: Invalid input.\n");
            return (-1);
          }
          if (string[0] != '\n') {
            char_copy(fname, string);
          }

          PROC_SWT = ON;
          break;
        } else if (string[0] >= '1' && string[0] <= '9' ||
                   string[0] >= 'a' && string[0] <= 'd') {
          if (string[0] >= '1' && string[0] <= '9') {
            i = string[0] - '1';
          } else if (string[0] >= 'a' && string[0] <= 'd') {
            i = string[0] - 'a' + 9;
          }
          printf("Input parameter : ");
          if (fgets(string, sizeof(string), stdin) == NULL) {
            printf("ERROR: PHASE_SCREEN_CHECK: Invalid input.\n");
            return (-1);
          }
          sscanf(string, "%lf", &ps_param[i]);
          sprintf(param_char[i], "%lf\0", ps_param[i]);
        }
      }
      if (string[0] == '0') {
        break;
      }
    }

/*
-------------------------------
*/

    if (PROC_SWT == ON) {

      wvc.H_d        = ps_param[0];
      wvc.v[0]       = ps_param[1] * cos(ps_param[2] / 180.0 * dpi);
      wvc.v[1]       = ps_param[1] * sin(ps_param[2] / 180.0 * dpi);
      wvc.i_scale[0] = ps_param[3];
      wvc.o_scale[0] = ps_param[4];
      wvc.i_expon    = ps_param[5];
      wvc.o_expon    = ps_param[6];
      wvc.pixel      = ps_param[7];

      NX             = (int)rint(ps_param[8] / ps_param[7]);
      NY             = (int)rint(ps_param[9] / ps_param[7]);
      ps_param[8]    = ps_param[7] * (double)NX;
      ps_param[9]    = ps_param[7] * (double)NY;

      wvc.i_coeffi   = ps_param[10] / pow(ps_param[11], 0.5*ps_param[5]);
      wvc.o_coeffi   = 0.0;
      wvc.c_coeffi   = 0.0;

/*
-------------------------------
*/

      NOD         = NX * NY;
      seed_dist   = (double *)calloc(NMTRX+1, sizeof(double));
      DS          = (double *)calloc(NOD,     sizeof(double));
      IX          = (int    *)calloc(NOD,     sizeof(int));
      IY          = (int    *)calloc(NOD,     sizeof(int));

      corner_position[0][0] = NMTRX/2 - NX/2;
      corner_position[0][1] = NMTRX/2 - NY/2;
      corner_position[1][0] = NMTRX/2 + NX/2 - 1;
      corner_position[1][1] = NMTRX/2 + NY/2 - 1;
      if ((COUNT_NOD = turbulent_phase_screen
             (NMTRX, 0, wvdist, seed_dist, seed_end, &wvc,
              OFF, OFF, 0, IX, IY, DS, corner_position, 0)) == -1) {
        free (seed_dist);
        free (IX);
        free (IY);
        free (DS);
        return (-1);
      } else {
        NOD = COUNT_NOD;
        ps_param[3] = wvc.i_scale[1];
        ps_param[4] = wvc.o_scale[1];
        for (i=3; i<5; i++) {
          I = ATM_SECTION + i;
          sprintf(param_char[i], "%lf\0", ps_param[i]);
          if (TV_SWT == ON) {
            cpgsci(1);
            cpgrect(bttn_box[I][0], bttn_box[I][1],
                    bttn_box[I][2], bttn_box[I][3]);
            cpgsci(0);
            cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
                    0.0, 1.0, param_char[i]);
            cpgsci(1);
          }
        }

        for (i=8; i<10; i++) {
          I = ATM_SECTION + i;
          sprintf(param_char[i], "%lf\0", ps_param[i]);
          if (TV_SWT == ON) {
            cpgsci(1);
            cpgrect(bttn_box[I][0], bttn_box[I][1],
                    bttn_box[I][2], bttn_box[I][3]);
            cpgsci(0);
            cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
                    0.0, 1.0, param_char[i]);
            cpgsci(1);
          }
        }
      }

/*
--------
*/

      if ((ofp = fopen(fname, "w")) == NULL) {
        printf("ERROR: phase_screen_check: cannot open file\n");
        return (-1);
      }

      fprintf(ofp, "# SCREEN HEIGHT       %s\n", param_char[0]);
      fprintf(ofp, "# WIND VELOCITY       %s\n", param_char[1]);
      fprintf(ofp, "# POSITION ANGLE      %s\n", param_char[2]);
      fprintf(ofp, "# INNER SCALE LENGTH  %s\n", param_char[3]);
      fprintf(ofp, "# OUTER SCALE LENGTH  %s\n", param_char[4]);
      fprintf(ofp, "# INNER EXPONENT      %s\n", param_char[5]);
      fprintf(ofp, "# OUTER EXPONENT      %s\n", param_char[6]);
      fprintf(ofp, "# GRID                %s\n", param_char[7]);
      fprintf(ofp, "# SCREEN WIDTH (X)    %s\n", param_char[8]);
      fprintf(ofp, "# SCREEN WIDTH (Y)    %s\n", param_char[9]);
      fprintf(ofp, "# RMS VALUE           %s\n", param_char[10]);
      fprintf(ofp, "# BASELINE OF THE RMS %s\n", param_char[11]);
      fprintf(ofp, "# BIAS                %s\n", param_char[12]);
      fprintf(ofp, "# DISPLAY SWITCH      %1d\n", DISP_SWT);
      fprintf(ofp, "# SAVE FILE NAME      %s\n", fname);
      fprintf(ofp, "# END OF HEADER       \n");
      for (i=0; i<NX; i++) {
        for (j=0; j<NY; j++) {
          fprintf(ofp, "%4d,%4d,%lf\n", i, j, DS[NY*i+j]+ps_param[12]);
        }
      }
      fclose (ofp);

/*
------------------------------------------------
*/

      if (DISP_SWT == ON) {
        DIST[0] = (float *)calloc(NOD, sizeof(float));
        dmin = (float)DS[0];
        dmax = (float)DS[0];
        for (i=0; i<NOD; i++) {
          DIST[0][i] = (float)DS[i];
          if (DIST[0][i] < dmin) {
            dmin = DIST[0][i];
          }
          if (DIST[0][i] > dmax) {
            dmax = DIST[0][i];
          }
        }
        for (i=0; i<NOD; i++) {
          DIST[0][i] -= dmin;
          DIST[0][i] /= (dmax - dmin);
        }
        title[0] = (char *)calloc(100, sizeof(char));
        sprintf(title[0], "Toropospheric Phase Screen\0");
        if (TV_SWT == ON) {
          if (pgid[1] < -1) {
            pgid[1] = cpgopen("/xs");
          }
          cpgslct(pgid[1]);
        } else {
          cpgbeg(1, "/xs", 1, 1);
          cpgpap(pgpap_prm, 1.0);
        }
        brightness_disp(1, NX, NX/2, NX/2, 1.0, 1.0,
                        (float)NX, (float)NY, 0.0, 0.0,
                        OFF, s_x_cnt, s_y_cnt, s_x_w, s_y_w,
                        DIST, "[meter]", title,
                        ON, ON, OFF, OFF, OFF, 64, "clr",
                        &pmin, &pmax, &noise, &err_x, &err_y,
                        &delta_x, &delta_y);
        if (TV_SWT == ON) {
          cpgslct(pgid[0]);
        } else {
          cpgend();
        }
        free (DIST[0]);
      }

/*
------------------------------------------------
*/

      free (seed_dist);
      free (IX);
      free (IY);
      free (DS);

      if (TV_SWT == ON) {
        I = CNTR_SECTION + 1;
        off_button(&idum, "SAVE\0", bttn_box[I]);
      }
    }
  }

/*
------------------------------------------------
*/

  if ((ifp = fopen("aris_input/ps_model.prm", "w")) != NULL) {
    fprintf(ifp, "SCREEN HEIGHT       %s\n", param_char[0]);
    fprintf(ifp, "WIND VELOCITY       %s\n", param_char[1]);
    fprintf(ifp, "POSITION ANGLE      %s\n", param_char[2]);
    fprintf(ifp, "INNER SCALE LENGTH  %s\n", param_char[3]);
    fprintf(ifp, "OUTER SCALE LENGTH  %s\n", param_char[4]);
    fprintf(ifp, "INNER EXPONENT      %s\n", param_char[5]);
    fprintf(ifp, "OUTER EXPONENT      %s\n", param_char[6]);
    fprintf(ifp, "GRID                %s\n", param_char[7]);
    fprintf(ifp, "SCREEN WIDTH (X)    %s\n", param_char[8]);
    fprintf(ifp, "SCREEN WIDTH (Y)    %s\n", param_char[9]);
    fprintf(ifp, "RMS VALUE           %s\n", param_char[10]);
    fprintf(ifp, "BASELINE OF THE RMS %s\n", param_char[11]);
    fprintf(ifp, "BIAS                %s\n", param_char[12]);
    fprintf(ifp, "DISPLAY SWITCH      %1d\n", DISP_SWT);
    fprintf(ifp, "SAVE FILE NAME      %s\n", fname);
    fclose (ifp);
  } else {
    printf("CAUTION: Input parameters cannot be saved. ");
    printf("Make directory \"./aris_input/\".\n");
  }

  return ( 1);

}
