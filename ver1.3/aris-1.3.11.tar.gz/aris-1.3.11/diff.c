#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>


double  diff(double X, double Y)
{

/****
      Difinition: (value) = X - Y
****/

  return (X - Y);
}
