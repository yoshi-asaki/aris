#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>


void output_star_position(char *RA,  char *DC,  double *s)
{
  int    i;
  int    rahh, ramm, dcdd, dcmm;
  double rass, dcss;

/*
----------------------------
*/

  xyz2radec(s, &rahh, &ramm, &rass, &dcdd, &dcmm, &dcss);
  sprintf(RA, "%2d %2d %9.6lf\0", rahh, ramm, rass);
  if (RA[0] == ' ') {
    RA[0] = '0';
  }
  if (RA[3] == ' ') {
    RA[3] = '0';
  }
  if (RA[6] == ' ') {
    RA[6] = '0';
  }
  while ((i=strlen(RA)-1) >= 10) {
    if (RA[i] == '0') {
      RA[i] = '\0';
    } else {
      break;
    }
  }

/*
----------------------------
*/

  if (dcdd >= 0) {
    DC[0] = '+';
  } else if (dcdd < 0) {
    DC[0] = '-';
  }

  if (abs(dcdd) < 10) {
    sprintf(DC+1, "0%1d %2d %9.6lf\0", abs(dcdd), abs(dcmm), fabs(dcss));
  } else if (abs(dcdd) >= 10) {
    sprintf(DC+1,  "%2d %2d %9.6lf\0", abs(dcdd), abs(dcmm), fabs(dcss));
  }
  if (DC[4] == ' ') {
    DC[4] = '0';
  }
  if (DC[7] == ' ') {
    DC[7] = '0';
  }
  while ((i=strlen(DC)-1) >= 11) {
    if (DC[i] == '0') {
      DC[i] = '\0';
    } else {
      break;
    }
  }

/*
----------------------------
*/

  return;
}
