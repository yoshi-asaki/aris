#include <stdio.h>
#include <aris.h>

#include <sys/time.h>
#include <unistd.h>
struct timeval  TV;
/**** 2010.08.31  timezone structure is too old.
struct timezone TZ;
****/


void seed_random(int RAND_SWT)
{
  if (RAND_SWT == ON) {
/**** 2010.08.31  timezone structure is too old.
    gettimeofday(&TV, &TZ);
****/
    gettimeofday(&TV, NULL);
    srand(TV.tv_usec);
  } else {
    srand(17);
  }
}
