#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <aris.h>


void source_model2(float *dist, int dmax, float res,
                   int   n_source,
                   float *pamp, float  *tamp,
                   float *radius_maj, float *radius_min, float *pa,
                   float *xoff, float *yoff, char  *s_type)
{
  int    i, j, dref, I, N;
  int    ix0, ix1, iy0, iy1;
  float  *DIST;
  float  amp=0.0, AMP, x, y, ar, ai;
  float  r_factor=0.0, alpha, r, phs, u, v;
  float  RA2, RB2, ln2;

/*
--------------------
*/

  DIST = (float *)calloc(dmax*dmax, sizeof(float));
  ln2 = log(2.0);

  dref = dmax / 2;

  for (N=0; N<n_source; N++) {
    for (i=0; i<dmax*dmax; i++) {
      DIST[i] = 0.0;
    }
    if (radius_maj[N] == 0.0 || radius_min[N] == 0.0) {
      amp = pamp[N];
      if (pamp[N] == 0.0) {
        amp = tamp[N];
      }
      *(DIST + dmax * (dref + (int)rint(xoff[N]/res))
                     + dref + (int)rint(yoff[N]/res)) = amp;
    } else {
      if (n_source > 5) {
        if (s_type[N] == 'G') {
          r_factor = 8.0;
        } else if (s_type[N] == 'S') {
          r_factor = 1.5;
        }

        r = r_factor * radius_maj[N];
        ix0 = dref + (int)rint((xoff[N] - r) / res);
        if (ix0 < 0) {
          ix0 = 0;
        }
        ix1 = dref + (int)rint((xoff[N] + r) / res);
        if (ix1 > dmax) {
          ix1 = dmax;
        }
        iy0 = dref + (int)rint((yoff[N] - r) / res);
        if (iy0 < 0) {
          iy0 = 0;
        }
        iy1 = dref + (int)rint((yoff[N] + r) / res);
        if (iy1 > dmax) {
          iy1 = dmax;
        }
      } else {
        ix0 = 0;
        ix1 = dmax;
        iy0 = 0;
        iy1 = dmax;
      }

      phs = -(0.5*dpi - pa[N]);
      ar = cos(phs);
      ai = sin(phs);
      RA2 = radius_maj[N] * radius_maj[N];
      RB2 = radius_min[N] * radius_min[N];

      if (pamp[N] != 0.0) {
        amp = pamp[N];
        if (s_type[N] == 'G') {
          tamp[N] = pamp[N] * ln2 * dpi * radius_maj[N] * radius_min[N];
        } else if (s_type[N] == 'S') {
          tamp[N] = pamp[N]       * dpi * radius_maj[N] * radius_min[N];
        }
      } else if (pamp[N] == 0.0) {
        if (s_type[N] == 'G') {
          amp = tamp[N] * ln2 / dpi / radius_maj[N] / radius_min[N];
        } else if (s_type[N] == 'S') {
          amp = tamp[N]       / dpi / radius_maj[N] / radius_min[N];
        }
      }
/**
      amp = 1.0;
**/

      AMP = 0.0;
      for (i=ix0; i<ix1; i++) {
        for (j=iy0; j<iy1; j++) {
          I = i*dmax + j;
          u = res * (float)(i - dref) - xoff[N];
          v = res * (float)(j - dref) - yoff[N];

          x = ar * u - ai * v;
          y = ai * u + ar * v;

          if (       s_type[N] == 'G') {
            *(DIST + I) = amp * exp(-ln2 * (x*x/RA2 + y*y/RB2));
          } else if (s_type[N] == 'S') {
            if (x*x/RA2 + y*y/RB2 <= 1.0) {
              *(DIST + I) = amp;
            }
          }
          AMP += *(DIST + I);
        }
      }

      alpha = tamp[N] / AMP;
/****
      printf("aaaaaaaaaa  %f  %f  %f\n", tamp[N], AMP, alpha);
****/
      for (i=ix0; i<ix1; i++) {
        for (j=iy0; j<iy1; j++) {
          *(DIST + i*dmax + j) *= alpha*0.5e4;
        }
      }
    }

    for (i=0; i<dmax*dmax; i++) {
      *(dist + i) += *(DIST + i);
    }
  }

  free (DIST);

  return;
}
