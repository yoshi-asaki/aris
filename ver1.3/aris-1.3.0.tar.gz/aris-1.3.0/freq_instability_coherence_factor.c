#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>

double  freq_instability_coherence_factor
        (double nu, int FRQSTD_1, int FRQSTD_2)
{

  int    ASD_MODE;
  int    wave_id;
  double coh_factor;

/*
--------
*/

  coh_factor = 1.0;

  ASD_MODE = FRQSTD_1 + FRQSTD_2;
/****
  ASD_MODE =  0 : NONE    & NONE
  ASD_MODE =  2 : NONE    & H_M
  ASD_MODE =  8 : NONE    & CSO_10
  ASD_MODE = 32 : NONE    & CSO_100
  ASD_MODE =  4 : H_M     & H_M
  ASD_MODE = 10 : H_M     & CSO_10
  ASD_MODE = 34 : H_M     & CSO_100
  ASD_MODE = 16 : CSO_10  & CSO_10
  ASD_MODE = 40 : CSO_10  & CSO_100
  ASD_MODE = 64 : CSO_100 & CSO_100
****/

  if (wave_id == L_BAND) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else if (wave_id == S_BAND) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else if (wave_id == C_BAND) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else if (wave_id == X_BAND) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else if (wave_id == KU_BAND) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else if (wave_id == K_BAND) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else if (wave_id == Q_BAND) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else if (wave_id == W_BAND || wave_id == BAND03) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else if (wave_id == BAND04) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else if (wave_id == BAND07) {
    if (ASD_MODE == 0) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  2) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  8) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 32) {
      coh_factor = 1.0;
    } else if (ASD_MODE ==  4) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 10) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 34) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 16) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 40) {
      coh_factor = 1.0;
    } else if (ASD_MODE == 64) {
      coh_factor = 1.0;
    }
  } else {
    coh_factor = 1.0;
  }

  coh_factor = one_sec_coherence_factor_calc(nu, FRQSTD_1, FRQSTD_2);

  return coh_factor;
}
