#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>

#define NCOM      24
#define MENU_NUM  20

void  error_disp(int ,
                 struct antenna_parameter        *,
                 struct atmospheric_zenith_error *,
                 float  *, float  *,
                 int  );

int  menu_config(int ANT_NUM, int GRT_NUM,  int SRT_NUM,  int TRK_NUM,
                 int BGN_ANT_I, int END_ANT_I,
                 int BGN_ANT_J, int END_ANT_J,
                 int nobs,
                 int  *TimUTC, double UT1_UTC, int  *ERROR_FLAG, int nswt,
                 struct antenna_parameter *ant_prm,
                 struct atmospheric_zenith_error *dz,
                 struct st_observable **int_obs,
                 double elevation_limit,
                 double *wave_length, double *nu,
                 double **Rate, int nbase,
                 struct fringe **frng,
                 float  **fringe_weight,
                 double inttim,
                 int    nfrq,
                 double band_width, struct baseline_uvw **bluvw,
                 struct source_parameter *src,
                 struct source_parameter sun,
                 double *pix_uvl, double *pix_mas,
                 struct srt_orbit_parameter *srt,
                 struct antenna_position    *trk_pos,
                 struct srt_data_link       *srt_link,
                 int    BODY_X_SUN,
                 double sep_angle_limit_from_earth_limb,
                 double OBS_T,   double  OBS_p,
                 double **wvc_ds, double **ion_ds,
                 int  TVSWT, float *cursor_pos,
                 int cpgid1, int cpgid2 )
{
  int    i, j, I, J, idum;
  int    NX, NY;
  int    proc_mode;
  int    iant, ns;
  int    timUTC[6];
  double ut1_utc;
  double uv_max;
  char   fits_fname[3][40];
  int    dsel_flag[3];

  int    m_block;
  float  **bttn_box;
  float  pitch=0.03;

  int    menu_num, MENU_ID, MENU_SECTION;
  char   menu[MENU_NUM][60];

  int    pgdev_num, PGDEV_ID, PGDEV_SECTION;
  char   pgdev[10][20];
  float  sel_pos = 0.15;

  char   string[NCOMLEN];
  char   comstr[NCOM][NCOMLEN];
  struct comment_param cmnt;

  int    FRNG_NUM;
  float  rms_phase[2];

  FILE   *log_fp;

/*
------------------------------------------
*/

  menu_num = 19;
  sprintf(menu[ 0], "ON source duration\0");
  sprintf(menu[ 1], "GRT error quantities\0");
  sprintf(menu[ 2], "Az-El plot\0");
  sprintf(menu[ 3], "(u, v) Plane\0");
  sprintf(menu[ 4], "Fringe Phase & Amplitude\0");
  sprintf(menu[ 5], "FITS-IDI save\0");
  sprintf(menu[ 6], "Simple FFT Imaging (no CLEAN)\0");
  sprintf(menu[ 7], "XXXX Fringe Fitting XXXX\0");


  sprintf(menu[ 8], "Orbit of Spacecrafts\0");
  sprintf(menu[ 9], "Ground Tracking AZ-EL Conditions\0");
  sprintf(menu[10], "On-board Link AZ-EL Conditions\0");
  sprintf(menu[11], "Ka-link Schedule\0");
  sprintf(menu[12], "SLR - Link Conditions (time line)\0");
  sprintf(menu[13], "SLR - Link Conditions (statistics)\0");
  sprintf(menu[14], "XXXX GPS - Link Conditions (time line) XXXX\0");
  sprintf(menu[15], "XXXX GPS - Link Conditions (statistics) XXXX\0");
  sprintf(menu[16], "Error Path Length time series\0");
  sprintf(menu[17], "Error Path Length power spectrum (target)\0");
  sprintf(menu[18], "Error Path Length Allan standard deviation (target)\0");

  pgdev_num = 7;
  sprintf(pgdev[0], "/XS\0");
  sprintf(pgdev[1], "/PS\0");
  sprintf(pgdev[2], "/VPS\0");
  sprintf(pgdev[3], "/CPS\0");
  sprintf(pgdev[4], "/VCPS\0");
  sprintf(pgdev[5], "/GIF\0");
  sprintf(pgdev[6], "/NULL\0");

/*
------------------------------------------
*/

  if (TVSWT == ON) {
    cpgslct(cpgid1);
    cpgpap(1.5*pgpap_prm, 1.0);
    cpgsch(1.5*pgpap_prm/13.0);
    cpgsvp(0.0, 1.0, 0.0, 1.0);
    cpgswin(0.0, 1.0, 0.0, 1.0);

    cpgsci(0);
    cpgrect(0.0, 1.0, 0.0, 1.0);

    cmnt.ncol = 24;
    cmnt.xmin = 0.52;
    cmnt.xmax = 0.98;
    cmnt.ymin = 0.28;
    cmnt.ymax = 0.92;
    cmnt.pitch = 0.03;
    comment_init(&cmnt, comstr, ON);
  }

/*
------------------------------------------
*/

  while (1) {
    for (i=0; i<6; i++) {
      timUTC[i] = TimUTC[i];
    }
    ut1_utc = UT1_UTC;

    if (TVSWT == OFF) {

      printf("**** plot : OBSERVING RESULTS ****\n");
      if (ANT_NUM >= 1) {
        printf("1. %s\n", menu[0]);
      }
      if (GRT_NUM >= 1) {
        printf("2. %s\n", menu[ 1]);
        printf("3. %s\n", menu[ 2]);
      }
      if (ANT_NUM >= 2) {
        printf("4. %s\n", menu[ 3]);
        printf("5. %s\n", menu[ 4]);
        printf("6. %s\n", menu[ 5]);
        printf("7. %s\n", menu[ 6]);
        printf("8. %s\n", menu[ 7]);
      }
      if (SRT_NUM >= 1) {
        printf("9. %s\n", menu[ 8]);
        printf("a. %s\n", menu[ 9]);
        printf("b. %s\n", menu[10]);
        printf("c. %s\n", menu[11]);
        printf("d. %s\n", menu[12]);
        printf("e. %s\n", menu[13]);
        printf("f. %s\n", menu[14]);
        printf("g. %s\n", menu[15]);
      }
      if (ANT_NUM >= 2 &&
          (ERROR_FLAG[APOSER] == ON || ERROR_FLAG[EOPERR] == ON ||
           ERROR_FLAG[TDSECZ] == ON || ERROR_FLAG[IDSECZ] == ON ||
           ERROR_FLAG[TWVTRB] == ON || ERROR_FLAG[IONTRB] == ON ||
           ERROR_FLAG[FQSERR] == ON || ERROR_FLAG[LOPOFS] == ON)) {
        printf("h. %s\n", menu[16]);
        printf("i. %s\n", menu[17]);
        printf("j. %s\n", menu[18]);
      }
      printf("\n");
      printf("0. RETURN\n");
      printf("-. EXIT\n");
      printf("Select number: ");

      while (1) {
        if (fgets(string, sizeof(string), stdin) == NULL) {
          printf("ERROR: MENU_CONFIG: Invalid input.\n");
          return (NG);
        }
        if (string[0] == '-') {
          MENU_ID = -2;
          break;
        } else if (string[0] == '0') {
          MENU_ID = string[0] - '0' - 1;
          break;
        } else if (string[0] == '1' && ANT_NUM >= 1) {
          MENU_ID = string[0] - '0' - 1;
          break;
        } else if (string[0] >= '2' && string[0] <= '3' && GRT_NUM >= 1) {
          MENU_ID = string[0] - '0' - 1;
          break;
        } else if (string[0] >= '4' && string[0] <= '7' && ANT_NUM >= 2) {
          MENU_ID = string[0] - '0' - 1;
          break;
        } else if (string[0] >= '8' && string[0] <= '9' && SRT_NUM >= 1) {
          MENU_ID = string[0] - '0' - 1;
          break;
        } else if (string[0] >= 'a' && string[0] <= 'e' && SRT_NUM >= 1) {
          MENU_ID = string[0] - 'a' + 9;
          break;
        } else if (string[0] >= 'g' && string[0] <= 'i' && ANT_NUM >= 2 &&
                  (ERROR_FLAG[APOSER] == ON || ERROR_FLAG[EOPERR] == ON ||
                   ERROR_FLAG[TDSECZ] == ON || ERROR_FLAG[IDSECZ] == ON ||
                   ERROR_FLAG[TWVTRB] == ON || ERROR_FLAG[IONTRB] == ON ||
                   ERROR_FLAG[FQSERR] == ON || ERROR_FLAG[LOPOFS] == ON)) {
          MENU_ID = string[0] - 'a' + 9;
          break;
        } else {
          printf("Wrong number. Select again : ");
        }
      }

      if (MENU_ID != -2 && MENU_ID != -1 && MENU_ID != 1 && MENU_ID != 5) {
        printf("PG Device? ");
        printf(
          "(1.XS  2.PS  3.VPS  4.CPS  5.VCPS  6.GIF  7.other (CR->/null) : ");
        while (1) {
          if (fgets(string, sizeof(string), stdin) == NULL) {
            printf("ERROR: MENU_CONFIG: Invalid input.\n");
            return (NG);
          }
          if (string[0] == '\n') {
            PGDEV_ID = 5;
            break;
          } else if (string[0] >= '1' && string[0] <= '6') {
            PGDEV_ID = string[0] - '1';
            break;
          } else if (string[0] == '7') {
            PGDEV_ID = 7;
            printf("Input device name: ");
            if (fgets(string, sizeof(string), stdin) == NULL) {
              printf("ERROR: MENU_CONFIG: Invalid input.\n");
              return (NG);
            }
            string[strlen(string)-1] = '\0';
            sprintf(pgdev[7], "%s\0", string);
            break;
          } else {
            printf("? Input again : ");
          }
        }
      }

/*
------------
*/

    } else if (TVSWT == ON) {

      TV_menu_hatch(0.00, 1.00, 0.92, 1.00, 0, 1);
      TV_menu_hatch(0.00, 0.50, sel_pos+0.04, 0.92, 0, 1);
      TV_menu_hatch(0.00, 1.00, 0.00, sel_pos+0.04, 0, 1);

      m_block = 2 + menu_num + pgdev_num;
      if ((bttn_box = (float **)malloc(m_block * sizeof(float *)))
                                                               == NULL) {
        printf("ERROR: menu_config: memory alloc for **bttn_box.\n");
        return ( NG);
      }
      for (i=0; i<m_block; i++) {
        if ((bttn_box[i] = (float *)calloc(4, sizeof(float))) == NULL) {
          printf("ERROR: menu_config: memory alloc for **bttn_box.\n");
          free_memory_block_float(bttn_box, i);
          return ( NG);
        }
      }

      I = 0;
      bttn_box[I][0] = 0.12;
      bttn_box[I][1] = 0.42;
      bttn_box[I][2] = 0.97;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      off_button(&idum, "RETURN\0", bttn_box[I]);

      I = 1;
      bttn_box[I][0] = 0.58;
      bttn_box[I][1] = 0.88;
      bttn_box[I][2] = 0.97;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      off_button(&idum, "EXIT\0", bttn_box[I]);

      MENU_SECTION  = 2;
      PGDEV_SECTION = MENU_SECTION + menu_num;

      for (i=0; i<menu_num; i++) {
        I = MENU_SECTION + i;
        bttn_box[I][0] = 0.02;
        bttn_box[I][1] = 0.48;
        bttn_box[I][2] = 0.89 - 0.037 * (float)i;
        bttn_box[I][3] = bttn_box[I][2] + pitch;
        if (i == 0 && ANT_NUM >= 1) {
          off_button(&idum, menu[i], bttn_box[I]);
        } else if (i >=  1 && i <=  2 && GRT_NUM >= 1) {
          off_button(&idum, menu[i], bttn_box[I]);
        } else if (i >=  3 && i <=  7 && ANT_NUM >= 2) {
          off_button(&idum, menu[i], bttn_box[I]);
        } else if (i >=  8 && i <= 15 && SRT_NUM >= 1) {
          off_button(&idum, menu[i], bttn_box[I]);
        } else if (i >= 16 && i <= 18 && ANT_NUM >= 2 &&
             (ERROR_FLAG[APOSER] == ON || ERROR_FLAG[EOPERR] == ON ||
              ERROR_FLAG[TDSECZ] == ON || ERROR_FLAG[IDSECZ] == ON ||
              ERROR_FLAG[TWVTRB] == ON || ERROR_FLAG[IONTRB] == ON ||
              ERROR_FLAG[FQSERR] == ON || ERROR_FLAG[LOPOFS] == ON)) {
          off_button(&idum, menu[i], bttn_box[I]);
        }
      }

      for (i=0; i<pgdev_num; i++) {
        I = PGDEV_SECTION +i;
        bttn_box[I][0] = 0.10 + 0.11 * (float)i;
        bttn_box[I][1] = 0.20 + 0.11 * (float)i;
        bttn_box[I][2] = 0.93;
        bttn_box[I][3] = bttn_box[I][2] + pitch;

        if (i == 0) {
          on_button(&idum, pgdev[i], bttn_box[I]);
        } else {
          off_button(&idum, pgdev[i], bttn_box[I]);
        }
        PGDEV_ID = 0;
      }

      while (1) {
        MENU_ID = -10;
        cpgcurs(cursor_pos, cursor_pos+1, string);

/*
-------------------
*/

        if (button_chk(cursor_pos, bttn_box[0]) == ON) {
          on_button(&idum, "RETURN\0", bttn_box[0]);
          MENU_ID = -1;
          break;
        }

        if (button_chk(cursor_pos, bttn_box[1]) == ON) {
          on_button(&idum, "EXIT\0", bttn_box[1]);
          MENU_ID = -2;
          break;
        }

/*
-------------------
*/

        for (i=0; i<menu_num; i++) {
          I = MENU_SECTION + i;
          if (button_chk(cursor_pos, bttn_box[I]) == ON) {
            if (i == 0 && ANT_NUM >= 1) {
              on_button(&idum, menu[i], bttn_box[I]);
              MENU_ID = i;
              break;
            } else if (i >= 1 && i <= 2 && GRT_NUM >= 1) {
              on_button(&idum, menu[i], bttn_box[I]);
              MENU_ID = i;
              break;
            } else if (i >= 3 && i <= 7 && ANT_NUM >= 2) {
              on_button(&idum, menu[i], bttn_box[I]);
              MENU_ID = i;
              break;
            } else if (i >= 8 && i <= 15) {
              if (SRT_NUM >= 1) {
                on_button(&idum, menu[i], bttn_box[I]);
                MENU_ID = i;
                break;
              }
            } else if (i >= 16 && i <= 18 && ANT_NUM >= 2 &&
                 (ERROR_FLAG[APOSER] == ON || ERROR_FLAG[EOPERR] == ON ||
                  ERROR_FLAG[TDSECZ] == ON || ERROR_FLAG[IDSECZ] == ON ||
                  ERROR_FLAG[TWVTRB] == ON || ERROR_FLAG[IONTRB] == ON ||
                  ERROR_FLAG[FQSERR] == ON || ERROR_FLAG[LOPOFS] == ON)) {
              on_button(&idum, menu[i], bttn_box[I]);
              MENU_ID = i;
              break;
            }
          }
        }
        if (MENU_ID != -10) {
          break;
        }

/*
-------------------
*/

        for (i=0; i<pgdev_num; i++) {
          I = PGDEV_SECTION + i;
          if (button_chk(cursor_pos, bttn_box[I]) == ON) {
            PGDEV_ID = i;
            for (j=0; j<pgdev_num; j++) {
              J = PGDEV_SECTION + j;
              if (j == i) {
                on_button(&idum, pgdev[j], bttn_box[J]);
              } else {
                off_button(&idum, pgdev[j], bttn_box[J]);
              }
            }
          }
        }
      }
    }

/*
----------------------------------------------------
*/

    if (MENU_ID == -2) {
      sprintf(string, "See you!!\0");
      if (TVSWT == OFF) {
        printf("%s\n", string);
      } else if (TVSWT == ON) {
        comment_disp(&cmnt, comstr, string, ON);
        free_memory_block_float(bttn_box, m_block);
      }
      return (OFF);
    } else if (MENU_ID == -1) {
      if (TVSWT == ON) {
        free_memory_block_float(bttn_box, m_block);
      }
      return ( ON);
    }

/*
----------------------------------------------------
*/

    if (TVSWT == ON && (MENU_ID != 1 && MENU_ID != 5)) {
      cpgid2 = (int)cpgopen(pgdev[PGDEV_ID]);
      if (cpgid2 < 0) {
        cpgask(-1);
      }
    }

/*
----------------------------------------------------
*/

    if (MENU_ID ==  0) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
      }
      on_source_disp(ANT_NUM,  GRT_NUM,  nobs, TimUTC,   UT1_UTC,
                     nswt, ant_prm,  int_obs,  elevation_limit);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID ==  1) {
      if (TVSWT == ON) {
        cpgslct(cpgid1);
        TV_menu_hatch(0.00, 1.00, 0.92, 1.00, 7, 4);
        TV_menu_hatch(0.00, 0.50, sel_pos+0.04, 0.92, 7, 4);
      }

      while (1) {
        proc_mode = station_select(ANT_NUM,
                       BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J, 
                       &NX, &NY, ant_prm, sel_pos, cursor_pos, TVSWT, 1);
        if (proc_mode == NG) {
          if (TVSWT == ON) {
            free_memory_block_float(bttn_box, m_block);
          }
          return ( NG);
        } else if (proc_mode == OFF) {
          break;
        } else {
          sprintf(string, "%10s : (X,Y,Z)[mm], Zt[ns], Zi[TECU]: \0",
                  ant_prm[NX].IDC);
          if (TVSWT == OFF) {
            printf("%s", string);
          } else if (TVSWT == ON) {
            comment_disp(&cmnt, comstr, string, ON);
          }

          sprintf(string, "  (%6.2f,%6.2f,%6.2f), %6.2f, %6.2f\0",
              (float)((ant_prm[NX].ERR[0] - ant_prm[NX].XYZ[0])/ 1.0e-3),
              (float)((ant_prm[NX].ERR[1] - ant_prm[NX].XYZ[1])/ 1.0e-3),
              (float)((ant_prm[NX].ERR[2] - ant_prm[NX].XYZ[2])/ 1.0e-3),
              (float)(dz[NX].trp / 1.0e-9),
              (float)(dz[NX].tec / 1.0e16));
          if (TVSWT == OFF) {
            printf("%s\n", string);
          } else if (TVSWT == ON) {
            comment_disp(&cmnt, comstr, string, ON);
          }
        }
      }

      if ((log_fp = fopen("aris_log/st.log", "w")) == NULL) {
        printf("Warning: MENU_CONFIG: ./aris_log/st.log cannot open.\n");
      } else {
        fprintf(log_fp,
         "  ANTENNA   X[mm]  Y[mm]  Z[mm]    Zt[ns]  Zi[TECU]\n");
        fprintf(log_fp,
         "---------------------------------------------------\n");
        for (i=0; i<GRT_NUM; i++) {
            sprintf(string, "%8s  (%6.2f,%6.2f,%6.2f), %6.2f, %6.2f\0",
                ant_prm[i].IDC,
                (float)((ant_prm[i].ERR[0] - ant_prm[i].XYZ[0])/ 1.0e-3),
                (float)((ant_prm[i].ERR[1] - ant_prm[i].XYZ[1])/ 1.0e-3),
                (float)((ant_prm[i].ERR[2] - ant_prm[i].XYZ[2])/ 1.0e-3),
                (float)(dz[i].trp / 1.0e-9),
                (float)(dz[i].tec / 1.0e16));
            fprintf(log_fp, "%s\n", string);
        }
        fclose (log_fp);
      }

/*
----
*/

    } else if (MENU_ID ==  2) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      azel_disp(GRT_NUM, nobs, ant_prm, int_obs, timUTC, elevation_limit);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID ==  3) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
      }

      cpgpap(pgpap_prm, 1.0);
      cpgsvp(0.15, 0.90, 0.15, 0.90);
      uv_max = 0.0;
      if (uv_display(nobs, &uv_max, ANT_NUM,
                     BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J,
                     int_obs, wave_length, nswt, ON,
                     1.25, C_STRUCTURE) == NG) {
        if (TVSWT == ON) {
          free_memory_block_float(bttn_box, m_block);
        }
        return ( NG);
      }
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID ==  4) {
      if (TVSWT == ON) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        TV_menu_hatch(0.00, 1.00, 0.92, 1.00, 7, 4);
        TV_menu_hatch(0.00, 0.50, sel_pos+0.04, 0.92, 7, 4);
      }
      while (1) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        proc_mode = station_select(ANT_NUM,
                           BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J, 
                           &NX, &NY, ant_prm, sel_pos, cursor_pos, TVSWT, 3);
        if (proc_mode == NG) {
          if (TVSWT == ON) {
            free_memory_block_float(bttn_box, m_block);
          }
          return ( NG);
        } else if (proc_mode == OFF) {
          break;
        } else {
          if (TVSWT == ON) {
            cpgslct(cpgid2);
          } else {
            cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
            cpgpap(pgpap_prm, 1.0);
          }
          if (proc_mode == 2) {
            FRNG_NUM = 2;
            if (fringe_disp(FRNG_NUM, ANT_NUM, NX, NY, ant_prm, nobs, nfrq,
                            timUTC, ut1_utc, frng, fringe_weight,
                            rms_phase) == -1) {
              printf("MENU_CONFIG: FRINGE_DISP: ERROR\n");
              exit (-1);
            }
          } else if (proc_mode == 3) {
            FRNG_NUM = 1;
            if (fringe_disp(FRNG_NUM, ANT_NUM, NX, NY, ant_prm, nobs, nfrq,
                            timUTC, ut1_utc, &frng[2], &fringe_weight[2],
                            rms_phase) == -1) {
              printf("MENU_CONFIG: FRINGE_DISP: ERROR\n");
              exit (-1);
            }
          }

          for (i=0; i<FRNG_NUM; i++) {
            if (i == 0) {
              sprintf(string, "RMS PHASE (TGT) : %5.1f [deg]\0", rms_phase[i]);
            } else if (i == 1) {
              sprintf(string, "RMS PHASE (REF) : %5.1f [deg]\0", rms_phase[i]);
            }
            if (TVSWT == ON) {
              cpgslct(cpgid1);
              comment_disp(&cmnt, comstr, string, ON);
            } else {
              printf("%s\n", string);
            }
          }
        }
      }
      if (TVSWT == ON) {
        cpgslct(cpgid2);
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID ==  5) {
      if (TVSWT == ON) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        TV_menu_hatch(0.00, 1.00, 0.92, 1.00, 7, 4);
        TV_menu_hatch(0.00, 0.50, sel_pos+0.04, 0.92, 7, 4);
      }
      while (1) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        if (fits_data_select(fits_fname, dsel_flag,
                             sel_pos, cursor_pos, TVSWT) == OFF) {
          break;
        } else {
          for (i=0; i<6; i++) {
            timUTC[i] = TimUTC[i];
          }
          ut1_utc = UT1_UTC;
          for (ns=0; ns<3; ns++) {
            if (dsel_flag[ns] == ON) {
              if (fitsidi_save(fits_fname[ns], ns, nobs,
                    ANT_NUM, GRT_NUM, SRT_NUM,
                    BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J,
                    timUTC, ut1_utc, inttim, nfrq, band_width, nu,
                    bluvw, frng, fringe_weight, ant_prm, src, srt) == -1) {
                printf("MENU_CONFIG: FITSIDI_SAVE: ERROR: STOP.\n");
                if (TVSWT == ON) {
                  free_memory_block_float(bttn_box, m_block);
                }
                return ( NG);
              }
            }
          }
        }
      }

/*
----
*/

    } else if (MENU_ID ==  6) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
        cpgpap(pgpap_prm, 1.0);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      qlook_imager(ANT_NUM, BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J,
                   nswt, nobs, nfrq, bluvw, frng, fringe_weight, wave_length);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID ==  7) {

/********
      if (TVSWT == ON) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        TV_menu_hatch(0.00, 1.00, 0.92, 1.00, 7, 4);
        TV_menu_hatch(0.00, 0.50, sel_pos+0.04, 0.92, 7, 4);
      }
      while (1) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        proc_mode = station_select(ANT_NUM,
                           BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J, 
                           &NX, &NY, ant_prm, sel_pos, cursor_pos, TVSWT, 3);
        if (proc_mode == NG) {
          if (TVSWT == ON) {
            free_memory_block_float(bttn_box, m_block);
          }
          return ( NG);
        } else if (proc_mode == OFF) {
          break;
        } else {
          if (TVSWT == ON) {
            cpgslct(cpgid2);
          } else {
            cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
            cpgpap(pgpap_prm, 1.0);
          }
          if (proc_mode == 2) {
            FRNG_NUM = 2;
            if (fringe_fitting(FRNG_NUM, ANT_NUM, NX, NY, ant_prm, nobs, nfrq,
                            timUTC, ut1_utc, frng, fringe_weight,
                            rms_phase) == -1) {
              printf("MENU_CONFIG: FRINGE_DISP: ERROR\n");
              exit (-1);
            }
          } else if (proc_mode == 3) {
            FRNG_NUM = 1;
            if (fringe_fitting(FRNG_NUM, ANT_NUM, NX, NY, ant_prm, nobs, nfrq,
                            timUTC, ut1_utc, &frng[2], &fringe_weight[2],
                            rms_phase) == -1) {
              printf("MENU_CONFIG: FRINGE_DISP: ERROR\n");
              exit (-1);
            }
          }

          for (i=0; i<FRNG_NUM; i++) {
            if (i == 0) {
              sprintf(string, "RMS PHASE (TGT) : %5.1f [deg]\0", rms_phase[i]);
            } else if (i == 1) {
              sprintf(string, "RMS PHASE (REF) : %5.1f [deg]\0", rms_phase[i]);
            }
            if (TVSWT == ON) {
              cpgslct(cpgid1);
              comment_disp(&cmnt, comstr, string, ON);
            } else {
              printf("%s\n", string);
            }
          }
        }
      }
      if (TVSWT == ON) {
        cpgslct(cpgid2);
        cpgclos();
      } else {
        cpgend();
      }
********/

/*
----
*/

    } else if (MENU_ID ==  8) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      orbit_disp(SRT_NUM, nobs, srt, timUTC, ut1_utc,
                 sep_angle_limit_from_earth_limb,
                 srt_link,
                 OBS_T, OBS_p,
                 TRK_NUM, BODY_X_SUN,
                 GRT_NUM, int_obs,
                 trk_pos, src[0], sun);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID ==  9) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      link_TRK_sim(SRT_NUM, nobs, srt, trk_pos,
                src[0], sun, srt_link,
                timUTC, ut1_utc, sep_angle_limit_from_earth_limb,
                OBS_T, OBS_p, TRK_NUM, BODY_X_SUN, TRACKING);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID ==  10) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      link_TRK_sim(SRT_NUM, nobs, srt, trk_pos,
                src[0], sun, srt_link,
                timUTC, ut1_utc, sep_angle_limit_from_earth_limb,
                OBS_T, OBS_p, TRK_NUM, BODY_X_SUN, ONBOARD);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID == 11) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      data_link_schedule(SRT_NUM, nobs, srt, trk_pos,
                src[0], sun, srt_link,
                timUTC, ut1_utc, sep_angle_limit_from_earth_limb,
                OBS_T, OBS_p, TRK_NUM, BODY_X_SUN, ONBOARD);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID == 12) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      link_SLR_sim(SRT_NUM, nobs, srt, trk_pos,
                src[0], sun, srt_link,
                timUTC, ut1_utc, sep_angle_limit_from_earth_limb,
                OBS_T, OBS_p, TRK_NUM, BODY_X_SUN, 0);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID == 13) {
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      link_SLR_sim(SRT_NUM, nobs, srt, trk_pos,
                src[0], sun, srt_link,
                timUTC, ut1_utc, sep_angle_limit_from_earth_limb,
                OBS_T, OBS_p, TRK_NUM, BODY_X_SUN, 1);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }

/*
----
*/

    } else if (MENU_ID == 14) {
/****AAAA
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      link_SLR_sim(SRT_NUM, nobs, srt, trk_pos,
                src[0], sun, srt_link,
                timUTC, ut1_utc, sep_angle_limit_from_earth_limb,
                OBS_T, OBS_p, TRK_NUM, BODY_X_SUN, 1);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }
AAAA****/

/*
----
*/

    } else if (MENU_ID == 15) {
/****AAAA
      if (TVSWT == ON) {
        cpgslct(cpgid2);
      } else {
        cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
        cpgpap(pgpap_prm, 1.0);
      }
      link_SLR_sim(SRT_NUM, nobs, srt, trk_pos,
                src[0], sun, srt_link,
                timUTC, ut1_utc, sep_angle_limit_from_earth_limb,
                OBS_T, OBS_p, TRK_NUM, BODY_X_SUN, 1);
      if (TVSWT == ON) {
        cpgclos();
      } else {
        cpgend();
      }
AAAA****/

/*
----
*/

    } else if (MENU_ID == 16) {
      if (TVSWT == ON) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        TV_menu_hatch(0.00, 1.00, 0.92, 1.00, 7, 4);
        TV_menu_hatch(0.00, 0.50, sel_pos+0.04, 0.92, 7, 4);
      }
      while (1) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        proc_mode = station_select(ANT_NUM,
                           BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J, 
                           &NX, &NY, ant_prm, sel_pos, cursor_pos, TVSWT, 2);
        if (proc_mode == NG) {
          if (TVSWT == ON) {
            free_memory_block_float(bttn_box, m_block);
          }
          return ( NG);
        } else if (proc_mode == OFF) {
          break;
        } else {
          if (TVSWT == ON) {
            cpgslct(cpgid2);
          } else {
            cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
            cpgpap(pgpap_prm, 1.0);
          }
          EPL_disp(NX, NY, nobs, ant_prm, nu, timUTC, int_obs);
          if (TVSWT == OFF) {
            cpgend();
          }
        }
      }
      if (TVSWT == ON) {
        cpgslct(cpgid2);
        cpgclos();
      }

/*
----
*/

    } else if (MENU_ID == 17) {
      if (TVSWT == ON) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        TV_menu_hatch(0.00, 1.00, 0.92, 1.00, 7, 4);
        TV_menu_hatch(0.00, 0.50, sel_pos+0.04, 0.92, 7, 4);
      }
      while (1) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        proc_mode = station_select(ANT_NUM,
                           BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J, 
                           &NX, &NY, ant_prm, sel_pos, cursor_pos, TVSWT, 2);
        if (proc_mode == NG) {
          if (TVSWT == ON) {
            free_memory_block_float(bttn_box, m_block);
          }
          return ( NG);
        } else if (proc_mode == OFF) {
          break;
        } else {
          if (TVSWT == ON) {
            cpgslct(cpgid2);
          } else {
            cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
            cpgpap(pgpap_prm, 1.0);
          }
          spectl_disp(NX, NY, nobs, ant_prm, nu, timUTC, int_obs);
          if (TVSWT == OFF) {
            cpgend();
          }
        }
      }
      if (TVSWT == ON) {
        cpgslct(cpgid2);
        cpgclos();
      }

/*
----
*/

    } else if (MENU_ID == 18) {
      if (TVSWT == ON) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        TV_menu_hatch(0.00, 1.00, 0.92, 1.00, 7, 4);
        TV_menu_hatch(0.00, 0.50, sel_pos+0.04, 0.92, 7, 4);
      }
      while (1) {
        if (TVSWT == ON) {
          cpgslct(cpgid1);
        }
        proc_mode = station_select(ANT_NUM,
                           BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J, 
                           &NX, &NY, ant_prm, sel_pos, cursor_pos, TVSWT, 2);
        if (proc_mode == NG) {
          if (TVSWT == ON) {
            free_memory_block_float(bttn_box, m_block);
          }
          return ( NG);
        } else if (proc_mode == OFF) {
          break;
        } else {
          if (TVSWT == ON) {
            cpgslct(cpgid2);
          } else {
            cpgbeg(1, pgdev[PGDEV_ID], 1, 1);
            cpgpap(pgpap_prm, 1.0);
          }
          allanv_disp(NX, NY, nobs, ant_prm, nu, timUTC, int_obs);
          if (TVSWT == OFF) {
            cpgend();
          }
        }
      }
      if (TVSWT == ON) {
        cpgslct(cpgid2);
        cpgclos();
      }
    }

/*
===========================================================
*/

    if (TVSWT == ON) {
      cpgslct(cpgid1);
      I = MENU_SECTION + MENU_ID;
      off_button(&idum, menu[MENU_ID], bttn_box[I]);
    }
  }

  if (TVSWT == ON) {
    free_memory_block_float(bttn_box, m_block);
  }
  return ( ON);
}
