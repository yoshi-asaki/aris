#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>


int  antenna_selection(int *ANT_NUM, int *GRT_NUM, int *SRT_NUM,
                       int *wave_id,
                       double grt_elevation_limit,
                       struct antenna_parameter *ant_prm,
                       struct srt_orbit_parameter *srt,
                       char   antenna_code[][10] )
{
  int    i, iant, itmp, I;
  char   station_code[10];

  I = 0;
  for (i=0; i<*GRT_NUM; i++) {
    if (ant_prm[i].UFL == ON) {
      array_config(-1, wave_id, 0,  &itmp,
                   ant_prm[i].IDC, ant_prm+I,  srt, ON);
      strncpy(antenna_code[I], ant_prm[I].IDC, strlen(ant_prm[I].IDC));
      if (grt_elevation_limit > ant_prm[I].ELLIM) {
        ant_prm[I].ELLIM = grt_elevation_limit;
      }
      I++;
    }
  }
  *GRT_NUM = I;
  *ANT_NUM = I;
  if (*SRT_NUM > 0) {
    *ANT_NUM += array_config(-1, wave_id, *SRT_NUM,  &itmp,
                            station_code, ant_prm + *ANT_NUM,  srt, ON);
  }

  for (iant=0; iant<*ANT_NUM; iant++) {
    ant_prm[iant].NOSTA = iant + 1;
  }

  return 1;
}
