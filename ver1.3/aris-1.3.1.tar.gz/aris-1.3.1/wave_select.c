#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <astrotools.h>
#include <aris.h>

int   wave_select(int  wave_id, double *wave_length, double *nu)
{
  int   WID;

  if (wave_id == L_BAND) {
    *wave_length = 0.188;
    WID =  0;
  } else if (wave_id == S_BAND) {
    *wave_length = 0.136;
    WID =  1;
  } else if (wave_id == C_BAND) {
    *wave_length = 6.25e-2;
    WID =  2;
  } else if (wave_id == X_BAND) {
    *wave_length = 3.57e-2;
    WID =  3;
  } else if (wave_id == KU_BAND) {
    *wave_length = 1.96e-2;
    WID =  4;
  } else if (wave_id == K_BAND) {
    *wave_length = 1.40e-2;
    WID =  5;
  } else if (wave_id == Q_BAND) {
    *wave_length = 7.00e-3;
    WID =  6;
  } else if (wave_id == W_BAND || wave_id == BAND03) {
    *wave_length = 3.4262857e-3;
    WID =  7;
  } else if (wave_id == BAND04) {
    *wave_length = 2.32e-3;
    WID =  8;
  } else if (wave_id == BAND05) {
    *wave_length = 1.74e-3;
    WID =  9;
  } else if (wave_id == BAND06) {
    *wave_length = 1.16e-3;
    WID = 10;
  } else if (wave_id == BAND07) {
    *wave_length = 8.5657143e-4;
    WID = 11;
  } else if (wave_id == BAND08) {
    *wave_length = 7.747e-4;
    WID = 12;
  } else {
    *wave_length = 1.0;
    WID = -1;
  }
  *nu = speed_of_light / *wave_length;

  return WID;
}
