#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>

/****
#define __DEMO__
#define __UV_DEBUG__
#define __CF_DEBUG__
****/

#define __CMG_FULL_SPEC__
#ifndef __CMG_FULL_SPEC__
  #define __CMG_HALF_SPEC__
#endif

 
/****
  src[0]: target
  src[1]: refernce calibrator
****/

int  main(int argc, char **argv)
{
  FILE   *fp;
  int    i, j, k, I, J, K, L;
  int    ns, NS[SRC_NUM];
  int    itmp1, proc_mode;
  int    wave_id[SRC_NUM_P1];
  int    ARRAY_ID, iant, jant, ANT_NUM, GRT_NUM;
  int    ndata, nant[SRC_NUM];
  int    BGN_ANT_I, BGN_ANT_J, END_ANT_I, END_ANT_J;

  int    ERROR_FLAG[ERROR_NUM];
  int    iobs, nobs;
  int    iave, nswt, nslewt, noffset;
  int    ibase, nbase;
  char   station_code[10];
  char   string[200];
  float  *mapr, *mapi;
  float  src_flag[SRC_NUM];
  double pix_uvl[SRC_NUM], pix_mas[SRC_NUM];
  double wave_length[SRC_NUM_P1], nu[SRC_NUM_P1];
  double uv_max, uv_factor[SRC_NUM];
  double SEPANG;
  double azl, ell;
  double amperr;
  double lftmp;
  double DS[SRC_NUM];
  int    nseries, SITE_NUM, NELEM; 

  char   comment[40][NCOMLEN];
  struct comment_param cmnt;

  struct phase_screen_parameter wvc[ANTMAX], ion[ANTMAX];
  double Cw[ANTMAX], CW, CI;
  double Ci0[2][86400], Ci1[2][86400];

  double amp, SIGMA, sigma, f1, f2;
  double Sv, Sh;
  struct EOP_data EOP, EOP_e;
  double dWX, dWY, dUT1;
  double W[3][3], R1[3][3];
  double xyz_tmp[3];
  double d_Delta_psi, d_Delta_eps;
  double pnt_err_tau;

  int    TimUTC[6], timUTC[6];
  int    DOY;
  double UT1_UTC,  ut1_utc;
  double obs_duration;
  double OBS_T, OBS_p;
  double grt_elevation_limit;
  struct srt_data_link  *srt_link;
  struct atmospheric_zenith_error *dz[2];
  struct TID  MSTID;
  int    BODY_X_SUN;

  struct fringe *frng[SRC_NUM_P1];
  float  *fringe_weight[SRC_NUM_P1];

  struct st_observable    *int_obs[SRC_NUM];
  double *wvc_ds[SRC_NUM], *ion_ds[SRC_NUM];
  double *fqs_ds;

  struct baseline_uvw  *bluvw[SRC_NUM];

  struct source_parameter src[SRC_NUM], src_proc[SRC_NUM], sun;
  struct morphology_file_name ch_file[SRC_NUM];

  int    IFREF=FLDMAX/2, JFREF=FLDMAX/2;
  int    ifrq, nfrq;
  double ar, ai, fr, fi, F, tau_err, ion_err, phs_err, fai_err;
  double d_lo_phs;
  double band_width, d_band_width, cfact;
  double inttim=1.0;
  struct antenna_parameter ant_prm[ANTMAX];
  char   antenna_code[ANTMAX][10];

  int    SRT_NUM;
  double sep_angle_limit_from_earth_limb;
  struct srt_orbit_parameter srt[SRTMAX];
  double init_l[SRTMAX];

  int    TRK_NUM;
  struct antenna_position  trk_pos[TRKMAX];

  int    AZEL_FIX = OFF;
  char   fits_fname[100], fname[100];

  int    TV_SWT, pgid[10];
  float  cursor_pos[2];
  float  bttn_box[4];
  float  pitch = 0.03;

  double fov_st;

  double frq_coh_factor[SRC_NUM];

/**** ACA DEMO PARAMETER ****/

  double alpha, pwv_exp, pwv_rms;

/*
===================================================================
*/

  for (i=0; i<10; i++) {
    pgid[i] = -1;
  }

/*
===================================================================
*/

  for (i=0; i<ERROR_NUM; i++) {
    ERROR_FLAG[i]      = OFF;
  }

  for (ns=0; ns<SRC_NUM; ns++) {
    src_flag[ns] = 100.0 * (float)(ns + 1);
    frq_coh_factor[ns] = 1.0;
  }

/*
===================================================================
*/

  BODY_X_SUN          = 0;

/*
===================================================================
*/

  OBS_T               =   290.0;
  OBS_p               =  1013.0;
  grt_elevation_limit =     7.0  / 180.0 * dpi;
  sep_angle_limit_from_earth_limb
                      =     0.25 / 180.0 * dpi;

/*
===================================================================
*/

#ifdef __RANDOM_SEED__
  seed_random(ON);
#else
  seed_random(OFF);
#endif /* __RANDOM_SEED__ */

/*
===================================================================
*/

/**** ACA DEMO PARAMETER ****/

  alpha   = 2.0 * 0.58;
  pwv_exp = 1.5;   /* [mm] */
  pwv_rms = pwv_exp * 0.02 / pow(100.0, 0.5*alpha);

/*
===================================================================
*/

  if (argc >= 2 && strcmp(argv[1], "-g") == 0) {
    TV_SWT = ON;
  } else {
    TV_SWT = OFF;
  }

/*
===================================================================
*/

/***********************************************
  cpgslct(cpgid2);
  cpgbbuf();
  cpgsave();
  Gaussian_noise_check();
  cpgebuf();
  cpgunsa();
***********************************************/

/*
===================================================================
*/

  if (TV_SWT == ON) {
    if (pgid[0] < 0) {
      pgid[0] = (int)cpgopen("/xs");
      if (pgid[0] < 0) {
        cpgask(-1);
        TV_SWT = OFF;
      }
    }
    cmnt.ncol  = 12;
    cmnt.xmin  = 0.02;
    cmnt.xmax  = 0.98;
    cmnt.ymin  = 0.01;
    cmnt.ymax  = 0.23;
    cmnt.pitch = 0.03;
  }

/*
----------------
*/

  while (1) {
    if (TV_SWT == ON) {
      cpgslct(pgid[0]);
    }
    SRT_NUM  = 0;
    ARRAY_ID = ALL_ANT;
    for (ns=0; ns<SRC_NUM; ns++) {
      wave_id[ns] = -1;
    }
    ANT_NUM   = array_config(ARRAY_ID,   wave_id, SRT_NUM, &GRT_NUM,
                             station_code, ant_prm,  srt, ON);
    proc_mode = obs_param_input(ERROR_FLAG, &ARRAY_ID,
                    &ANT_NUM, &GRT_NUM, &SRT_NUM,
                    srt, &grt_elevation_limit,
                    sep_angle_limit_from_earth_limb,
                    TimUTC, &UT1_UTC, &obs_duration, src, &sun, ant_prm,
                    &cmnt, comment,
                    TV_SWT, cursor_pos, pgid);

    if (proc_mode == NG) {
      sprintf(string, "ERROR: ARIS: in OBS_PARAMETER_SET: exit.\0");
      printf("%s\n", string);
      if (TV_SWT == ON) {
        comment_disp(&cmnt, comment, string, ON);
      }
      return (0);
    } else if (proc_mode == OFF) {
      sprintf(string, "See you again!!\0");
      if (TV_SWT == ON) {
        comment_disp(&cmnt, comment, string, ON);
      }
      printf("EXIT.\n");
      return (0);
    } else if (proc_mode == ANT_VIS) {
      proc_mode = antenna_visibility(
                        ANT_NUM, GRT_NUM, SRT_NUM, ant_prm,
                        src, sun, wvc, ion, Cw, Ci0, fqs_ds, src_flag, srt,
                        trk_pos, sep_angle_limit_from_earth_limb,
                        &cmnt, comment, TV_SWT, pgid);
      if (proc_mode == -1 || proc_mode == 0) {
        return (0);
      }
    } else if (proc_mode == PHS_SCR) {
      phase_screen_check(NOISE_MTRX, wvc[0], cursor_pos, TV_SWT, pgid);
    } else {
      antenna_selection(&ANT_NUM, &GRT_NUM, &SRT_NUM, wave_id,
                        grt_elevation_limit, ant_prm, srt,  antenna_code);
      break;
    }
  }

/*
===================================================================
*/

  nobs = (int)rint(obs_duration);

/*
------------------------------
*/


/*
----
*/

  if (SRT_NUM >= 1) {
    if ((srt_link = (struct srt_data_link *)
                        calloc(1, sizeof(struct srt_data_link))) == NULL) {
      printf("ARIS: ERROR: memory allocation: srt_link.\n");
      return (0);
    }
    if (get_srt_link(srt_link, &fov_st) == NG) {
      printf("ARIS: ERROR: GET_SRT_LINK\n");
      return (0);
    }
  }

  for (ns=0; ns<SRC_NUM; ns++) {
    uv_factor[ns] = 4.0;
  }
  /*
     For wider imaging area, uv_factor would be a small value. 
     (for example, 1.0.) For small imaging area, it would be 
     3.0 - 4.0. 
  */

  if (ARRAY_ID != ACA) {
    SITE_NUM = GRT_NUM;
    NELEM    = 1;
    nseries  = 2;
  } else if (ARRAY_ID == ACA) {
    SITE_NUM = 1;
    NELEM    = GRT_NUM;
    nseries  = SRC_NUM * GRT_NUM;
  }

/*
==============================================================
*/

  if (ERROR_FLAG[TWVTRB] == ON) {
    if (ARRAY_ID != ACA) {
      for (iant=0; iant<GRT_NUM; iant++) {
        wvc[iant].H_d        = 1.0e3;
        wvc[iant].H_s        = 1.0e3;
        wvc[iant].pixel      = 1.0;
        wvc[iant].i_scale[0] = wvc[iant].pixel * 1024.0;
        wvc[iant].o_scale[0] = wvc[iant].pixel * 8192.0;
        wvc[iant].i_expon    = 5.0 / 3.0;
        wvc[iant].o_expon    = 2.0 / 3.0;
        wvc[iant].v[0]       = -10.0;
        wvc[iant].v[1]       =   0.0;
        wvc[iant].i_coeffi   = 1.0;
        wvc[iant].o_coeffi   = 0.0;
        wvc[iant].c_coeffi   = 0.0;
        for (ns=0; ns<SRC_NUM; ns++) {
          Cw[iant] = wvc[iant].i_coeffi;
        }
      }
    } else if (ARRAY_ID == ACA) {
      for (iant=0; iant<GRT_NUM; iant++) {
        wvc[iant].H_d        = 1.0e3;
        wvc[iant].H_s        = 1.0e3;
        wvc[iant].pixel      = 1.0;
        wvc[iant].i_scale[0] = wvc[iant].pixel * 1024.0;
        wvc[iant].o_scale[0] = wvc[iant].pixel * 8192.0;
        wvc[iant].i_expon    = alpha;
        wvc[iant].o_expon    = 2.0 / 3.0;
        wvc[iant].v[0]       =  10.0;
        wvc[iant].v[1]       =   0.0;
        wvc[iant].i_coeffi   = 1.0;
        wvc[iant].o_coeffi   = 0.0;
        wvc[iant].c_coeffi   = 0.0;
        for (ns=0; ns<SRC_NUM; ns++) {
          Cw[iant] = wvc[iant].i_coeffi;
        }
      }
    }
  }

/*
==============================================================
*/

  if (ERROR_FLAG[IONTRB] == ON) {
    for (iant=0; iant<ANT_NUM; iant++) {
      ion[iant].H_d        = 300.0e+3;
      ion[iant].H_s        = 450.0e+3;
      ion[iant].pixel      = 150.0;
      ion[iant].pixel      = 300.0;
      ion[iant].i_scale[0] = ion[iant].pixel *   512.0;
      ion[iant].o_scale[0] = ion[iant].pixel *  8192.0;
      ion[iant].i_expon    = 5.0 / 3.0;
      ion[iant].o_expon    = -40.0;
      ion[iant].i_coeffi   = 1.0e12;
      ion[iant].o_coeffi   = 0.0;
      ion[iant].c_coeffi   = 0.0;
      ion[iant].v[0]       = 0.0;
      if (ant_prm[iant].XYZ[2] >= 0.0) {
        ion[iant].v[1]       = -100.0;
      } else {
        ion[iant].v[1]       =  100.0;
      }
    }

    if (TEC_fluctuation_amp(Ci0, TimUTC) == -1) {
      printf("ERROR: ARIS: TEC_fluctuation.\n");
      if (SRT_NUM >= 1) {
        free (srt_link);
      }
      return (0);
    }

    MSTID.amp    = 1.0e16;
    MSTID.lambda = 200.0e3;
    MSTID.v[0]   =   0.0;
    MSTID.v[1]   = 100.0;
  }

/*
=====================================================
*/

  Sv    = 10.0e-3;     /* Antenna Position: Vertical Comp.    :  10 mm   */
  Sh    =  3.0e-3;     /* Antenna Position: Horizontal Comp.  :   3 mm   */

  EOP.WX   = 0.0;
  EOP.WY   = 0.0;
  EOP_e.WX = 0.0;
  EOP_e.WY = 0.0;

/*
---- Antenna Position Error ----
*/

  if (ERROR_FLAG[APOSER] == ON) {
    for (iant=0; iant<GRT_NUM; iant++) {
      f1 = 0.5 * dpi * random_val1();
      f2 =       dpi * random_val1();
      amp = gauss_dev() / sqrt(pow(cos(f1)/Sh, 2.0) + pow(sin(f1)/Sv , 2.0));
      xyz_tmp[0] = amp * cos(f1) * cos(f2);
      xyz_tmp[1] = amp * cos(f1) * sin(f2);
      xyz_tmp[2] = amp * sin(f1);
      drotate(xyz_tmp, -dpi/2.0, "z");
      drotate(xyz_tmp,
        dpi/2.0-atan2(ant_prm[iant].XYZ[2], vlen2(ant_prm[iant].XYZ)), "y");
      drotate(xyz_tmp,
              atan2(ant_prm[iant].XYZ[1], ant_prm[iant].XYZ[0]), "z");
      ant_prm[iant].ERR[0] = ant_prm[iant].XYZ[0] + xyz_tmp[0];
      ant_prm[iant].ERR[1] = ant_prm[iant].XYZ[1] + xyz_tmp[1];
      ant_prm[iant].ERR[2] = ant_prm[iant].XYZ[2] + xyz_tmp[2];
    }
  } else if (ERROR_FLAG[APOSER] == OFF) {
    for (iant=0; iant<GRT_NUM; iant++) {
      ant_prm[iant].ERR[0] = ant_prm[iant].XYZ[0];
      ant_prm[iant].ERR[1] = ant_prm[iant].XYZ[1];
      ant_prm[iant].ERR[2] = ant_prm[iant].XYZ[2];
    }
  }

/*
---- Target Position Error ----
*/

  if (ERROR_FLAG[TPOSER] == ON) {
    DS[0] = 0.3e-3 * dpi / 180.0 / 3600.0 * gauss_dev();
    ref_pos_shift(src,   src+1, DS[0], &cmnt, comment, TV_SWT);
  }

/*
---- Reference Calibrator Position Error ----
*/

  if (ERROR_FLAG[RPOSER] == ON) {
    DS[1] = 0.3e-3 * dpi / 180.0 / 3600.0 * gauss_dev();
    ref_pos_shift(src+1, src,   DS[1], &cmnt, comment, TV_SWT);
  }

/*
---- EOP ----
*/

  transformation_matrices(TimUTC, (&EOP)->Qt,   (&EOP)->W,
                          0.0,     0.0,   EOP.WX,  EOP.WY);
  transformation_matrices(TimUTC, (&EOP_e)->Qt, (&EOP_e)->W,
                          0.0,     0.0,   EOP.WX,  EOP.WY);
  for (iant=0; iant<GRT_NUM; iant++) {
    dvector_calc(EOP.W, ant_prm[iant].XYZ);
  }

/*
---- EOP Error ----
*/

  if (ERROR_FLAG[EOPERR] == ON) {
    dUT1        =     0.02e-3 * gauss_dev();
                      /* UT1 Error                           : 0.02 ms */
    dWX         =     0.3e-3 / sqrt(2.0) / 3600.0 / 180.0 * dpi * gauss_dev();
                      /* Polar Motion Error [x]              : 0.3 mas */
    dWY         =     0.3e-3 / sqrt(2.0) / 3600.0 / 180.0 * dpi * gauss_dev();
                      /* Polar Motion Error [y]              : 0.3 mas */
    d_Delta_psi =     0.3e-3 / sqrt(2.0) / 3600.0 / 180.0 * dpi * gauss_dev();
    d_Delta_eps =     0.3e-3 / sqrt(2.0) / 3600.0 / 180.0 * dpi * gauss_dev();
                      /* Precession and Nutation             : 0.3 mas */

    transformation_matrices(TimUTC, (&EOP_e)->Qt, (&EOP_e)->W,
                            d_Delta_psi,  d_Delta_eps,
                            EOP.WX+dWX,  EOP.WY+dWY);

    for (iant=0; iant<GRT_NUM; iant++) {
      dvector_calc(EOP_e.W, ant_prm[iant].ERR);
    }
  } else {
    for (iant=0; iant<GRT_NUM; iant++) {
      dvector_calc(EOP.W,   ant_prm[iant].ERR);
    }
  }

/*
---------------
*/

  for (ns=0; ns<SRC_NUM; ns++) {
    dvector_calc(EOP.Qt, src[ns].s);
    src[ns].RA     = atan2(src[ns].s[1], src[ns].s[0]);
    src[ns].DC     = atan2(src[ns].s[2], vlen2(src[ns].s));
  }

  for (ns=0; ns<SRC_NUM; ns++) {
    if (ERROR_FLAG[EOPERR] == ON) {
      dvector_calc(EOP_e.Qt, src[ns].s_e);
    } else {
      dvector_calc(EOP.Qt,   src[ns].s_e);
    }
    src[ns].RA_e   = atan2(src[ns].s_e[1], src[ns].s_e[0]);
    src[ns].DC_e   = atan2(src[ns].s_e[2], vlen2(src[ns].s_e));
  }

/*
---------------
*/

  if (ERROR_FLAG[EOPERR] == ON || ERROR_FLAG[APOSER] == ON ||
      ERROR_FLAG[RPOSER] == ON) {
    for (i=0; i<3; i++) {
      for (j=0; j<3; j++) {
        R1[j][i] = EOP.W[i][j];
      }
    }
    for (i=0; i<3; i++) {
      for (j=0; j<3; j++) {
        W[i][j] = 0.0;
        for (k=0; k<3; k++) {
          W[i][j] += EOP_e.W[i][k] * R1[k][j];
        }
      }
    }
  }

/*
---------------
*/

  if (ERROR_FLAG[TDSECZ] == ON ||
     (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
    for (i=0; i<2; i++) {
      if ((dz[i] = (struct atmospheric_zenith_error *)
        calloc(GRT_NUM, sizeof(struct atmospheric_zenith_error))) == NULL) {
        printf("ARIS: ERROR: memory allocation: dz.\n");
        if (SRT_NUM >= 1) {
          free (srt_link);
        }
        free_memory_block((void *)dz, i);
        return (0);
      }
    }
  }

  if (ERROR_FLAG[TDSECZ] == ON) {
    if (ARRAY_ID != ACA) {
      for (iant=0; iant<GRT_NUM; iant++) {
        dz[0][iant].trp = gauss_dev();
      }
    } else if (ARRAY_ID == ACA) {
      for (iant=0; iant<GRT_NUM; iant++) {
        dz[0][iant].trp = pwv_exp;
      }
    }
  }

  if (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA) {
    for (iant=0; iant<GRT_NUM; iant++) {
      dz[0][iant].tec = gauss_dev();
    }
  }

/*
---- Local Oscilator Phase Error ----
*/

  if (ERROR_FLAG[LOPOFS] == ON) {
    for (iant=0; iant<ANT_NUM; iant++) {
      for (i=0; i<N_WAVE; i++) {
        ant_prm[iant].LOPHS[i] = dpi * random_val1();
      }
    }
  }

/*
---- Antenna Gain Loss Error ----
*/

  if (ERROR_FLAG[AMPERR] == ON) {
    for (iant=0; iant<ANT_NUM; iant++) {
      ant_prm[iant].d_gain = 0.05 * gauss_dev();
    }
  }

/*
==============================================================
*/

  I = nobs * ANT_NUM;
  for (ns=0; ns<SRC_NUM; ns++) {
    if ((int_obs[ns] = (struct st_observable *)
                   calloc(I, sizeof(struct st_observable))) == NULL) {
      printf("ARIS: ERROR: memory allocation: obs[%d]\n", ns);

      if (SRT_NUM >= 1) {
        free (srt_link);
      }
      if (ERROR_FLAG[TDSECZ] == ON ||
         (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
        free_memory_block((void *)dz, 2);
      }
      free_memory_block((void *)int_obs, ns);
      return (0);
    }
  }
  for (ns=0; ns<SRC_NUM; ns++) {
    for (i=0; i<I; i++) {
      int_obs[ns][i].wt        = src_flag[ns];
      int_obs[ns][i].amp_error = 1.0;
    }
  }

  if (ERROR_FLAG[TWVTRB] == ON) {
    for (ns=0; ns<SRC_NUM; ns++) {
      if ((wvc_ds[ns] = (double *)calloc(I, sizeof(double))) == NULL) {
        printf("ARIS: ERROR: calloc for wvc_ds[%d].\n", ns);

        if (SRT_NUM >= 1) {
          free (srt_link);
        }
        if (ERROR_FLAG[TDSECZ] == ON ||
           (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
          free_memory_block((void *)dz, 2);
        }
        free_memory_block((void *)int_obs, SRC_NUM);
        free_memory_block((void *)wvc_ds,  ns);
        return (0);
      }
    }
  }
  if (ERROR_FLAG[IONTRB] == ON) {
    for (ns=0; ns<SRC_NUM; ns++) {
      if ((ion_ds[ns] = (double *)calloc(I, sizeof(double))) == NULL) {;
        printf("AIRS: ERROR: calloc for ion_ds[%d].\n", ns);

        if (SRT_NUM >= 1) {
          free (srt_link);
        }
        if (ERROR_FLAG[TDSECZ] == ON ||
           (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
          free_memory_block((void *)dz, 2);
        }
        free_memory_block((void *)int_obs, SRC_NUM);
        if (ERROR_FLAG[TWVTRB] == ON) {
          free_memory_block((void *)wvc_ds,  SRC_NUM);
        }
        free_memory_block((void *)ion_ds,  ns);
        return (0);
      }
    }
  }
  if (ERROR_FLAG[FQSERR] == ON) {
    if ((fqs_ds = (double *)calloc(I, sizeof(double))) == NULL) {;
      printf("AIRS: ERROR: calloc for fqs_ds.\n");

      if (SRT_NUM >= 1) {
        free (srt_link);
      }
      if (ERROR_FLAG[TDSECZ] == ON ||
         (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
        free_memory_block((void *)dz, 2);
      }
      free_memory_block((void *)int_obs, SRC_NUM);
      if (ERROR_FLAG[TWVTRB] == ON) {
        free_memory_block((void *)wvc_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[IONTRB] == ON) {
        free_memory_block((void *)ion_ds,  SRC_NUM);
      }
      return (0);
    }
  }

/*
==============================================================
---------------------- Niell Mapping Function
*/

  DOY = (int)(MJD(TimUTC[0], TimUTC[1], TimUTC[2],
                  TimUTC[3], TimUTC[4], TimUTC[5],     0.0)
            - MJD(TimUTC[0],         1,         0,
                          0,         0,         0,     0.0));
  for (iant=0; iant<GRT_NUM; iant++) {
    nmf20_coeffi(ant_prm[iant].LLH[2], DOY,
                 &ant_prm[iant].nmfh[0], &ant_prm[iant].nmfh_hcr[0],
                 &ant_prm[iant].nmfw[0]);
  }

/*
==============================================================
*/

  sprintf(string, "**** UVW Calculation ****\0");
  if (TV_SWT == OFF) {
    printf("%s\n", string);
  } else if (TV_SWT == ON) {
    comment_disp(&cmnt, comment, string, ON);
  }

  for (ns=0; ns<SRC_NUM; ns++) {
    nant[ns] = 0;
    for (i=0; i<6; i++) {
      timUTC[i] = TimUTC[i];
    }
    ut1_utc = UT1_UTC;
    for (iant=0; iant<SRT_NUM; iant++) {
      init_l[iant] = dpi;
    }

    for (iobs=0; iobs<nobs; iobs++) {
      timUTC[5] = TimUTC[5] + iobs;
      i = uvw_calc(100.0 * (float)(ns + 1),
              ANT_NUM, GRT_NUM,  nobs, iobs, timUTC, UT1_UTC,
              ant_prm, src[ns], sun,
              wvc, ion, Cw, Ci0, CI, wvc_ds[ns], ion_ds[ns], fqs_ds,
              OFF, ERROR_FLAG, W, dUT1, int_obs[ns],
              OBS_T, OBS_p, dz[1], OFF,
              srt, init_l, TRK_NUM, trk_pos, srt_link,
              sep_angle_limit_from_earth_limb, BODY_X_SUN, MSTID);
      usleep(1);
/****
Although the above ``usleep'' is not needed in terms of the functions, 
the performance could be stable with this usleep in order to disturb 
SEGMENTATION FAULT. 
****/

      nant[ns] += i;
    }
    az_rotation(GRT_NUM, nobs, int_obs[ns], ant_prm);
  }
  az_adjustment(GRT_NUM, nobs, int_obs, ant_prm);

  for (ns=0; ns<SRC_NUM; ns++) {
    if (nant[ns] == 0) {
      printf("ERROR: ARIS: NO valid data because the elevation \n");
      printf("       angle is below the limit.\n");

      if (SRT_NUM >= 1) {
        free (srt_link);
      }
      if (ERROR_FLAG[TDSECZ] == ON ||
         (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
        free_memory_block((void *)dz, 2);
      }
      free_memory_block((void *)int_obs, SRC_NUM);
      if (ERROR_FLAG[TWVTRB] == ON) {
        free_memory_block((void *)wvc_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[IONTRB] == ON) {
        free_memory_block((void *)ion_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[FQSERR] == ON) {
        free(fqs_ds);
      }
      return (0);
    }
  }

  uv_max = 0.0;
  if (uv_display(nobs, &uv_max, ANT_NUM, 0, ANT_NUM, 0, ANT_NUM,
                 int_obs, wave_length, nswt, OFF, 1.25, OFF) == -1) {
    if (SRT_NUM >= 1) {
      free (srt_link);
    }
    if (ERROR_FLAG[TDSECZ] == ON ||
       (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
      free_memory_block((void *)dz, 2);
    }
    free_memory_block((void *)int_obs, SRC_NUM);
    if (ERROR_FLAG[TWVTRB] == ON) {
      free_memory_block((void *)wvc_ds,  SRC_NUM);
    }
    if (ERROR_FLAG[IONTRB] == ON) {
      free_memory_block((void *)ion_ds,  SRC_NUM);
    }
    if (ERROR_FLAG[FQSERR] == ON) {
      free(fqs_ds);
    }
    return (0);
  }

/*
---- ACA_DEMO ----
*/

  if (ARRAY_ID == ACA && AZEL_FIX == ON) {
    for (ns=0; ns<SRC_NUM; ns++) {
      for (iant=0; iant<GRT_NUM; iant++) {
        for (iobs=0; iobs<nobs; iobs++) {
          int_obs[ns][nobs*iant + iobs].az = fabs(src[ns].RA2k);
          int_obs[ns][nobs*iant + iobs].el = fabs(src[ns].DC2k);
        }
      }
    }
  }

/*
==============================================================
*/

  if (ERROR_FLAG[TWVTRB] == ON) {
    sprintf(string, "**** Tropospheric Phase Screen ****\0");
    if (TV_SWT == OFF) {
      printf("%s\n", string);
    } else if (TV_SWT == ON) {
      comment_disp(&cmnt, comment, string, ON);
    }

    for (i=0; i<6; i++) {
      timUTC[i] = TimUTC[i];
    }
    ut1_utc = UT1_UTC;
    if (atmospheric_fluctuation(
           NOISE_MTRX, GRT_NUM, nobs,  wvc_ds, timUTC, ut1_utc, ant_prm,
           wvc, src, OBS_T, OBS_p, OFF,
           nseries, SITE_NUM, NELEM, AZEL_FIX,
           &cmnt, comment, TV_SWT) == -1) {
      if (SRT_NUM >= 1) {
        free (srt_link);
      }
      if (ERROR_FLAG[TDSECZ] == ON ||
         (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
        free_memory_block((void *)dz, 2);
      }
      free_memory_block((void *)int_obs, SRC_NUM);
      free_memory_block((void *)wvc_ds,  SRC_NUM);
      if (ERROR_FLAG[IONTRB] == ON) {
        free_memory_block((void *)ion_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[FQSERR] == ON) {
        free(fqs_ds);
      }
      return 0;
    }
  }

/*
==============================================================
*/

  if (ERROR_FLAG[IONTRB] == ON) {
    sprintf(string, "**** Ionospheric Phase Screen ****\0");
    if (TV_SWT == OFF) {
      printf("%s\n", string);
    } else if (TV_SWT == ON) {
      comment_disp(&cmnt, comment, string, ON);
    }

    for (i=0; i<6; i++) {
      timUTC[i] = TimUTC[i];
    }
    ut1_utc = UT1_UTC;
    if (atmospheric_fluctuation(
           NOISE_MTRX, GRT_NUM, nobs,  ion_ds, timUTC, ut1_utc, ant_prm,
           ion, src, OBS_T, OBS_p, OFF,
           nseries, SITE_NUM, NELEM, AZEL_FIX,
           &cmnt, comment, TV_SWT) == -1) {
      if (SRT_NUM >= 1) {
        free (srt_link);
      }
      if (ERROR_FLAG[TDSECZ] == ON ||
         (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
        free_memory_block((void *)dz, 2);
      }
      free_memory_block((void *)int_obs, SRC_NUM);
      if (ERROR_FLAG[TWVTRB] == ON) {
        free_memory_block((void *)wvc_ds,  SRC_NUM);
      }
      free_memory_block((void *)ion_ds,  SRC_NUM);
      if (ERROR_FLAG[FQSERR] == ON) {
        free(fqs_ds);
      }
      return 0;
    }

/*
--------------------------------------------------------------
*/

    sprintf(string, "**** TEC MS-TID Simulation ****\0");
    if (TV_SWT == OFF) {
      printf("%s\n", string);
    } else if (TV_SWT == ON) {
      comment_disp(&cmnt, comment, string, ON);
    }

    for (i=0; i<6; i++) {
      timUTC[i] = TimUTC[i];
    }
    ut1_utc = UT1_UTC;
    GRT_TEC_TID(GRT_NUM, nobs, ion_ds, ant_prm, ion, int_obs, MSTID);
  }

/*
==============================================================
*/

  if (ERROR_FLAG[FQSERR] == ON) {
    sprintf(string, "**** Frequency Standard Error ****\0");
    if (TV_SWT == OFF) {
      printf("%s\n", string);
    } else if (TV_SWT == ON) {
      comment_disp(&cmnt, comment, string, ON);
    }

    for (iant=0; iant<ANT_NUM; iant++) {
      for (iobs=0; iobs<nobs; iobs++) {
        fqs_ds[nobs*iant + iobs] = 0.0;
      }

      if (ant_prm[iant].FRQSTD != 0) {
        if (freq_std_instability(nobs, fqs_ds+nobs*iant,
                               ant_prm[iant].FRQSTD) == -1) {
          if (SRT_NUM >= 1) {
            free (srt_link);
          }
          if (ERROR_FLAG[TDSECZ] == ON ||
             (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
            free_memory_block((void *)dz, 2);
          }
          free_memory_block((void *)int_obs, SRC_NUM);
          if (ERROR_FLAG[TWVTRB] == ON) {
            free_memory_block((void *)wvc_ds,  SRC_NUM);
          }
          free_memory_block((void *)ion_ds,  SRC_NUM);
          if (ERROR_FLAG[FQSERR] == ON) {
            free(fqs_ds);
          }
          return 0;
        }
      }
    }
  }

/*
==============================================================
*/

  while (1) {

/*
----------------------------------------------------
*/

    if (ERROR_FLAG[TDSECZ] == ON && ARRAY_ID != ACA) {
      for (iant=0; iant<GRT_NUM; iant++) {
        dz[1][iant].trp = dz[0][iant].trp;
      }
    }

    if (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA) {
      for (iant=0; iant<GRT_NUM; iant++) {
        dz[1][iant].tec = dz[0][iant].tec;
      }
    }

/*
----------------------------------------------------
*/

    if (err_parameter_set(ANT_NUM, GRT_NUM, SRT_NUM,
              &BGN_ANT_I, &END_ANT_I, &BGN_ANT_J, &END_ANT_J,
              ARRAY_ID, &CW, &CI, dz[1], src_proc, ch_file,
              wave_id, wave_length, nu,
              &band_width, &nfrq, &cfact,
              ERROR_FLAG, srt, &BODY_X_SUN,
              &nswt, ant_prm, &TRK_NUM, trk_pos,
              &cmnt, comment, TV_SWT, cursor_pos, pgid[0]) == -1) {
      return 1;
    }
    NS[0] = src_proc[0].positionID;
    NS[1] = src_proc[1].positionID;

/*
----------------------------------------------------
*/

    if (ERROR_FLAG[TWVTRB] == ON && ARRAY_ID != ACA) {
      for (iant=0; iant<GRT_NUM; iant++) {
        for (ns=0; ns<SRC_NUM; ns++) {
          Cw[iant] = CW;
        }
      }
    } else if (ERROR_FLAG[TWVTRB] == ON && ARRAY_ID == ACA) {
      for (iant=0; iant<GRT_NUM; iant++) {
        for (ns=0; ns<SRC_NUM; ns++) {
          Cw[iant] = pwv_rms;
        }
      }
    }

/*
----------------------------------------------------
*/

    if (ERROR_FLAG[IONTRB] == ON) {
      for (i=0; i<86400; i++) {
        Ci1[0][i] = CI * Ci0[0][i];
        Ci1[1][i] = CI * Ci0[1][i];
      }
    }

/*
----------------------------------------------------
*/

    for (iant=0; iant<GRT_NUM; iant++) {
      array_config(-1,              wave_id,
                   0,               &itmp1,     antenna_code[iant],
                   ant_prm+iant,    srt,        OFF);
    }

    if (SRT_NUM > 0) {
      array_config(-1,              wave_id,
                   SRT_NUM,         &itmp1,     station_code,
                   ant_prm+GRT_NUM, srt,        OFF);
    }
    for (iant=0; iant<ANT_NUM; iant++) {
      ant_prm[iant].NOSTA = iant + 1;
    }
    if (ERROR_FLAG[THRMNS] == ON) {
      for (iant=0; iant<ANT_NUM; iant++) {
        for (ns=0; ns<SRC_NUM; ns++) {
          ant_prm[iant].SEFD[ns]
              = SEFD(ant_prm[iant].Trx[ns], ant_prm[iant].Tsky[ns],
                     ant_prm[iant].Dm[ns],  ant_prm[iant].Ae[ns]);
        }

        sprintf(string, "SEFD (%s) : %8.2lf Jy    %8.2lf Jy\0",
                ant_prm[iant].IDC, ant_prm[iant].SEFD[0] * 1.0e26,
                                   ant_prm[iant].SEFD[1] * 1.0e26);
        if (TV_SWT == ON) {
          comment_disp(&cmnt, comment, string, ON);
        } else {
          printf("%s\n", string);
        }
      }
    }

/*
---- SRT Slew Time Setting ----  2007.10.15
*/

    SEPANG = sepang(src[NS[0]].s2k, src[NS[1]].s2k) * 180.0 / dpi;
    for (iant=GRT_NUM; iant<ANT_NUM; iant++) {
#ifdef __CMG_FULL_SPEC__
      if (SEPANG <= 1.0) {
        ant_prm[iant].slewt =  5.0;
      } else {
        ant_prm[iant].slewt =  5.0 + (SEPANG - 1.0) *  5.0;
      }
#elif defined __CMG_HALF_SPEC__
      if (SEPANG <= 1.0) {
        ant_prm[iant].slewt = 10.0;
      } else {
        ant_prm[iant].slewt = 10.0 + (SEPANG - 1.0) * 10.0;
      }
#endif
    }

/*
----------------------------------------------------
*/

    nbase =  (ANT_NUM * (ANT_NUM - 1)) / 2;
    I = nobs * ANT_NUM;
    for (ns=0; ns<SRC_NUM; ns++) {
      for (i=0; i<I; i++) {
        int_obs[ns][i].u         = (double)0.0;
        int_obs[ns][i].v         = (double)0.0;
        int_obs[ns][i].w         = (double)0.0;
        int_obs[ns][i].grp_delay = (double)0.0;
        int_obs[ns][i].ion_delay = (double)0.0;
        int_obs[ns][i].local_phs = (double)0.0;
        int_obs[ns][i].az        = (double)0.0;
        int_obs[ns][i].el        = (double)0.0;
        int_obs[ns][i].wt        = (float)src_flag[NS[ns]];
        int_obs[ns][i].amp_error = 1.0;
      }
    }

/*
---- Swtching Flagging -----------------------------
*/

    for (ns=0; ns<SRC_NUM; ns++) {
      for (i=0; i<6; i++) {
        timUTC[i] = TimUTC[i];
      }
      ut1_utc = UT1_UTC;
      for (iant=0; iant<SRT_NUM; iant++) {
        init_l[iant] = dpi;
      }

      for (iobs=0; iobs<nobs; iobs++) {
        timUTC[5] = TimUTC[5] + iobs;
        uvw_calc(src_flag[NS[ns]],
                ANT_NUM, GRT_NUM,  nobs, iobs, timUTC, ut1_utc,
                ant_prm, src[NS[ns]], sun,
                wvc, ion, Cw, Ci1, CI, wvc_ds[NS[ns]], ion_ds[NS[ns]], fqs_ds,
                OFF,  ERROR_FLAG, W, dUT1, int_obs[ns],
                OBS_T, OBS_p, dz[1], OFF,
                srt, init_l, TRK_NUM, trk_pos, srt_link,
                sep_angle_limit_from_earth_limb, BODY_X_SUN, MSTID);
      }
      az_rotation(GRT_NUM, nobs, int_obs[ns], ant_prm);
    }
    az_adjustment(GRT_NUM, nobs, int_obs, ant_prm);

#ifndef __DEMO__
    if (nswt != 0) {
      for (ns=0; ns<SRC_NUM; ns++) {
        noffset = (1 - ns) * (nswt / 2);
        for (iant=0; iant<ANT_NUM; iant++) {
          if (iant < GRT_NUM) {
            azl = ant_prm[iant].AZSV * ant_prm[iant].AZSV / ant_prm[iant].AZSA;
            ell = ant_prm[iant].ELSV * ant_prm[iant].ELSV / ant_prm[iant].ELSA;
          } else if (iant >= GRT_NUM) {
            nslewt = (int)rint(ant_prm[iant].slewt);
/*XXXXXXXX*/
            nslewt = 0;
/*XXXXXXXX*/
          }

          iobs = 0;
          while (iobs < nobs) {
            iave = (iobs - noffset) % nswt;
            i = iant * nobs + iobs;

            if (iave == 0) {
              if (iant < GRT_NUM) {
                nslewt = (int)rint(
                          slew_time(int_obs[0][i].az, int_obs[1][i].az, azl,
                                    ant_prm[iant].AZSV, ant_prm[iant].AZSA,
                                    int_obs[0][i].el, int_obs[1][i].el, ell,
                                    ant_prm[iant].ELSV, ant_prm[iant].ELSA));
              } else if (iant >= GRT_NUM && ERROR_FLAG[SRTAER] == ON) {
                pnt_err_tau = 0.684e-12 * gauss_dev();
/*
----
               [2009/07/31]
                 1-sigma Attitude Error : 1.9/1000 deg
             --> 1-sigma Delay Error due to the Attitude Error : 0.684 ps
               [2007/01/01]
                 5/1000-deg Attitude Error : 1.8-ps Delay Error
             --> 1/1000-deg Attitude Error : 0.36-ps Delay Error
----
*/

/*XXXXXXXX*/
                nslewt = 0;
/*XXXXXXXX*/
              }
            }

            if (nu[0] != nu[1] && ant_prm[iant].FQSST > nslewt) {
              nslewt = ant_prm[iant].FQSST;
            }

            if        (iave <  nslewt || iave >= nswt / 2) {
              int_obs[ns][i].wt = src_flag[NS[ns]] + (float)OFF_SOURCE;
            } else if (iave >= nslewt && iave <  nswt / 2) {
              int_obs[ns][i].wt = src_flag[NS[ns]];
              if (iant >= GRT_NUM && ERROR_FLAG[SRTAER] == ON) {
                int_obs[ns][i].local_phs += pnt_err_tau;
              }
            }
            iobs++;
          }
        }
      }
    }

/*
------------------------------
*/

    for (ns=0; ns<SRC_NUM; ns++) {
      pixel_calc(&pix_uvl[ns], &pix_mas[ns], wave_length[ns],
                 uv_max, &uv_factor[ns], FLDMAX, 1);
      lftmp = log10(pix_mas[ns]);
      if (lftmp < 0.0) {
        lftmp = pow(10.0, fabs(floor(lftmp)));
        pix_mas[ns] = rint(pix_mas[ns] * lftmp) / lftmp;
        pixel_calc(&pix_uvl[ns], &pix_mas[ns], wave_length[ns],
                   uv_max, &uv_factor[ns], FLDMAX, -1);
      }
    }

/*
----------------------------------------------------
*/

    if (TV_SWT == ON) {
      cpgslct(pgid[0]);
      cpgsci(0);
      cpgrect(0.0, 1.0, 0.235, 1.0);
    }

    for (ns=0; ns<SRC_NUM; ns++) {

/*aaaaaaaaaaaa*/
/****
      cpgsci(0);
      cpgrect(0.0, 1.0, 0.235, 1.0);
****/
/*aaaaaaaaaaaa*/

      src[NS[ns]].flux        = src_proc[ns].flux;
      src[NS[ns]].morphology  = src_proc[ns].morphology;

#ifdef __UV_DEBUG__
      sprintf(string, "uvtxt-%d.txt\0", ns+1);
      fp = fopen(string, "w");
#endif /*__UV_DEBUG__*/
      if (ns == 0) {
        sprintf(string, "**** Target data processed.      ****\0");
      } else {
        sprintf(string, "**** Reference data processed.   ****\0");
      }
      if (TV_SWT == OFF) {
        printf("%s\n", string);
      } else if (TV_SWT == ON) {
        comment_disp(&cmnt, comment, string, ON);
      }

      I         = nobs * nbase;
      if ((bluvw[ns] = (struct baseline_uvw *)
           calloc(I, sizeof(struct baseline_uvw))) == NULL) {
        printf("ARIS: ERROR: memory allocation: bluvw\n");

        if (SRT_NUM >= 1) {
          free (srt_link);
        }
        if (ERROR_FLAG[TDSECZ] == ON ||
           (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
          free_memory_block((void *)dz, 2);
        }
        free_memory_block((void *)int_obs, SRC_NUM);
        if (ERROR_FLAG[TWVTRB] == ON) {
          free_memory_block((void *)wvc_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[IONTRB] == ON) {
          free_memory_block((void *)ion_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[FQSERR] == ON) {
          free(fqs_ds);
        }
        return (0);
      }

      if ((fringe_weight[ns] = (float *)calloc(I, sizeof(float))) == NULL) {
        printf("ARIS: ERROR: memory allocation: fringe_weight.\n");

        if (SRT_NUM >= 1) {
          free (srt_link);
        }
        if (ERROR_FLAG[TDSECZ] == ON ||
           (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
          free_memory_block((void *)dz, 2);
        }
        free_memory_block((void *)int_obs, SRC_NUM);
        if (ERROR_FLAG[TWVTRB] == ON) {
          free_memory_block((void *)wvc_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[IONTRB] == ON) {
          free_memory_block((void *)ion_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[FQSERR] == ON) {
          free(fqs_ds);
        }
        free_memory_block((void *)bluvw,         ns);
        return (0);
      }

      for (i=0; i<I; i++) {
        bluvw[ns][i].u = (double)0.0;
        bluvw[ns][i].v = (double)0.0;
        bluvw[ns][i].w = (double)0.0;
        fringe_weight[ns][i] = 0.0;
      }

      I = nobs * nbase * nfrq;
      if ((frng[ns]  = (struct fringe *)
           calloc(I, sizeof(struct fringe))) == NULL) {
        printf("ARIS: ERROR: memory allocation: frng.\n");

        if (SRT_NUM >= 1) {
          free (srt_link);
        }
        if (ERROR_FLAG[TDSECZ] == ON ||
           (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
          free_memory_block((void *)dz, 2);
        }
        free_memory_block((void *)int_obs, SRC_NUM);
        if (ERROR_FLAG[TWVTRB] == ON) {
          free_memory_block((void *)wvc_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[IONTRB] == ON) {
          free_memory_block((void *)ion_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[FQSERR] == ON) {
          free(fqs_ds);
        }
        free_memory_block((void *)bluvw,         ns);
        free_memory_block((void *)fringe_weight, ns);
        return (0);
      }
      for (i=0; i<I; i++) {
        frng[ns][i].rl = (double)0.0;
        frng[ns][i].im = (double)0.0;
        frng[ns][i].wt = (double)0.0;
      }

/*
----------------------------------------------------
*/

      for (i=0; i<6; i++) {
        timUTC[i] = TimUTC[i];
      }
      ut1_utc = UT1_UTC;
      for (iant=0; iant<SRT_NUM; iant++) {
        init_l[iant] = dpi;
      }

      for (iobs=0; iobs<nobs; iobs++) {
        timUTC[5] = TimUTC[5] + iobs;
        uvw_calc(src_flag[NS[ns]],
                ANT_NUM, GRT_NUM,  nobs, iobs, timUTC, ut1_utc,
                ant_prm, src[NS[ns]], sun,
                wvc, ion, Cw, Ci1, CI, wvc_ds[NS[ns]], ion_ds[NS[ns]], fqs_ds,
                ON,  ERROR_FLAG, W, dUT1, int_obs[ns],
                OBS_T, OBS_p, dz[1], ON,
                srt, init_l, TRK_NUM, trk_pos, srt_link,
                sep_angle_limit_from_earth_limb, BODY_X_SUN, MSTID);
      }
      az_rotation(GRT_NUM, nobs, int_obs[ns], ant_prm);
      if (ns == 1) {
        az_adjustment(GRT_NUM, nobs, int_obs, ant_prm);
      }

/*
-------------------------------------------------------------
*/

      if ((mapr = (float *)calloc(FLDMAX*FLDMAX, sizeof(float))) == NULL) {
        printf("ERROR: ARIS: memory allocation: mapr.\n");
        if (SRT_NUM >= 1) {
          free (srt_link);
        }
        if (ERROR_FLAG[TDSECZ] == ON ||
           (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
          free_memory_block((void *)dz, 2);
        }
        free_memory_block((void *)int_obs, SRC_NUM);
        if (ERROR_FLAG[TWVTRB] == ON) {
          free_memory_block((void *)wvc_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[IONTRB] == ON) {
          free_memory_block((void *)ion_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[FQSERR] == ON) {
          free(fqs_ds);
        }
        free_memory_block((void *)bluvw,         SRC_NUM);
        free_memory_block((void *)fringe_weight, SRC_NUM);
        free_memory_block((void *)frng,          SRC_NUM);
        return (0);
      }
      if ((mapi = (float *)calloc(FLDMAX*FLDMAX, sizeof(float))) == NULL) {
        printf("ERROR: ARIS: memory allocation: mapi.\n");
        if (SRT_NUM >= 1) {
          free (srt_link);
        }
        if (ERROR_FLAG[TDSECZ] == ON ||
           (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
          free_memory_block((void *)dz, 2);
        }
        free_memory_block((void *)int_obs, SRC_NUM);
        if (ERROR_FLAG[TWVTRB] == ON) {
          free_memory_block((void *)wvc_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[IONTRB] == ON) {
          free_memory_block((void *)ion_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[FQSERR] == ON) {
          free(fqs_ds);
        }
        free_memory_block((void *)bluvw,         SRC_NUM);
        free_memory_block((void *)fringe_weight, SRC_NUM);
        free_memory_block((void *)frng,          SRC_NUM);
        free (mapr);
        return (0);
      }

      if (visibility_calc(mapr, mapi, FLDMAX, &pix_uvl[ns], &pix_mas[ns],
                          wave_length[ns], uv_max, &uv_factor[ns],
                          src[NS[ns]], ch_file+ns,
                          &cmnt, comment, ON, ns, pgid[0]) == NG) {
        printf("ERROE: aris: visibility_calc returns ERROR.\n");
        printf("ERROR: aris: abnormaly ended.\n");
        if (SRT_NUM >= 1) {
          free (srt_link);
        }
        if (ERROR_FLAG[TDSECZ] == ON ||
           (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
          free_memory_block((void *)dz, 2);
        }
        free_memory_block((void *)int_obs, SRC_NUM);
        if (ERROR_FLAG[TWVTRB] == ON) {
          free_memory_block((void *)wvc_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[IONTRB] == ON) {
          free_memory_block((void *)ion_ds,  SRC_NUM);
        }
        if (ERROR_FLAG[FQSERR] == ON) {
          free(fqs_ds);
        }
        free_memory_block((void *)bluvw,         SRC_NUM);
        free_memory_block((void *)fringe_weight, SRC_NUM);
        free_memory_block((void *)frng,          SRC_NUM);
        free (mapr);
        free (mapi);
        return (0);
      }

      if (TV_SWT == ON) {
        cpgsvp(0.0, 1.0, 0.0, 1.0);
        cpgswin(0.0, 1.0, 0.0, 1.0);
        cpgsch(0.65);
      }

/*
----------------------------------------------------------------
*/

      d_band_width = band_width / (double)nfrq;

      for (iant=0; iant<ANT_NUM; iant++) {
        if (iant >= BGN_ANT_I && iant < END_ANT_I) {
/********XXXXXXXXXX********/
          frq_coh_factor[ns] 
           = one_sec_coherence_factor_calc(nu[ns],
                                    ant_prm[iant].FRQSTD, 
                                    ant_prm[jant].FRQSTD);
#ifdef __CF_DEBUG__
          printf("## __CF_DEBUG__   %lf\n", frq_coh_factor[ns]);
#endif /* __CF_DEBUG__ */
/********XXXXXXXXXX********/
          for (jant=iant+1; jant<ANT_NUM; jant++) {
            if (jant >= BGN_ANT_J && jant < END_ANT_J) {

              ibase = baseline_number(ANT_NUM, iant, jant);
              if (ERROR_FLAG[THRMNS] == ON) {
                sigma = thermal_noise_cal(1.0, cfact,
                             ant_prm[iant].Dm[ns], ant_prm[jant].Dm[ns],
                             ant_prm[iant].Ae[ns], ant_prm[jant].Ae[ns],
                             1.0,  1.0,   d_band_width,  inttim);
              }

              d_lo_phs = 0.0;
              if (ERROR_FLAG[LOPOFS] == ON) {
                d_lo_phs = diff(ant_prm[iant].LOPHS[wave_id[ns]],
                                ant_prm[jant].LOPHS[wave_id[ns]]);
              }

              for (iobs=0; iobs<nobs; iobs++) {
                I = iant  * nobs + iobs;
                J = jant  * nobs + iobs;
                K = ibase * nobs + iobs;
                if (int_obs[ns][I].wt >= src_flag[NS[ns]] &&
                    int_obs[ns][J].wt >= src_flag[NS[ns]]) {
                  bluvw[ns][K].u = diff(int_obs[ns][I].u, int_obs[ns][J].u);
                  bluvw[ns][K].v = diff(int_obs[ns][I].v, int_obs[ns][J].v);
                  bluvw[ns][K].w = diff(int_obs[ns][I].w, int_obs[ns][J].w);

#ifdef __UV_DEBUG__
                  fprintf(fp, "%2d %2d %5d %15.4lf %15.4lf\n",
                         iant+1, jant+1, iobs, bluvw[ns][K].u, bluvw[ns][K].v);
#endif /* __UV_DEBUG__ */

	          vis_smoothing(&fr, &fi, mapr, mapi,
                              bluvw[ns][K].u, bluvw[ns][K].v,
                              FLDMAX, IFREF, JFREF, pix_uvl[ns]);
                  tau_err = diff(int_obs[ns][I].grp_delay,
                                 int_obs[ns][J].grp_delay);
                  ion_err = diff(int_obs[ns][I].ion_delay,
                                 int_obs[ns][J].ion_delay);
                  phs_err = diff(int_obs[ns][I].local_phs,
                                 int_obs[ns][J].local_phs);

                  if (ERROR_FLAG[THRMNS] == ON) {
                    SIGMA = sqrt(
                          (ant_prm[iant].Trx[ns]
                         + ant_prm[iant].Tsky[ns] / sin(int_obs[ns][I].el))
                        * (ant_prm[jant].Trx[ns]
                         + ant_prm[jant].Tsky[ns] / sin(int_obs[ns][J].el))
                                );
                  }

                  for (ifrq=0; ifrq<nfrq; ifrq++) {
                    L = (ibase * nobs + iobs) * nfrq + ifrq;
                    F = nu[ns] + (double)ifrq  * d_band_width;
                    fai_err = 2.0 * dpi * (F * tau_err
                                         + F * phs_err
                                         + ion_err / F) + d_lo_phs;
                    ar = cos(fai_err);
                    ai = sin(fai_err);
                    frng[ns][L].rl = fr * ar - fi * ai;
                    frng[ns][L].im = fr * ai + fi * ar;
                    frng[ns][L].wt = 1.0;

                    if (ERROR_FLAG[THRMNS] == ON) {
                      frng[ns][L].rl += SIGMA * sigma * gauss_dev();
                      frng[ns][L].im += SIGMA * sigma * gauss_dev();
                    }
                    if (ERROR_FLAG[AMPERR] == ON) {
                      amperr = frq_coh_factor[ns] * sqrt(
                        int_obs[ns][I].amp_error * int_obs[ns][J].amp_error);
                      frng[ns][L].rl *= amperr;
                      frng[ns][L].im *= amperr;
                    }
                  }
                  fringe_weight[ns][K] = src_flag[NS[ns]] + 1.0;
                } else {
                  fringe_weight[ns][K] = 0.0;
                }
              }
            }
          }
        }
      }
      free (mapr);
      free (mapi);
#ifdef __UV_DEBUG__
      fclose (fp);
#endif /*__UV_DEBUG__*/
    }

/*
----------------------------------------
*/

    for (ns=0; ns<SRC_NUM; ns++) {
      ndata = 0;
      for (iant=0; iant<ANT_NUM; iant++) {
        if (iant >= BGN_ANT_I && iant < END_ANT_I) {
          for (jant=iant+1; jant<ANT_NUM; jant++) {
            if (jant >= BGN_ANT_J && jant < END_ANT_J) {
              ibase = baseline_number(ANT_NUM, iant, jant);
              for (iobs=0; iobs<nobs; iobs++) {
                I = ibase * nobs + iobs;
                if (fringe_weight[ns][I] > 0.0) {
                  ndata++;
                }
              }
            }
          }
        }
      }
      if (ndata == 0 && ANT_NUM >= 2) {
        sprintf(string, "WARNING: ARIS: NO valid data for the source.\0");
        printf("%s\n", string);
        if (TV_SWT == ON) {
          comment_disp(&cmnt, comment, string, ON);
        }
        sprintf(string, "WARNING: Please check the observation situation.\0");
        printf("%s\n", string);
        if (TV_SWT == ON) {
          comment_disp(&cmnt, comment, string, ON);
        }
        sprintf(string, "WARNING: The problem may be solved, for example, \0");
        printf("%s\n", string);
        if (TV_SWT == ON) {
          comment_disp(&cmnt, comment, string, ON);
        }
        sprintf(string, "WARNING: if the observation time becomes longer.\0");
        printf("%s\n", string);
        if (TV_SWT == ON) {
          comment_disp(&cmnt, comment, string, ON);
        }
      }
    }

/*
----------------------------------------
*/


/*
---- ACA_DEMO ----
*/

    if (ARRAY_ID == ACA && AZEL_FIX == ON) {
      for (ns=0; ns<SRC_NUM; ns++) {
        for (iant=0; iant<GRT_NUM; iant++) {
          for (iobs=0; iobs<nobs; iobs++) {
            int_obs[ns][nobs*iant + iobs].az = fabs(src[NS[ns]].RA2k);
            int_obs[ns][nobs*iant + iobs].el = fabs(src[NS[ns]].DC2k);
          }
        }
      }
    }

/*
----------------------------------------------------
*/

    I = nobs * nbase;
    if ((fringe_weight[SRC_NUM_P1-1]  = (float *)calloc(I, sizeof(float)))
        == NULL) {
      printf("ARIS: ERROR: memory allocation: fringe_weight[%d]\n",
             SRC_NUM_P1 - 1);

      if (SRT_NUM >= 1) {
        free (srt_link);
      }
      if (ERROR_FLAG[TDSECZ] == ON ||
         (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
        free_memory_block((void *)dz, 2);
      }
      free_memory_block((void *)int_obs, SRC_NUM);
      if (ERROR_FLAG[TWVTRB] == ON) {
        free_memory_block((void *)wvc_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[IONTRB] == ON) {
        free_memory_block((void *)ion_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[FQSERR] == ON) {
        free(fqs_ds);
      }
      free_memory_block((void *)bluvw,         SRC_NUM);
      free_memory_block((void *)fringe_weight, SRC_NUM);
      free_memory_block((void *)frng,          SRC_NUM);
      return (0);
    }
    for (i=0; i<I; i++) {
      fringe_weight[SRC_NUM_P1-1][i] = (double)0.0;
    }

    I = nobs * nbase * nfrq;
    if ((frng[SRC_NUM_P1-1]  = (struct fringe *)
         calloc(I, sizeof(struct fringe))) == NULL) {
      printf("memory allocation error: frng[%d]\n", SRC_NUM_P1 - 1);

      if (SRT_NUM >= 1) {
        free (srt_link);
      }
      if (ERROR_FLAG[TDSECZ] == ON ||
         (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
        free_memory_block((void *)dz, 2);
      }
      free_memory_block((void *)int_obs, SRC_NUM);
      if (ERROR_FLAG[TWVTRB] == ON) {
        free_memory_block((void *)wvc_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[IONTRB] == ON) {
        free_memory_block((void *)ion_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[FQSERR] == ON) {
        free(fqs_ds);
      }
      free_memory_block((void *)bluvw,         SRC_NUM);
      free_memory_block((void *)fringe_weight, SRC_NUM_P1);
      free_memory_block((void *)frng,          SRC_NUM);
      return (0);
    }
    for (i=0; i<I; i++) {
      frng[SRC_NUM_P1-1][i].rl = (double)0.0;
      frng[SRC_NUM_P1-1][i].im = (double)0.0;
    }
    if (phase_reference(ANT_NUM, nfrq,
                    BGN_ANT_I, END_ANT_I, BGN_ANT_J, END_ANT_J,
                    nobs, nswt, nu, frng, fringe_weight) == -1) {
      printf("ARIS: PHASE_REFERNCE: ERROR\n");
      free_memory_block((void *)bluvw,         SRC_NUM);
      free_memory_block((void *)fringe_weight, SRC_NUM_P1);
      free_memory_block((void *)frng,          SRC_NUM_P1);

      if (SRT_NUM >= 1) {
        free (srt_link);
      }
      if (ERROR_FLAG[TDSECZ] == ON ||
         (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
        free_memory_block((void *)dz, 2);
      }
      free_memory_block((void *)int_obs, SRC_NUM);
      if (ERROR_FLAG[TWVTRB] == ON) {
        free_memory_block((void *)wvc_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[IONTRB] == ON) {
        free_memory_block((void *)ion_ds,  SRC_NUM);
      }
      if (ERROR_FLAG[FQSERR] == ON) {
        free(fqs_ds);
      }

      exit (-1);
    }

/*
------------------------------------------------------------
*/

#endif /* __DEMO__ */

    if (TV_SWT == ON) {
      bttn_box[0] = 0.20;
      bttn_box[1] = 0.80;
      bttn_box[2] = 0.235;
      bttn_box[3] = 0.235 + pitch;
      cursor_pos[0] = 0.5 * (bttn_box[0] + bttn_box[1]);
      cursor_pos[1] = 0.5 * (bttn_box[2] + bttn_box[3]);
      off_button(&i, "Continue?", bttn_box);
      while (1) {
        cpgcurs(cursor_pos, cursor_pos+1, string);
        if (button_chk(cursor_pos, bttn_box) == ON) {
          break;
        }
      }
    }

    proc_mode = menu_config(ANT_NUM, GRT_NUM,  SRT_NUM,  TRK_NUM,
                            BGN_ANT_I, END_ANT_I,
                            BGN_ANT_J, END_ANT_J,
                            nobs, TimUTC, UT1_UTC, ERROR_FLAG, nswt,
                            ant_prm, dz[1], int_obs, grt_elevation_limit,
                            wave_length, nu, nbase,
                            frng, fringe_weight, inttim, nfrq, band_width,
                            bluvw, src, sun,
                            pix_uvl, pix_mas, srt, trk_pos, srt_link,
                            BODY_X_SUN,
                            sep_angle_limit_from_earth_limb, OBS_T, OBS_p,
                            wvc_ds, ion_ds,
                            TV_SWT, cursor_pos, pgid[0], pgid[1]);

/*
-------------------------------
*/

    free_memory_block((void *)bluvw,         SRC_NUM);
    free_memory_block((void *)fringe_weight, SRC_NUM_P1);
    free_memory_block((void *)frng,          SRC_NUM_P1);

    if (proc_mode == OFF || proc_mode == NG) {
      break;
    }
  }

/*
===================================================================
*/

  cpgend();

/*
===================================================================
*/

  if (SRT_NUM >= 1) {
    free (srt_link);
  }
  if (ERROR_FLAG[TDSECZ] == ON ||
     (ERROR_FLAG[IDSECZ] == ON && ARRAY_ID != ACA)) {
    free_memory_block((void *)dz, 2);
  }
  free_memory_block((void *)int_obs, SRC_NUM);
  if (ERROR_FLAG[TWVTRB] == ON) {
    free_memory_block((void *)wvc_ds,  SRC_NUM);
  }
  if (ERROR_FLAG[IONTRB] == ON) {
    free_memory_block((void *)ion_ds,  SRC_NUM);
  }
  if (ERROR_FLAG[FQSERR] == ON) {
    free(fqs_ds);
  }

/*
===================================================================
*/
 
  return 1;
}
