#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>

/****
#define __DEBUG__
****/

int  source_position(struct source_parameter *src,
                     struct pair_src_info *pair_src,
                     struct char_src_info *ch_src,
                     int SEP_MODE, int POS_MODE)
{
  int    i, ns;
  double DPI;
  double ra, dc, vl;
  double dra, ddc;
  double sa, pa, mid_s[3], s[SRC_NUM][3];

/*
--------
*/

  DPI = dpi / 180.0;

  if (SEP_MODE == SRC_SEP1) {
    input_star_position(ch_src->tgt_ra, ch_src->tgt_dc,
                        &src[0].RA2k, &src[0].DC2k);
    input_star_position(ch_src->ref_ra, ch_src->ref_dc,
                        &src[1].RA2k, &src[1].DC2k);
    for (ns=0; ns<SRC_NUM; ns++) {
      src[ns].s2k[0] = cos(src[ns].DC2k) * cos(src[ns].RA2k);
      src[ns].s2k[1] = cos(src[ns].DC2k) * sin(src[ns].RA2k);
      src[ns].s2k[2] = sin(src[ns].DC2k);
      vl = vlen3(src[ns].s2k);
      src[ns].s2k[0] /= vl;
      src[ns].s2k[1] /= vl;
      src[ns].s2k[2] /= vl;
    }
    mid_s[0] = src[0].s2k[0] + src[1].s2k[0];
    mid_s[1] = src[0].s2k[1] + src[1].s2k[1];
    mid_s[2] = src[0].s2k[2] + src[1].s2k[2];
    pair_src->mid_ra = atan2(mid_s[1], mid_s[0]);
    pair_src->mid_dc = atan2(mid_s[2], vlen2(mid_s));
    mid_s[0] = cos(pair_src->mid_dc) * cos(pair_src->mid_ra);
    mid_s[1] = cos(pair_src->mid_dc) * sin(pair_src->mid_ra);
    mid_s[2] = sin(pair_src->mid_dc);

    s[0][0] = src[0].s2k[0];
    s[0][1] = src[0].s2k[1];
    s[0][2] = src[0].s2k[2];
    drotate(s[0], -1.0 * (pair_src->mid_ra), "z");
    drotate(s[0], pair_src->mid_dc,          "y");
    pair_src->dlt_ra = -2.0 * atan2(s[0][1], s[0][0])     / DPI;
    pair_src->dlt_dc = -2.0 * atan2(s[0][2], vlen2(s[0])) / DPI;
    pair_src->sepang = sepang(src[0].s2k, src[1].s2k)            / DPI;
    pair_src->posang = atan2(pair_src->dlt_ra, pair_src->dlt_dc) / DPI;

  } else if (SEP_MODE == SRC_SEP2) {
    if (       POS_MODE == SRC_POS1) {
      input_star_position(ch_src->tgt_ra, ch_src->tgt_dc,
                          &src[0].RA2k, &src[0].DC2k);
      ra = src[0].RA2k;
      dc = src[0].DC2k;

      src[0].s2k[0] = 1.0;
      src[0].s2k[1] = 0.0;
      src[0].s2k[2] = 0.0;
      dra =  0.5 * pair_src->dlt_ra * DPI;
      ddc =  0.5 * pair_src->dlt_dc * DPI;
      src[1].s2k[0] = cos(ddc) * cos(dra);
      src[1].s2k[1] = cos(ddc) * sin(dra);
      src[1].s2k[2] = sin(ddc);
      drotate(src[1].s2k,  dra, "z");
      drotate(src[1].s2k, -ddc, "y");

    } else if (POS_MODE == SRC_POS2) {
      input_star_position(ch_src->mid_ra,   ch_src->mid_dc,
                          &(pair_src->mid_ra), &(pair_src->mid_dc));
      ra = pair_src->mid_ra;
      dc = pair_src->mid_dc;

      dra = -0.5 * pair_src->dlt_ra * DPI;
      ddc = -0.5 * pair_src->dlt_dc * DPI;
      src[0].s2k[0] = cos(ddc) * cos(dra);
      src[0].s2k[1] = cos(ddc) * sin(dra);
      src[0].s2k[2] = sin(ddc);

      dra =  0.5 * pair_src->dlt_ra * DPI;
      ddc =  0.5 * pair_src->dlt_dc * DPI;
      src[1].s2k[0] = cos(ddc) * cos(dra);
      src[1].s2k[1] = cos(ddc) * sin(dra);
      src[1].s2k[2] = sin(ddc);
    }

    for (ns=0; ns<SRC_NUM; ns++) {
      drotate(src[ns].s2k, -dc, "y");
      drotate(src[ns].s2k,  ra, "z");
      vl = vlen3(src[ns].s2k);
      src[ns].s2k[0] /= vl;
      src[ns].s2k[1] /= vl;
      src[ns].s2k[2] /= vl;
      xyz2radec_rad(src[ns].s2k, &src[ns].RA2k, &src[ns].DC2k);
      src[ns].RA2k = atan2(src[ns].s2k[1], src[ns].s2k[0]);
      src[ns].DC2k = atan2(src[ns].s2k[2], vlen2(src[ns].s2k));
    }

    pair_src->sepang  = sepang(src[0].s2k, src[1].s2k)            / DPI;
    pair_src->posang  = atan2(pair_src->dlt_ra, pair_src->dlt_dc) / DPI;

  } else if (SEP_MODE == SRC_SEP3) {
    sa = pair_src->sepang * DPI;
    pa = pair_src->posang * DPI;

    if (       POS_MODE == SRC_POS1) {
      input_star_position(ch_src->tgt_ra, ch_src->tgt_dc,
                          &src[0].RA2k, &src[0].DC2k);
      ra = src[0].RA2k;
      dc = src[0].DC2k;

      dra =  0.0;
      ddc = -0.5 * sa;
      s[0][0] = cos(ddc) * cos(dra);
      s[0][1] = cos(ddc) * sin(dra);
      s[0][2] = sin(ddc);
      drotate(s[0], -pa, "x");

      dra =  0.0;
      ddc =  0.5 * sa;
      s[1][0] = cos(ddc) * cos(dra);
      s[1][1] = cos(ddc) * sin(dra);
      s[1][2] = sin(ddc);
      drotate(s[1], -pa, "x");

      dra = atan2(s[0][1], s[0][0]);
      ddc = atan2(s[0][2], vlen2(s[0]));
      drotate(s[1], -dra, "z");
      drotate(s[1],  ddc, "y");
      vl = vlen3(s[1]);
      s[1][0] /= vl;
      s[1][1] /= vl;
      s[1][2] /= vl;

      s[0][0] = 1.0;
      s[0][1] = 0.0;
      s[0][2] = 0.0;

      pair_src->dlt_ra = -2.0 * dra / DPI;
      pair_src->dlt_dc = -2.0 * ddc / DPI;

    } else if (POS_MODE == SRC_POS2) {
      input_star_position(ch_src->mid_ra, ch_src->mid_dc,
                          &(pair_src->mid_ra), &(pair_src->mid_dc));
      ra = pair_src->mid_ra;
      dc = pair_src->mid_dc;

      dra =  0.0;
      ddc = -0.5 * sa;
      s[0][0] = cos(ddc) * cos(dra);
      s[0][1] = cos(ddc) * sin(dra);
      s[0][2] = sin(ddc);
      dra =  0.0;
      ddc =  0.5 * sa;
      s[1][0] = cos(ddc) * cos(dra);
      s[1][1] = cos(ddc) * sin(dra);
      s[1][2] = sin(ddc);

      for (ns=0; ns<SRC_NUM; ns++) {
        drotate(s[ns], -pa, "x");
        vl = vlen3(s[ns]);
        s[ns][0] /= vl;
        s[ns][1] /= vl;
        s[ns][2] /= vl;
      }

      pair_src->dlt_ra = -2.0 * atan2(s[0][1], s[0][0])     / DPI;
      pair_src->dlt_dc = -2.0 * atan2(s[0][2], vlen2(s[0])) / DPI;
    }

    for (ns=0; ns<SRC_NUM; ns++) {
      src[ns].s2k[0] = s[ns][0];
      src[ns].s2k[1] = s[ns][1];
      src[ns].s2k[2] = s[ns][2];
      drotate(src[ns].s2k, -1.0 * dc, "y");
      drotate(src[ns].s2k,        ra, "z");
      vl = vlen3(src[ns].s2k);
      src[ns].s2k[0] /= vl;
      src[ns].s2k[1] /= vl;
      src[ns].s2k[2] /= vl;
      xyz2radec_rad(src[ns].s2k, &src[ns].RA2k, &src[ns].DC2k);
      src[ns].RA2k = atan2(src[ns].s2k[1], src[ns].s2k[0]);
      src[ns].DC2k = atan2(src[ns].s2k[2], vlen2(src[ns].s2k));
    }
  }

  if ((SEP_MODE != SRC_SEP1) && POS_MODE == SRC_POS1) {
    mid_s[0] = src[0].s2k[0] + src[1].s2k[0];
    mid_s[1] = src[0].s2k[1] + src[1].s2k[1];
    mid_s[2] = src[0].s2k[2] + src[1].s2k[2];
    pair_src->mid_ra = atan2(mid_s[1], mid_s[0]);
    pair_src->mid_dc = atan2(mid_s[2], vlen2(mid_s));
    mid_s[0] = cos(pair_src->mid_dc) * cos(pair_src->mid_ra);
    mid_s[1] = cos(pair_src->mid_dc) * sin(pair_src->mid_ra);
    mid_s[2] = sin(pair_src->mid_dc);
  }

#ifdef __DEBUG__
  printf("__STAR_POS_DEBUG_1__ : %s   %s\n", ch_src->tgt_ra,  ch_src->tgt_dc);
  printf("__STAR_POS_DEBUG_1__ : %s   %s\n", ch_src->ref_ra,  ch_src->ref_dc);
  printf("__STAR_POS_DEBUG_1__ : %s   %s\n", ch_src->mid_ra,  ch_src->mid_dc);
  printf("__STAR_POS_DEBUG_1__ : %s   %s\n", ch_src->sepang,  ch_src->posang);
  printf("__STAR_POS_DEBUG_1__ : %s   %s\n", ch_src->dlt_ra,  ch_src->dlt_dc);
#endif /*__DEBUG__*/

/*
---------------------------------------------------------
*/

  if (       SEP_MODE == SRC_SEP1) {
    sprintf(ch_src->dlt_ra, "%15.10lf\0", pair_src->dlt_ra);
    sprintf(ch_src->dlt_dc, "%15.10lf\0", pair_src->dlt_dc);
    sprintf(ch_src->sepang, "%15.10lf\0", pair_src->sepang);
    sprintf(ch_src->posang, "%15.10lf\0", pair_src->posang);
    output_star_position(ch_src->mid_ra, ch_src->mid_dc, mid_s);
  } else if (SEP_MODE == SRC_SEP2) {
    if (       POS_MODE == SRC_POS1) {
      output_star_position(ch_src->ref_ra, ch_src->ref_dc, src[1].s2k);
    } else if (POS_MODE == SRC_POS2) {
      output_star_position(ch_src->mid_ra, ch_src->mid_dc, mid_s);
    }
    sprintf(ch_src->sepang, "%15.10lf\0", pair_src->sepang);
    sprintf(ch_src->posang, "%15.10lf\0", pair_src->posang);
  } else if (SEP_MODE == SRC_SEP3) {
    if (       POS_MODE == SRC_POS1) {
      output_star_position(ch_src->ref_ra, ch_src->ref_dc, src[1].s2k);
    } else if (POS_MODE == SRC_POS2) {
      output_star_position(ch_src->mid_ra, ch_src->mid_dc, mid_s);
    }
    sprintf(ch_src->dlt_ra,    "%15.10lf\0", pair_src->dlt_ra);
    sprintf(ch_src->dlt_dc,    "%15.10lf\0", pair_src->dlt_dc);
  }

  while ((i=strlen(ch_src->sepang) - 1) >= 6) {
    if (*(ch_src->sepang+i) == '0') {
      *(ch_src->sepang+i) = '\0';
    } else {
      break;
    }
  }
  while ((i=strlen(ch_src->posang) - 1) >= 6) {
    if (*(ch_src->posang+i) == '0') {
      *(ch_src->posang+i) = '\0';
    } else {
      break;
    }
  }
  while ((i=strlen(ch_src->dlt_ra) - 1) >= 6) {
    if (*(ch_src->dlt_ra+i) == '0') {
      *(ch_src->dlt_ra+i) = '\0';
    } else {
      break;
    }
  }
  while ((i=strlen(ch_src->dlt_dc) - 1) >= 6) {
    if (*(ch_src->dlt_dc+i) == '0') {
      *(ch_src->dlt_dc+i) = '\0';
    } else {
      break;
    }
  }

#ifdef __DEBUG__
  printf("__STAR_POS_DEBUG_2__ : %s   %s\n", ch_src->tgt_ra,  ch_src->tgt_dc);
  printf("__STAR_POS_DEBUG_2__ : %s   %s\n", ch_src->ref_ra,  ch_src->ref_dc);
  printf("__STAR_POS_DEBUG_2__ : %s   %s\n", ch_src->mid_ra,  ch_src->mid_dc);
  printf("__STAR_POS_DEBUG_2__ : %s   %s\n", ch_src->sepang,  ch_src->posang);
  printf("__STAR_POS_DEBUG_2__ : %s   %s\n", ch_src->dlt_ra,  ch_src->dlt_dc);
#endif /*__DEBUG__*/

/*
---------------------------------------------------------
*/

  for (ns=0; ns<2; ns++) {
    src[ns].RA2k = atan2(src[ns].s2k[1], src[ns].s2k[0]);
    src[ns].DC2k = atan2(src[ns].s2k[2], vlen2(src[ns].s2k));

    src[ns].RA   = src[ns].RA2k;
    src[ns].DC   = src[ns].DC2k;
    src[ns].RA_e = src[ns].RA2k;
    src[ns].DC_e = src[ns].DC2k;
    for (i=0; i<3; i++) {
      src[ns].s[i]   = src[ns].s2k[i];
      src[ns].s_e[i] = src[ns].s2k[i];
    }
  }

/*
---------------------------------------------------------
*/

  return 0;
}
