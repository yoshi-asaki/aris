#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <aris.h>

/****
#define __DEBUG__
****/

int  array_config(
                  int    ARRAY_ID,
                  int    *wave_id,
                  int    SRT_NUM,
                  int    *GRT_NUM,
                  char   *station_code,
                  struct antenna_parameter *ant_prm,
                  int    ERR_RESET_SWT)
{
  int    i, j, nline;
  int    array_id;
  int    iant, IANT, ns;
  int    station_rec_flag, array_rec_flag;
  int    dd, mm;
  double ss, DPI;
  FILE   *fp;
  char   string[1000];
  struct antenna_parameter ant_tmp, srt_tmp;

/*
----------------
*/

  DPI = dpi / 180.0;
  IANT = 0;
  *GRT_NUM = 0;

/*
----------------
*/

  if ((fp = fopen("aris_input/antenna.prm", "r")) == NULL) {
    printf("ERROR: array_config: aris_input/antenna.prm not found.\n");
    return -1;
  }

  nline = 0;
  IANT  = 0;
  while (1) {
    if (fgets(string, sizeof(string), fp) == NULL) {
      break;
    } else {
      nline++;
    }

    if (strncmp(string, "BEGIN_ANT", 9) == 0) {
      station_rec_flag = OFF;
      array_rec_flag   = OFF;
      for (ns=0; ns<SRC_NUM; ns++) {
        ant_tmp.Dm[ns]   = 0.0;
        ant_tmp.Ae[ns]   = 0.0;
        ant_tmp.Trx[ns]  = 0.0;
        ant_tmp.Tsky[ns] = 0.0;
        ant_tmp.FLAG[ns] = OFF;
      }
      while (1) {
        if (fgets(string, sizeof(string), fp) == NULL) {
          printf("WARNING: something wrong with aris_input/antenna.prm.\n");
          printf("Check line %d in aris_input/antenna.prm.\n", nline);
          break;
        } else {
          nline++;
          if (strncmp(string, "END_ANT", 7) == 0) {
            break;
          } else {

/*
--------
*/

            if (strncmp(string, "STATION", 7) == 0) {
              i = 0;
              while (1) {
                if (string[i] == '"') {
                  break;
                }
                i++;
              }
              i++;
              j = 0;
              while (1) {
                if (string[i+j] == '"') {
                  break;
                }
                j++;
              }
              strncpy(ant_tmp.IDC, string+i, j);
              ant_tmp.IDC[j] = 0;
              if (ARRAY_ID == -1 && strncmp(station_code, ant_tmp.IDC, j) == 0) {
                station_rec_flag = ON;
              }
            }

/*
--------
*/

            if (strncmp(string, "ARRAY", 5) == 0) {
              i = 0;
              while (1) {
                if (string[i] == '"') {
                  break;
                }
                i++;
              }
              i++;
              j = 0;
              while (1) {
                if (string[i+j] == '"') {
                  break;
                }
                j++;
              }
              array_id = -100;
              if (strncmp(string+i, "VLBA", j) == 0) {
                array_id = VLBA;
              } else if (strncmp(string+i, "EVN", j) == 0) {
                array_id = EVN;
              } else if (strncmp(string+i, "HSA", j) == 0) {
                array_id = HSA;
              } else if (strncmp(string+i, "VERA", j) == 0) {
                array_id = VERA;
              } else if (strncmp(string+i, "JVN", j) == 0) {
                array_id = JVN;
              } else if (strncmp(string+i, "KVN", j) == 0) {
                array_id = KVN;
              } else if (strncmp(string+i, "LBA", j) == 0) {
                array_id = LBA;
              } else if (strncmp(string+i, "TRACKING_NETWORK", j) == 0) {
                array_id = TRACKING_NETWORK;
              } else if (strncmp(string+i, "ACA", j) == 0) {
                array_id = ACA;
              } else if (strncmp(string+i, "STAND_ALONE", j) == 0) {
                array_id = STAND_ALONE;
              } else if (strncmp(string+i, "ORBITING", j) == 0) {
                array_id = ORBITING;
              } else if (strncmp(string+i, "SLR_NETWORK", j) == 0) {
                array_id = SLR_NETWORK;
              }

              if (ARRAY_ID == ALL_ANT || ARRAY_ID == array_id) {
                ant_tmp.ARRAY = array_id;
                array_rec_flag = ON;
              }
            }

/*
--------
*/

            if (strncmp(string, "MOUNT", 5) == 0) {
              i = 0;
              while (1) {
                if (string[i] == '"') {
                  break;
                }
                i++;
              }
              i++;
              j = 0;
              while (1) {
                if (string[i+j] == '"') {
                  break;
                }
                j++;
              }
              if (strncmp(string+i, "ALAZ", j) == 0) {
                ant_tmp.MNTSTA = ALAZ;
              } else if (strncmp(string+i, "EQUA", j) == 0) {
                ant_tmp.MNTSTA = EQUA;
              } else if (strncmp(string+i, "ORBI", j) == 0) {
                ant_tmp.MNTSTA = ORBI;
              }
            }

/*
--------
*/

            if (strncmp(string, "FREQ_STANDARD", 13) == 0) {
              i = 0;
              while (1) {
                if (string[i] == '"') {
                  break;
                }
                i++;
              }
              i++;
              j = 0;
              while (1) {
                if (string[i+j] == '"') {
                  break;
                }
                j++;
              }
              if (strncmp(string+i, "H_M", j) == 0) {
                ant_tmp.MNTSTA = H_M;
              } else if (strncmp(string+i, "CSO_10", j) == 0) {
                ant_tmp.MNTSTA = CSO_10;
              } else if (strncmp(string+i, "CSO_100", j) == 0) {
                ant_tmp.MNTSTA = CSO_100;
              }
            }

/*
--------
*/

            if (strncmp(string, "POSITION", 8) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%lf,%lf,%lf",
                     &ant_tmp.XYZ[0],
                     &ant_tmp.XYZ[1],
                     &ant_tmp.XYZ[2]);
            }

/*
--------
*/

            if (strncmp(string, "POS_OFFSET", 10) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%lf,%lf,%lf",
                     &ant_tmp.OFS[0],
                     &ant_tmp.OFS[1],
                     &ant_tmp.OFS[2]);
            }

/*
--------
*/

            if (strncmp(string, "STAXOF", 6) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%lf", &ant_tmp.STAXOF);
            }

/*
--------
*/

            if (strncmp(string, "LONGITUDE", 9) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%d %d %lf", &dd, &mm, &ss);
              if (dd >= 0) {
                ant_tmp.LLH[0] = (double)dd
                                        + (double)mm/60.0 + ss/3600.0;
              } else {
                ant_tmp.LLH[0] = fabs((double)dd)
                                        + (double)mm/60.0 + ss/3600.0;
                ant_tmp.LLH[0] *= -1.0;
              }
              ant_tmp.LLH[0] *= DPI;
            }

/*
--------
*/

            if (strncmp(string, "LATITUDE", 8) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%d %d %lf", &dd, &mm, &ss);
              if (dd >= 0) {
                ant_tmp.LLH[1] = (double)dd
                                        + (double)mm/60.0 + ss/3600.0;
              } else {
                ant_tmp.LLH[1] = fabs((double)dd)
                                        + (double)mm/60.0 + ss/3600.0;
                ant_tmp.LLH[1] *= -1.0;
              }
              ant_tmp.LLH[1] *= DPI;
            }

/*
--------
*/

            if (strncmp(string, "ALTITUDE", 8) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%lf", &ant_tmp.LLH[2]);
            }

/*
--------
*/

            if (strncmp(string, "AZ_RATE_ACCEL", 13) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%lf,%lf",
                     &ant_tmp.AZSV, &ant_tmp.AZSA);
            }

/*
--------
*/

            if (strncmp(string, "EL_RATE_ACCEL", 13) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%lf,%lf",
                     &ant_tmp.ELSV, &ant_tmp.ELSA);
            }

/*
--------
*/

            if (strncmp(string, "FREQ_SWT_LAG", 12) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%lf", &ant_tmp.FQSST);
            }

/*
--------
*/

            if (strncmp(string, "SLEW_TIME", 9) == 0) {
              i = 0;
              while (1) {
                if (string[i] == ':') {
                  break;
                }
                i++;
              }
              i++;
              sscanf(string+i, "%lf", &ant_tmp.slewt);
            }

/*
--------
*/

            if (strncmp(string, "L_BAND", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == L_BAND) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "S_BAND", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == S_BAND) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "C_BAND", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == C_BAND) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "X_BAND", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == X_BAND) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "KU_BAND", 7) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == KU_BAND) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "K_BAND", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == K_BAND) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "Q_BAND", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == Q_BAND) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "W_BAND", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == W_BAND) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND01", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND01) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND02", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND02) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }    
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND03", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND03) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                }    
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND04", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND04) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }    
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND05", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND05) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND06", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND06) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND07", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND07) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND08", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND08) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND09", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND09) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

            if (strncmp(string, "BAND10", 6) == 0) {
              for (ns=0; ns<SRC_NUM; ns++) {
                if (wave_id[ns] == BAND10) {
                  i = 0;
                  while (1) {
                    if (string[i] == ':') {
                      break;
                    }
                    i++;
                  }
                  i++;
                  sscanf(string+i, "%lf,%lf,%lf,%lf",
                         &ant_tmp.Dm[ns],  &ant_tmp.Ae[ns],
                         &ant_tmp.Trx[ns], &ant_tmp.Tsky[ns]);
                  ant_tmp.FLAG[ns] = ON;
                }
              }
            }

/*
--------
*/

          }
        }
      }

      if (station_rec_flag == ON || array_rec_flag == ON) {

        ant_tmp.UFL = ON;

        if (ant_tmp.XYZ[0] == 0.0 &&
            ant_tmp.XYZ[1] == 0.0 &&
            ant_tmp.XYZ[2] == 0.0 &&
              (ant_tmp.LLH[0] != 0.0 ||
               ant_tmp.LLH[1] != 0.0 ||
               ant_tmp.LLH[2] != 0.0)) {
          J_system_geocentric_equatorial_rectangular_coordinate(
            ant_tmp.LLH[0], ant_tmp.LLH[1], ant_tmp.LLH[2],
            ant_tmp.XYZ);
        }

        if (ant_tmp.LLH[0] == 0.0 &&
            ant_tmp.LLH[1] == 0.0 &&
            ant_tmp.LLH[2] == 0.0 &&
              (ant_tmp.XYZ[0] != 0.0 ||
               ant_tmp.XYZ[1] != 0.0 ||
               ant_tmp.XYZ[2] != 0.0)) {
          J_system_geocentric_equatorial_rectangular_coordinate2llh(
            &ant_tmp.LLH[0], &ant_tmp.LLH[1], &ant_tmp.LLH[2],
            ant_tmp.XYZ);
        }

        if (ERR_RESET_SWT == ON) {
          ant_tmp.ERR[0] =  ant_tmp.XYZ[0];
          ant_tmp.ERR[1] =  ant_tmp.XYZ[1];
          ant_tmp.ERR[2] =  ant_tmp.XYZ[2];
        }

        if (ant_tmp.ARRAY == VLBA) {
          ant_prm[IANT] = ant_tmp;
          (*GRT_NUM)++;
        } else if (ant_tmp.ARRAY == EVN)  {
          ant_prm[IANT] = ant_tmp;
          (*GRT_NUM)++;
        } else if (ant_tmp.ARRAY == HSA)  {
          ant_prm[IANT] = ant_tmp;
          (*GRT_NUM)++;
        } else if (ant_tmp.ARRAY == VERA) {
          ant_prm[IANT] = ant_tmp;
          (*GRT_NUM)++;
        } else if (ant_tmp.ARRAY == JVN)  {
          ant_prm[IANT] = ant_tmp;
          (*GRT_NUM)++;
        } else if (ant_tmp.ARRAY == KVN)  {
          ant_prm[IANT] = ant_tmp;
          (*GRT_NUM)++;
        } else if (ant_tmp.ARRAY == LBA)  {
          ant_prm[IANT] = ant_tmp;
          (*GRT_NUM)++;
        } else if (ant_tmp.ARRAY == ACA)  {
          ant_prm[IANT] = ant_tmp;
          (*GRT_NUM)++;
        } else if (ant_tmp.ARRAY == STAND_ALONE) {
          ant_prm[IANT] = ant_tmp;
          (*GRT_NUM)++;
        } else if (ant_tmp.ARRAY == ORBITING) {
          srt_tmp       = ant_tmp;
/****
        } else if (ant_tmp.ARRAY == TRACKING_NETWORK) {
        } else if (ant_tmp.ARRAY == SLR_NETWORK) {
****/
        }

#ifdef __DEBUG__
        printf("__DEBUG__  %d  %s  %d  %d\n",
            IANT, ant_prm[IANT].IDC, ant_prm[IANT].ARRAY, ant_prm[IANT].UFL);
        printf("__DEBUG__  %lf  %lf  %lf  %lf  %lf  %lf\n", 
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2],
            ant_prm[IANT].OFS[0], ant_prm[IANT].OFS[1], ant_prm[IANT].OFS[2]);
        printf("__DEBUG__  %lf  %lf  %lf\n", 
            ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2]);
#endif

        IANT++;
      }
    }
  }

  fclose (fp);

  if (SRT_NUM >= 1) {
    for (iant=0; iant<SRT_NUM; iant++) {
      ant_prm[IANT] = srt_tmp;
      if (SRT_NUM == 1) {
        sprintf(ant_prm[IANT].IDC, "SRT\0",      iant+1);
      } else {
        if (iant+1 < 10) {
          sprintf(ant_prm[IANT].IDC, "SRT_0%1d\0", iant+1);
        } else if (iant+1 >= 10 && iant+1 < 100) {
          sprintf(ant_prm[IANT].IDC, "SRT_%2d\0",  iant+1);
        }
      }
      IANT++;
    }
  }

  return IANT;
}
