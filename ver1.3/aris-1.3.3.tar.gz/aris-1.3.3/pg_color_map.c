#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <aris.h>


void pg_color_map(int   N,
                  int   cenx,        int   ceny,
                  float resx,        float resy,
                  float bias,        float width,
                  float xwidth,      float ywidth,
                  float px,          float py,
                  float *dist,
                  float x1, float x2, float y1, float y2,
                  char *labelx, char *labely, char *title,
                  int  NEGATIVE_COMP_SWT, int X_REVERSE,
                  char *mode)
{
  int    i, j;
  int    nxs, nxe, nys, nye;
  float  xmin, xmax, ymin, ymax;
  float  e, f, tx[2], ty[2];
  float  CR, CB, CG;
  float  lev, tr[6];

/*
---------------------------
*/

  nxs = cenx - (int)(0.5 * xwidth / resx);
  nxe = cenx + (int)(0.5 * xwidth / resx);
  nys = ceny - (int)(0.5 * ywidth / resy);
  nye = ceny + (int)(0.5 * ywidth / resy);

  xmin = (float)(nxs - N/2) * resx + px;
  ymin = (float)(nys - N/2) * resy + py;
  xmax = (float)(nxe - N/2) * resx + px;
  ymax = (float)(nye - N/2) * resy + py;

  cpgsvp(x1, x2, y1, y2);
  if (X_REVERSE == OFF) {
    cpgswin(xmin, xmax, ymin, ymax);
  } else if (X_REVERSE == ON) {
    cpgswin(xmax, xmin, ymin, ymax);
  }

  if (nxs < 0) {
    nxs = 0;
  }
  if (nxe > N) {
    nxe = N;
  }
  if (nys < 0) {
    nys = 0;
  }
  if (nye > N) {
    nye = N;
  }

/*
-------------------------------------------
*/

  if (NEGATIVE_COMP_SWT == ON) {
    if (bias >= 0.0) {
      e = - bias / width;
    } else if (bias < 0.0) {
      if (bias + width < 0.0) {
        e = - bias / width;
      } else {
        e = 0.0;
      }
    }
  } else if (NEGATIVE_COMP_SWT == OFF) {
    e =  bias / width;
  }

  set_color(e, &CR, &CG, &CB, NEGATIVE_COMP_SWT, mode);
  cpgscr(10, CR, CG, CB);
  cpgsci(10);
  cpgrect(xmin, xmax, ymin, ymax);

/*
-------------------------------------------
*/

  for (i=nxs; i<nxe; i++) {
    for (j=nys; j<nye; j++) {
      f = *(dist + N*i + j);
      if (NEGATIVE_COMP_SWT == ON) {
        if (bias >= 0.0) {
          e = (f - bias) / width;
        } else if (bias < 0.0) {
          if (bias + width < 0.0) {
            e = (f - bias) / width;
          } else {
            if (f < 0.0) {
              e = f / fabs(bias);
            } else {
              e = f / (width - fabs(bias));
            }
          }
        }
      } else if (NEGATIVE_COMP_SWT == OFF) {
        e = (f - bias) / width;
      }

      if (e != 0.0) {
        set_color(e, &CR, &CG, &CB, NEGATIVE_COMP_SWT, mode);
        cpgscr(10, CR, CG, CB);
        cpgsci(10);
        tx[0] = resx * (float)(i - N/2);
        tx[1] = tx[0] + resx;
        ty[0] = resy * (float)(j - N/2);
        ty[1] = ty[0] + resy;
        cpgrect(tx[0], tx[1], ty[0], ty[1]);
      }
    }
  }

/*
-------------------------------------------
*/

  cpgsci(1);
  cpgbox("BCNT", 0.0, 0, "BCNT", 0.0, 0);
  cpglab(labelx, labely, title);


#ifdef __AAAA__
  tr[0] =  -resx * (float)(N / 2 + 1) + px;
  tr[1] =   resx;
  tr[2] =   0.0;

  tr[3] =  -resy * (float)(N / 2 + 1) + py;
  tr[4] =   0.0;
  tr[5] =   resy;

  f = 0.0;
  for (i=0; i<N/2; i++) {
    for (j=0; j<N/2; j++) {
      e = *(dist + N*i + j);
      *(dist + N*i + j) = *(dist + N*j + i);
      *(dist + N*j + i) = e;
      if (e > f) {
        f = e;
      }
    }
  }

  for (i=N/2+1; i<N; i++) {
    for (j=0; j<N/2; j++) {
      e = *(dist + N*i + j);
      *(dist + N*i + j) = *(dist + N*j + i);
      *(dist + N*j + i) = e;
      if (e > f) {
        f = e;
      }
    }
  }

  f *= 0.00001;
  for (i=0; i<20; i++) {
    lev = f * pow(2.0, (float)i);
    cpgcont(dist, N, N, 1, N, 1, N, &lev, -1, tr);
  }
#endif


}
