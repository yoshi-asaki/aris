#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>

#define BOTTUN_NUM     200

#define BLSEL_SECTION   10
#define TROPOS_SECTION  20
#define IONOS_SECTION   30
#define ORBIT_SECTION   40
#define SRTATT_SECTION  50
#define T_WAVE_SECTION  60
#define R_WAVE_SECTION  80
#define BW_SECTION     100
#define FRCHAN_SECTION 110
#define CFACT_SECTION  120
#define T_FLUX_SECTION 130
#define R_FLUX_SECTION 150
#define SWTCYC_SECTION 170
#define TRK_SECTION    180

#define ALLBL            0
#define GG_BL            1
#define GS_BL            2
#define SS_BL            3

#define VERY_GOOD        0
#define GOOD             1
#define TYPICAL          2
#define POOR             3

#define HALF             0
#define NOMINAL          1
#define DOUBLE           2

double  band_width_set(int  );
double  cfact_set(int  );
int     channel_num_set(int  );
void    srtatt_button_disp(int , int , int ,
                           float , float , char [][10], float [][4]);

/****
#define __DEBUG__
****/

int   err_parameter_set(int ANT_NUM,  int GRT_NUM,  int SRT_NUM,
                int *BGN_ANT_I, int *END_ANT_I,
                int *BGN_ANT_J, int *END_ANT_J,
                int array_id,
                double *CW,     double *CI,
                struct atmospheric_zenith_error *dz,
                struct source_parameter  *src,
                struct morphology_file_name *ch_file,
                int *wave_id, double *wave_length, double *nu,
                double *band_width, int *FRCHAN_NUM,
                double *cfact,
                int *ERROR_FLAG,
                struct srt_orbit_parameter *srt,
                int *BODY_X_SUN,
                int *nswt,
                struct antenna_parameter *ant_prm,
                int    *TRK_NUM,
                struct antenna_position  *trk_pos,
                struct comment_param *cmnt,
                char comment[][NCOMLEN],
                int TVSWT, float *cursor_pos, int PGMENU_ID)
{
  int    idum, I, J;
  int    BL_SELECT;
  int    i, j, k, iant, ns;
  char   *c, string[100];
  float  bttn_box[BOTTUN_NUM][4], y_pos, srtatt_y_pos;
  double swt_cyc_time;
  double orbit_error_ap, orbit_error_pe;
  double tdscz, idscz;
  FILE   *fp;

  int    blsel_num, blsel_code[5];
  char   blsel_name[5][20];

  int    TRP_CONDITION, trp_num, trp_code[4];
  char   trp_name[4][10];

  int    ION_CONDITION, ion_num, ion_code[3];
  char   ion_name[3][10];

  int    itrk, trk_num;
  int    TRK_GEN_CMD=2;
  char   trk_name[TRKMAX][10];
  int    trk_priority[TRKMAX], priority[TRKMAX];

  int    wave_num, wave_code[N_WAVE], wave_swt[SRC_NUM][N_WAVE];
  char   wave_name[N_WAVE][10];

  int    srtatt_num, srtatt_code;
  char   srtatt_name[10][10];
  float  pitch;

  char   ch_tdscz[20], ch_idscz[20];
  char   ch_tflux[20], ch_rflux[20], ch_swttim[20];
  char   ch_orbae[20], ch_orbpe[20];
  char   ch_tmorp[20], ch_rmorp[20];
  char   ch_tpost[20], ch_rpost[20];

  int    bw_id, bw_num, cfact_id, cfact_num;
  int    bw_code[10], cfact_code[10];
  char   bw_name[10][10], cfact_name[10][10];

  int    frchan_id, frchan_num, frchan_code[10];
  char   frchan_name[10][10];

  char   g_name[5][10];

  int    tgt_morpho_num, ref_morpho_num;
  char   tgt_morphology[SRC_MORPH_CANDIDATE][50];
  char   ref_morphology[SRC_MORPH_CANDIDATE][50];
  int    tgt_proc_flag[SRC_MORPH_CANDIDATE];
  int    ref_proc_flag[SRC_MORPH_CANDIDATE];
  int    FLX_SECT=2, MRP_SECT=3;

/*
---------------------------------------------------------
*/

  pitch   = 0.03;

/*
---------------------------------------------------------
*/

  sprintf(blsel_name[0], "Full\0");
  sprintf(blsel_name[1], "Ground-Ground\0");
  sprintf(blsel_name[2], "Ground-Space\0");
  sprintf(blsel_name[3], "Space-Space\0");
  blsel_code[0] = OFF;
  if (SRT_NUM >= 2) {
    blsel_num = 4;
  } else {
    blsel_num = 3;
  }
  for (i=0; i<blsel_num; i++) {
    blsel_code[i] = OFF;
  }

/*
---------------------------------------------------------
*/

  trp_num = 4;
  sprintf(trp_name[0], "Very Good\0");
  sprintf(trp_name[1], "Good\0");
  sprintf(trp_name[2], "Typical\0");
  sprintf(trp_name[3], "Poor\0");
  for (i=0; i<trp_num; i++) {
    trp_code[i] = OFF;
  }

/*
---------------------------------------------------------
*/

  ion_num = 3;
  sprintf(ion_name[0], "Half\0");
  sprintf(ion_name[1], "Nominal\0");
  sprintf(ion_name[2], "Double\0");
  for (i=0; i<ion_num; i++) {
    ion_code[i] = OFF;
  }

/*
---------------------------------------------------------
*/

  srtatt_num = 3;
  sprintf(srtatt_name[0], "+X SUN\0");
  sprintf(srtatt_name[1], "-X SUN\0");
  sprintf(srtatt_name[2], "NO MATTER\0");
  srtatt_code = 2;

/*
---------------------------------------------------------
*/

  wave_num = 14;
/********
  sprintf(wave_name[ 0], "1.6GHz\0");
  sprintf(wave_name[ 1], "2.2GHz\0");
  sprintf(wave_name[ 2], "4.8GHz\0");
  sprintf(wave_name[ 3], "8.4GHz\0");
  sprintf(wave_name[ 4], "15 GHz\0");
  sprintf(wave_name[ 5], "22 GHz\0");
  sprintf(wave_name[ 6], "43 GGz\0");
  sprintf(wave_name[ 7], "86 GHz\0");
  sprintf(wave_name[ 8], "86(2)GHz\0");
  sprintf(wave_name[ 9], "129GHz\0");
  sprintf(wave_name[10], "172GHz\0");
  sprintf(wave_name[11], "258GHz\0");
  sprintf(wave_name[12], "350GHz\0");
  sprintf(wave_name[13], "387GHz\0");
********/
  sprintf(wave_name[ 0], "L Band\0");
  sprintf(wave_name[ 1], "S Band\0");
  sprintf(wave_name[ 2], "C Band\0");
  sprintf(wave_name[ 3], "X Band\0");
  sprintf(wave_name[ 4], "Ku Band\0");
  sprintf(wave_name[ 5], "K Band\0");
  sprintf(wave_name[ 6], "Q Band\0");
  sprintf(wave_name[ 7], "W Band\0");
  sprintf(wave_name[ 8], "BAND 3\0");
  sprintf(wave_name[ 9], "BAND 4\0");
  sprintf(wave_name[10], "BAND 5\0");
  sprintf(wave_name[11], "BAND 6\0");
  sprintf(wave_name[12], "BAND 7\0");
  sprintf(wave_name[13], "BAND 8\0");
  wave_code[ 0] = L_BAND;
  wave_code[ 1] = S_BAND;
  wave_code[ 2] = C_BAND;
  wave_code[ 3] = X_BAND;
  wave_code[ 4] = KU_BAND;
  wave_code[ 5] = K_BAND;
  wave_code[ 6] = Q_BAND;
  wave_code[ 7] = W_BAND;
  wave_code[ 8] = BAND03;
  wave_code[ 9] = BAND04;
  wave_code[10] = BAND05;
  wave_code[11] = BAND06;
  wave_code[12] = BAND07;
  wave_code[13] = BAND08;
  for (ns=0; ns<SRC_NUM; ns++) {
    for (i=0; i<wave_num; i++) {
      wave_swt[ns][i] = OFF;
    }
  }

/*
---------------------------------------------------------
*/

  bw_num = 9;
  sprintf(bw_name[0], "4MHz\0");
  sprintf(bw_name[1], "8MHz\0");
  sprintf(bw_name[2], "16MHz\0");
  sprintf(bw_name[3], "32MHz\0");
  sprintf(bw_name[4], "128MHz\0");
  sprintf(bw_name[5], "256MHz\0");
  sprintf(bw_name[6], "512MHz\0");
  sprintf(bw_name[7], "1024MHz\0");
  sprintf(bw_name[8], "4096MHz\0");
  for (i=0; i<bw_num; i++) {
    bw_code[i] = OFF;
  }

/*
---------------------------------------------------------
*/

  frchan_num = 5;
  sprintf(frchan_name[0], "1CH\0");
  sprintf(frchan_name[1], "4CH\0");
  sprintf(frchan_name[2], "8CH\0");
  sprintf(frchan_name[3], "16CH\0");
  sprintf(frchan_name[4], "32CH\0");
  for (i=0; i<frchan_num; i++) {
    frchan_code[i] = OFF;
  }

/*
---------------------------------------------------------
*/

  cfact_num = 2;
  sprintf(cfact_name[0], "1 bit\0");
  sprintf(cfact_name[1], "2 bit\0");
  for (i=0; i<cfact_num; i++) {
    cfact_code[i] = OFF;
  }

/*
---------------------------------------------------------
*/

  tgt_morpho_num = SRC_MORPH_CANDIDATE;
  for (i=0; i<tgt_morpho_num; i++) {
    if (i == 0) {
      sprintf(tgt_morphology[0], "Single Point\0");
    } else if (i == 1) {
      sprintf(tgt_morphology[1], "Multi-Component\0");
    } else if (i == 2) {
      sprintf(tgt_morphology[2], "Disk & Jet-CJet\0");
    } else if (i == 3) {
      sprintf(tgt_morphology[3], "Disk & VSOP2-Jet\0");
    } else if (i == 4) {
      sprintf(tgt_morphology[4], "AIPS CC Table\0");
    } else if (i == 5) {
      sprintf(tgt_morphology[5], "Blackhole Shadow\0");
    }
  }

  ref_morpho_num = SRC_MORPH_CANDIDATE;
  for (i=0; i<ref_morpho_num; i++) {
    if (i == 0) {
      sprintf(ref_morphology[0], "Single Point\0");
    } else if (i == 1) {
      sprintf(ref_morphology[1], "Multi-Component\0");
    } else if (i == 2) {
      sprintf(ref_morphology[2], "Disk & Jet-CJet\0");
    } else if (i == 3) {
      sprintf(ref_morphology[3], "Disk & VSOP2-Jet\0");
    } else if (i == 4) {
      sprintf(ref_morphology[4], "AIPS CC Table\0");
    } else if (i == 5) {
      sprintf(ref_morphology[5], "Blackhole Shadow\0");
    }
  }

/*
---------------------------------------------------------
*/

  sprintf(g_name[0], "Lo(high)\0");
  sprintf(g_name[1], "GRT err\0");

/*
---------------------------------------------------------
*/

  *CW                = 0.0;
  *CI                = 0.0;
  orbit_error_ap     = 0.0;
  orbit_error_pe     = 0.0;
  *BODY_X_SUN        = 0;
  trk_num            = 0;
  wave_id[0]         = 5;
  wave_id[1]         = 5;
  bw_id              = 0;
  frchan_id          = 0;
  cfact_id           = 0;
  src[0].flux        = 1.0;
  src[1].flux        = 1.0;
  src[0].morphology  = SRC_POINT;
  src[1].morphology  = SRC_POINT;
  src[0].positionID  = 0;
  src[1].positionID  = 1;
  swt_cyc_time       = 60.0;
  BL_SELECT          = ALLBL;
  TRP_CONDITION      = TYPICAL;
  ION_CONDITION      = NOMINAL;

  for (itrk=0; itrk<TRKMAX; itrk++) {
    trk_priority[itrk] = 0;
    priority[itrk]     = 0;
  }

  if ((fp = fopen("aris_input/sim.prm", "r")) != NULL) {
    while (1) {
      if (fgets(string, sizeof(string), fp) == NULL) {
        break;
      } else {
        string[strlen(string)-1] = '\0';
      }

      if (       strncmp(string, "BASELINE SELECT     ", 20) == 0) {
        sscanf(string+20, "%d", &BL_SELECT);
      } else if (strncmp(string, "TROPOS CONDITION    ", 20) == 0) {
        sscanf(string+20, "%d", &TRP_CONDITION);
      } else if (strncmp(string, "IONOS CONDITION     ", 20) == 0) {
        sscanf(string+20, "%d", &ION_CONDITION);
      } else if (strncmp(string, "TROPOS ZENITH ERROR ", 20) == 0) {
        sscanf(string+20, "%lf", &tdscz);
        if (strlen(string+20) == 0) {
          sprintf(ch_tdscz, "0\0");
        } else {
          char_copy(ch_tdscz, string+20);
        }
      } else if (strncmp(string, "IONOS ZENITH ERROR  ", 20) == 0) {
        sscanf(string+20, "%lf", &idscz);
        if (strlen(string+20) == 0) {
          sprintf(ch_idscz, "0\0");
        } else {
          char_copy(ch_idscz, string+20);
        }
      } else if (strncmp(string, "ORBIT ERROR APOGEE  ", 20) == 0) {
        sscanf(string+20, "%lf", &orbit_error_ap);
        if (strlen(string+20) == 0) {
          sprintf(ch_orbae, "0\0");
        } else {
          char_copy(ch_orbae, string+20);
        }
        orbit_error_ap *= 1.0e-2;
      } else if (strncmp(string, "ORBIT ERROR PERIGEE ", 20) == 0) {
        sscanf(string+20, "%lf", &orbit_error_pe);
        if (strlen(string+20) == 0) {
          sprintf(ch_orbpe, "0\0");
        } else {
          char_copy(ch_orbpe, string+20);
        }
        orbit_error_pe *= 1.0e-2;
      } else if (strncmp(string, "X_AXIS_SUN_ANGLE    ", 20) == 0) {
        sscanf(string+20, "%d", BODY_X_SUN);
        if (*BODY_X_SUN > 0) {
          srtatt_code = 0;
        } else if (*BODY_X_SUN < 0) {
          srtatt_code = 1;
        } else if (*BODY_X_SUN == 0) {
          srtatt_code = 2;
        }
      } else if (strncmp(string, "TRACKING NETWORK    ", 20) == 0) {
        trk_num = tracking_station_name_read(trk_num,  string+20,
                                             trk_name, priority);
      } else if (strncmp(string, "TGT WAVE ID         ", 20) == 0) {
        sscanf(string+20, "%d", &wave_id[0]);
      } else if (strncmp(string, "REF WAVE ID         ", 20) == 0) {
        sscanf(string+20, "%d", &wave_id[1]);
      } else if (strncmp(string, "BAND WIDTH          ", 20) == 0) {
        sscanf(string+20, "%d", &bw_id);
      } else if (strncmp(string, "FREQUENCY CHANNEL   ", 20) == 0) {
        sscanf(string+20, "%d", &frchan_id);
      } else if (strncmp(string, "COHERENCE FACTOR    ", 20) == 0) {
        sscanf(string+20, "%d", &cfact_id);
      } else if (strncmp(string, "SWITCHING CYC TIME  ", 20) == 0) {
        sscanf(string+20, "%lf", &swt_cyc_time);
        if (strlen(string+20) == 0) {
          sprintf(ch_swttim, "0\0");
        } else {
          char_copy(ch_swttim, string+20);
        }
      } else if (strncmp(string, "TGT FLUX DENSITY    ", 20) == 0) {
        sscanf(string+20, "%lf", &src[0].flux);
        if (strlen(string+20) == 0) {
          sprintf(ch_tflux, "0\0");
        } else {
          char_copy(ch_tflux, string+20);
        }
      } else if (strncmp(string, "TGT POSITION        ", 20) == 0) {
        sscanf(string+20, "%d", &src[0].positionID);
      } else if (strncmp(string, "TGT MORPHOLOGY      ", 20) == 0) {
        sscanf(string+20, "%d", &src[0].morphology);
      } else if (strncmp(string, "TGT MULTI COMPONENT ", 20) == 0) {
        sscanf(string+20, "%s", ch_file[0].mcm);
      } else if (strncmp(string, "TGT CC TABLE        ", 20) == 0) {
        sscanf(string+20, "%s", ch_file[0].cct);
      } else if (strncmp(string, "TGT BHS MODEL       ", 20) == 0) {
        sscanf(string+20, "%s", ch_file[0].bhs);
      } else if (strncmp(string, "REF FLUX DENSITY    ", 20) == 0) {
        sscanf(string+20, "%lf", &src[1].flux);
        if (strlen(string+20) == 0) {
          sprintf(ch_rflux, "0\0");
        } else {
          char_copy(ch_rflux, string+20);
        }
      } else if (strncmp(string, "REF POSITION        ", 20) == 0) {
        sscanf(string+20, "%d", &src[1].positionID);
      } else if (strncmp(string, "REF MORPHOLOGY      ", 20) == 0) {
        sscanf(string+20, "%d", &src[1].morphology);
      } else if (strncmp(string, "REF MULTI COMPONENT ", 20) == 0) {
        sscanf(string+20, "%s", ch_file[1].mcm);
      } else if (strncmp(string, "REF CC TABLE        ", 20) == 0) {
        sscanf(string+20, "%s", ch_file[1].cct);
      } else if (strncmp(string, "REF BHS MODEL       ", 20) == 0) {
        sscanf(string+20, "%s", ch_file[1].bhs);
      }
    }
    fclose (fp);
  }

  blsel_code[BL_SELECT] = ON;

  if (array_id == ACA) {
    TRP_CONDITION = -1;
    ION_CONDITION = -1;
  } else {
    trp_code[TRP_CONDITION] = ON;
    ion_code[ION_CONDITION] = ON;
  }

  wave_swt[0][wave_select(wave_id[0], &wave_length[0], &nu[0])]  = ON;
  wave_swt[1][wave_select(wave_id[1], &wave_length[1], &nu[1])]  = ON;
  bw_code[bw_id]           = ON;
  frchan_code[frchan_id]   = ON;
  *FRCHAN_NUM = channel_num_set(frchan_id);
  cfact_code[cfact_id]     = ON;
  *TRK_NUM = tracking_init(trk_num, priority, trk_priority, trk_name, trk_pos);

/*
---------------------------------------------------------
*/

  if (TVSWT == OFF) {

/*
----------------------------------------------------
*/

    if (array_id == ACA) {
      BL_SELECT == ALLBL;
    } else {
      while (1) {
        if (SRT_NUM >= 1) {
          printf("1. Full  2. Ground-Ground  3.Ground-Space  ");
          if (SRT_NUM >= 2) {
            printf("4. Space-Space    ");
          }
          printf("0. EXIT (CR->%d) : ", BL_SELECT+1);
          if (fgets(string, sizeof(string), stdin) == NULL) {
            printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
            return (-1);
          }
          if (string[0] == '\n') {
            break;
          } else {
            sscanf(string, "%d", &idum);
            if (idum == 0) {
              return (-1);
            } else if ((idum >= 1 && idum <= 3) ||
                       (idum == 4 && SRT_NUM >= 2)) {
              BL_SELECT = idum - 1;
              break;
            }
          }
        } else if (SRT_NUM == 0) {
          printf("1. Ground-Ground    0. EXIT (CR->%d) : ", BL_SELECT+1);
          if (fgets(string, sizeof(string), stdin) == NULL) {
            printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
            return (-1);
          }
          if (string[0] == '\n') {
            break;
          } else {
            sscanf(string, "%d", &idum);
            if (idum == 0) {
              return (-1);
            } else if (idum == 1) {
              BL_SELECT = ALLBL;
              break;
            }
          }
        }
      }
    }

/*
----------------------------------------------------
*/

    if (ERROR_FLAG[TWVTRB] == ON && array_id != ACA) {
      printf("Tropospheric Condition:\n");
      printf("1. Very Good  ");
      printf("2. Good     ");
      printf("3. Typical  ");
      printf("4. Poor (CR->%d) : ", TRP_CONDITION+1);
      while (1) {
        if (fgets(string, sizeof(string), stdin) == NULL) {
          printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
          return (-1);
        }
        if (string[0] == '\n') {
          break;
        } else {
          sscanf(string, "%d", &idum);
          if (idum >= 1 && idum <= trp_num) {
            TRP_CONDITION = idum - 1;
            break;
          }
        }
      }
    }

/*
----------------------------------------------------
*/

    if ((ERROR_FLAG[IONTRB] == ON)
      && array_id != ACA) {
      printf("Ionospheric Noise Power:\n");
      printf("1. Half Condition  ");
      printf("2. Nominal Codition  ");
      printf("3. Double Condition (CR->%d) : ", ION_CONDITION+1);

      while (1) {
        if (fgets(string, sizeof(string), stdin) == NULL) {
          printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
          return (-1);
        }
        if (string[0] == '\n') {
          break;
        } else {
          sscanf(string, "%d", &idum);
          if (idum >= 1 && idum <= ion_num) {
            ION_CONDITION = idum - 1;
            break;
          }
        }
      }
    }

/*
----------------------------------------------------
*/

    if (ERROR_FLAG[TDSECZ] == ON && GRT_NUM > 0) {
      printf("Input Tropospheric Zenith Error [cm] (CR->%lf[cm]) : ", tdscz);

      if (fgets(ch_tdscz, sizeof(ch_tdscz), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (ch_tdscz[0] == '\n') {
        sprintf(ch_tdscz, "%lf\0", tdscz);
      } else {
        sscanf(ch_tdscz, "%lf", &tdscz);
        ch_tdscz[strlen(ch_tdscz)-1] = '\0';
      }
    }

/*
----------------------------------------------------
*/

    if (ERROR_FLAG[IDSECZ] == ON && GRT_NUM > 0) {
      printf("Input Ionospheric Zenith Error [TECU] (CR->%lf[TECU]) : ", idscz);
      if (fgets(ch_idscz, sizeof(ch_idscz), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (ch_idscz[0] == '\n') {
        sprintf(ch_idscz, "%lf\0", idscz);
      } else {
        sscanf(ch_idscz, "%lf", &idscz);
        ch_idscz[strlen(ch_idscz)-1] = '\0';
      }
    }

/*
----------------------------------------------------
*/

    if (ERROR_FLAG[APOSER] == ON && SRT_NUM > 0) {
      printf("Input the Orbit Error at Apogee  [cm] (CR->%lf[cm]) : ",
             orbit_error_ap * 1.0e2);
      if (fgets(ch_orbae, sizeof(ch_orbae), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (ch_orbae[0] == '\n') {
        sprintf(ch_orbae, "%lf\0", orbit_error_ap * 1.0e+2);
      } else {
        sscanf(ch_orbae, "%lf", &orbit_error_ap);
        orbit_error_ap *= 1.0e-2;
        ch_orbae[strlen(ch_orbae)-1] = '\0';
      }

      printf("Input the Orbit Error at Perigee [cm] (CR->%lf[cm]) : ",
             orbit_error_pe * 1.0e2);
      if (fgets(ch_orbpe, sizeof(ch_orbpe), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (ch_orbpe[0] == '\n') {
        sprintf(ch_orbpe, "%lf\0", orbit_error_pe * 1.0e+2);
      } else {
        sscanf(ch_orbpe, "%lf", &orbit_error_pe);
        orbit_error_pe *= 1.0e-2;
        ch_orbpe[strlen(ch_orbpe)-1] = '\0';
      }
    }

/*
----------------------------------------------------
*/

    if (SRT_NUM >= 1) {
      printf("Tracking Network\n");
      for (itrk=0; itrk<*TRK_NUM; itrk++) {
        printf("%d. %s  ", itrk+1, trk_name[itrk]);
        if ((itrk+1)%7 == 0) {
          printf("\n");
        }
      }
      if (*TRK_NUM%7 != 0) {
        printf("\n");
      }
      printf("Select tracking stations : ");
      printf("(CR->");
      for (itrk=0; itrk<*TRK_NUM; itrk++) {
        if (trk_priority[itrk] >= 1 && trk_priority[itrk] <= 9) {
          printf("%1d", trk_priority[itrk]);
        } else if (trk_priority[itrk] >= 10) {
          *c = trk_priority[itrk] - 10 + 'a';
          printf("%1s", c);
        } else if (trk_priority[itrk] == 0) {
          printf("0");
        }
      }
      printf(") : ");
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] != '\n') {
        for (itrk=0; itrk<*TRK_NUM; itrk++) {
          if (string[itrk] >= '1' && string[itrk] <= '9') {
            trk_priority[itrk] = string[itrk] - '0';
          } else if (string[itrk] >= 'a' && string[itrk] <= 'z') {
            trk_priority[itrk] = string[itrk] - 'a' + 10;
          } else {
            trk_priority[itrk] = 0;
          }
        }
      }

      trk_num = 0;
      for (itrk=0; itrk<*TRK_NUM; itrk++) {
        if (trk_priority[itrk] >= 1 && trk_priority[itrk] <= 9) {
          printf("%1d", trk_priority[itrk]);
          trk_num++;
        } else if (trk_priority[itrk] >= 10) {
          *c = trk_priority[itrk] - 10 + 'a';
          printf("%1s", c);
          trk_num++;
        } else if (trk_priority[itrk] == 0) {
          printf("0");
        }
      }
      printf("\n");
    }

/*
----------------------------------------------------
*/

    if (SRT_NUM >= 1 && trk_num >= 1) {
      printf("SRT Attitude (CR->%d) :\n", srtatt_code+1);
      printf("( 1. PLUS  X-axis -> SUN )\n");
      printf("( 2. MINUS X-axis -> SUN )\n");
      printf("( 3. does not matter.    ) : ");
      while (1) {
        if (fgets(string, sizeof(string), stdin) == NULL) {
          printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
          return (-1);
        }
        if (string[0] == '\n') {
          break;
        }
        sscanf(string, "%d", &srtatt_code);
        if (srtatt_code >= 1 && srtatt_code <= 3) {
          srtatt_code--;
          break;
        } else {
          printf("Invalid input: again : ");
        }
      }
    }

/*
----------------------------------------------------
*/

    printf("Wave Band (Target)\n");
    I = 0;
    for (i=0; i<=wave_num/5; i++) {
      for (j=0; j<5; j++) {
        printf("%2d. %s     ", I+1, wave_name[I]);
        I++;
        if (I == wave_num) {
          break;
        }
      }
      printf("\n");
    }
    printf("(CR->%d) : ",
           1 + wave_select(wave_id[0], &wave_length[0], &nu[0]));
    while (1) {
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] == '\n') {
        break;
      } else {
        sscanf(string, "%d", &idum);
        if (idum >= 1 && idum <= wave_num) {
          wave_id[0] = wave_code[idum-1];
          break;
        }
      }
    }

    printf("Wave Band (Reference)\n");
    I = 0;
    for (i=0; i<=wave_num/5; i++) {
      for (j=0; j<5; j++) {
        printf("%2d. %s     ", I+1, wave_name[I]);
        I++;
        if (I == wave_num) {
          break;
        }
      }
      printf("\n");
    }
    printf("(CR->%d) : ",
           1 + wave_select(wave_id[1], &wave_length[1], &nu[1]));
    while (1) {
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] == '\n') {
        break;
      } else {
        sscanf(string, "%d", &idum);
        if (idum >= 1 && idum <= wave_num) {
          wave_id[1] = wave_code[idum-1];
          break;
        }
      }
    }

/*
----------------------------------------------------
*/

    printf("Observing Band Width\n");
    k = 0;
    for (i=0; i<bw_num/4+1; i++) {
      for (j=0; j<4; j++) {
        printf("%2d. %s  ", k+1, bw_name[k]);
        k++;
        if (k == bw_num) {
          break;
        }
      }
      printf("\n");
    }
    printf("(CR->%d) : ", bw_id+1);
    while (1) {
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] == '\n') {
        break;
      } else {
        if (string[0]-'0' >= 1 && string[0]-'0' <= bw_num) {
          bw_id = string[0] - '0' - 1;
          break;
        } else {
          printf("Invalid. Enter again: ");
        }
      }
    }
    *band_width = band_width_set(bw_id);

/*
----------------------------------------------------
*/

    printf("Frequency Channel\n");
    printf("[1. 1CH   2. 4CH   3. 8CH   4. 16CH  5. 32CH ]\n");
    printf("(CR->%d) : ", frchan_id+1);
    while (1) {
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] == '\n') {
        break;
      } else {
        if (string[0]-'0' >= 1 && string[0]-'0' <= frchan_num) {
          frchan_id = string[0] - '0' - 1;
          break;
        } else {
          printf("Invalid. Enter again: ");
        }
      }
    }
    *FRCHAN_NUM = channel_num_set(frchan_id);

/*
----------------------------------------------------
*/

    printf("Sampling Bit Number [1.1-bit  2.2-bit] (CR->%d) : ", cfact_id+1);
    while (1) {
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] == '\n') {
        break;
      } else {
        if (string[0]-'0' >= 1 && string[0]-'0' <= 2) {
          cfact_id = string[0] - '0' - 1;
          break;
        } else {
          printf("Invalid. Enter again: ");
        }
      }
    }
    *cfact = cfact_set(cfact_id);

/*
----------------------------------------------------
*/

    printf("Switching Cycle Time [sec] (CR->%lf) : ", swt_cyc_time);
    if (fgets(string, sizeof(string), stdin) == NULL) {
      printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
      return (-1);
    }
    if (string[0] != '\n') {
      sscanf(string, "%lf", &swt_cyc_time);
    }
    *nswt    = (int)rint(swt_cyc_time);
    if (*nswt % 2 == 1) {
      (*nswt)++;
      printf("Switching cycle time is changed to %d [sec].\n", *nswt);
    }
    swt_cyc_time = (double)(*nswt);
    sprintf(ch_swttim, "%d", *nswt);

/*
----------------------------------------------------
*/

    printf("Target Position    : 1. Source-1    2. Source-2\n");
    printf("Select number (CR->%d) : ", src[0].positionID + 1);
    if (fgets(ch_tpost, sizeof(ch_tpost), stdin) == NULL) {
      printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
      return (-1);
    }
    if (ch_tpost[0] == '\n') {
      sprintf(ch_tpost, "%d\0", src[0].positionID);
    } else {
      sscanf(ch_tpost, "%d", &src[0].positionID);
      ch_tpost[strlen(ch_tpost)-1] = '\0';
      src[0].positionID--;
    }

    printf("Target Morphology :\n");
    for (i=0; i<tgt_morpho_num; i++) {
      printf("%d. %s\n", i+1, tgt_morphology[i]);
    }
    printf("Select number (CR->%d) : ", src[0].morphology + 1);
    if (fgets(ch_tmorp, sizeof(ch_tmorp), stdin) == NULL) {
      printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
      return (-1);
    }
    if (ch_tmorp[0] == '\n') {
      sprintf(ch_tmorp, "%d\0", src[0].morphology);
    } else {
      sscanf(ch_tmorp, "%d", &src[0].morphology);
      ch_tmorp[strlen(ch_tmorp)-1] = '\0';
      src[0].morphology--;
    }

    if (src[0].morphology == SRC_MULTI_COMP) {
      printf("Multi-Component ASCII Data File : \n");
      if (strlen(ch_file[0].mcm) != 0) {
        printf("CR->%s : ", ch_file[0].mcm);
      }
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] != '\n') {
        sscanf(string, "%s", ch_file[0].mcm);
      }
    } else if (src[0].morphology == SRC_CC_COMP) {
      printf("CC Table File Name : \n");
      if (strlen(ch_file[0].cct) != 0) {
        printf("CR->%s : ", ch_file[0].cct);
      }
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] != '\n') {
        sscanf(string, "%s", ch_file[0].cct);
      }
    } else if (src[0].morphology == SRC_BHS_MOD) {
      printf("BHS Model Name : \n");
      if (strlen(ch_file[0].bhs) != 0) {
        printf("CR->%s : ", ch_file[0].bhs);
      }
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] != '\n') {
        sscanf(string, "%s", ch_file[0].bhs);
      }
    }

    if (src[0].morphology == SRC_POINT         ||
        src[0].morphology == SRC_MULTI_COMP    ||
        src[0].morphology == SRC_DISK_JETCJET  ||
        src[0].morphology == SRC_DISK_VSOP2JET) {
      printf("Target Total Flux [Jy]   (CR->%lf) : ", src[0].flux);
      if (fgets(ch_tflux, sizeof(ch_tflux), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (ch_tflux[0] == '\n') {
        sprintf(ch_tflux, "%lf\0", src[0].flux);
      } else {
        sscanf(ch_tflux, "%lf", &src[0].flux);
        ch_tflux[strlen(ch_tflux)-1] = '\0';
      }
    }

/*
--------
*/

    printf("Reference Position : 1. Source-1    2. Source-2\n");
    printf("Select number (CR->%d) : ", src[1].positionID + 1);
    if (fgets(ch_rpost, sizeof(ch_rpost), stdin) == NULL) {
      printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
      return (-1);
    }
    if (ch_rpost[0] == '\n') {
      sprintf(ch_rpost, "%d\0", src[1].positionID);
    } else {
      sscanf(ch_rpost, "%d", &src[1].positionID);
      ch_rpost[strlen(ch_rpost)-1] = '\0';
      src[1].positionID--;
    }

    printf("Reference Morphology :\n");
    for (i=0; i<ref_morpho_num; i++) {
      printf("%d. %s\n", i+1, ref_morphology[i]);
    }
    printf("Select number (CR->%d) : ", src[1].morphology + 1);
    if (fgets(ch_rmorp, sizeof(ch_rmorp), stdin) == NULL) {
      printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
      return (-1);
    }
    if (ch_rmorp[0] == '\n') {
      sprintf(ch_rmorp, "%d\0", src[1].morphology);
    } else {
      sscanf(ch_rmorp, "%d", &src[1].morphology);
      ch_rmorp[strlen(ch_rmorp)-1] = '\0';
      src[1].morphology--;
    }

    if (src[1].morphology == SRC_MULTI_COMP) {
      printf("Multi-Component ASCII Data File : \n");
      if (strlen(ch_file[1].mcm) != 0) {
        printf("CR->%s : ", ch_file[1].mcm);
      }
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] != '\n') {
        sscanf(string, "%s", ch_file[1].mcm);
      }
    } else if (src[1].morphology == SRC_CC_COMP) {
      printf("CC Table File Name : \n");
      if (strlen(ch_file[1].cct) != 0) {
        printf("CR->%s : ", ch_file[1].cct);
      }
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] != '\n') {
        sscanf(string, "%s", ch_file[1].cct);
      }
    } else if (src[1].morphology == SRC_BHS_MOD) {
      printf("BHS Model Name : \n");
      if (strlen(ch_file[1].bhs) != 0) {
        printf("CR->%s : ", ch_file[1].bhs);
      }
      if (fgets(string, sizeof(string), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (string[0] != '\n') {
        sscanf(string, "%s", ch_file[1].bhs);
      }
    }

    if (src[1].morphology == SRC_POINT         ||
        src[1].morphology == SRC_MULTI_COMP    ||
        src[1].morphology == SRC_DISK_JETCJET  ||
        src[1].morphology == SRC_DISK_VSOP2JET) {
      printf("Reference Total Flux [Jy]   (CR->%lf) : ", src[1].flux);
      if (fgets(ch_rflux, sizeof(ch_rflux), stdin) == NULL) {
        printf("ERROR: ERR_PARAMETER SET: Invalid input.\n");
        return (-1);
      }
      if (ch_rflux[1] == '\n') {
        sprintf(ch_rflux, "%lf\0", src[1].flux);
      } else {
        sscanf(ch_rflux, "%lf", &src[1].flux);
        ch_rflux[strlen(ch_rflux)-1] = '\0';
      }
    }

/*
----------------------------------------------------
*/

  } else if (TVSWT == ON) {

/*
----------------------------------------------------
*/

    cpgslct(PGMENU_ID);
    cpgpap(1.5*pgpap_prm, 1.10);
    cpgsch(1.5*pgpap_prm/13.0);
    cpgsvp(0.0, 1.0, 0.0, 1.0);
    cpgswin(0.0, 1.0, 0.0, 1.1);

/*
----------------------
*/

    comment_init(cmnt, comment, ON);
    *nswt    = (int)rint(swt_cyc_time);
    if (*nswt % 2 == 1) {
      (*nswt)++;
      printf("Switching cycle time is changed to %d [sec].\n", *nswt);
    }
    swt_cyc_time = (double)(*nswt);

/*
----------------------
*/

    I = 0;
    bttn_box[I][0] = 0.02;
    bttn_box[I][1] = 0.45;
    bttn_box[I][2] = 0.235;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "GO\0", bttn_box[I]);
    I = 1;
    bttn_box[I][0] = 0.55;
    bttn_box[I][1] = 0.98;
    bttn_box[I][2] = 0.235;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    off_button(&idum, "EXIT (without saving parameters)\0", bttn_box[I]);

/*
----------------------
*/

    y_pos = 1.065;

    if (SRT_NUM >= 1) {
      cpgsfs(2);
      cpgrect(0.020, 0.980, y_pos-0.005, y_pos+0.034);
      cpgsfs(1);

      cpgtext(0.035, y_pos + 0.3 * pitch, "Baseline Select\0");

      I = BLSEL_SECTION;
      for (i=0; i<3; i++) {
        bttn_box[I][0] = 0.200 + 0.200 * (float)i;
        bttn_box[I][1] = bttn_box[I][0] + 0.18;
        bttn_box[I][2] = y_pos;
        bttn_box[I][3] = bttn_box[I][2] + pitch;
        I++;
      }
      if (SRT_NUM >= 2) {
        i = 3;
        bttn_box[I][0] = 0.300 + 0.200 * (float)i;
        bttn_box[I][1] = bttn_box[I][0] + 0.18;
        bttn_box[I][2] = y_pos;
        bttn_box[I][3] = bttn_box[I][2] + pitch;
      }

      for (i=0; i<blsel_num; i++) {
        I = BLSEL_SECTION + i;
        if (blsel_code[i] == ON) {
          on_button(&blsel_code[i], blsel_name[i], bttn_box[I]);
        } else if (blsel_code[i] == OFF) {
          off_button(&blsel_code[i], blsel_name[i], bttn_box[I]);
        }
      }
    } else {
      BL_SELECT = ALLBL;
    }

/*
-------------
*/

    y_pos = 1.021;

    if (ERROR_FLAG[TWVTRB] == ON && array_id != ACA) {
      cpgsfs(2);
      cpgrect(0.020, 0.980, y_pos-0.041, y_pos+0.036);
      cpgsfs(1);

      cpgtext(0.035, y_pos + 0.35 * pitch, "Tropospheric Condition\0");

      I = TROPOS_SECTION;
      for (i=0; i<trp_num; i++) {
        bttn_box[I][0] = 0.225 + 0.110 * (float)i;
        bttn_box[I][1] = bttn_box[I][0] + 0.100;
        bttn_box[I][2] = y_pos;
        bttn_box[I][3] = bttn_box[I][2] + pitch;
        I++;
      }

      for (i=0; i<trp_num; i++) {
        I = TROPOS_SECTION + i;
        if (trp_code[i] == ON) {
          on_button(&trp_code[i], trp_name[i], bttn_box[I]);
        } else {
          off_button(&trp_code[i], trp_name[i], bttn_box[I]);
        }
      }
    }

/*
-------------
*/

    y_pos = 0.985;

    if ((ERROR_FLAG[IONTRB] == ON)
      && array_id != ACA) {
      cpgtext(0.035, y_pos + 0.3 * pitch, "Ionospheric Condition\0");

      I = IONOS_SECTION;
      for (i=0; i<ion_num; i++) {
        bttn_box[I][0] = 0.225 + 0.110 * (float)(i + 1);
        bttn_box[I][1] = bttn_box[I][0] + 0.100;
        bttn_box[I][2] = y_pos;
        bttn_box[I][3] = bttn_box[I][2] + pitch;
        I++;
      }

      for (i=0; i<ion_num; i++) {
        I = IONOS_SECTION + i;
        if (ion_code[i] == ON) {
          on_button(&ion_code[i], ion_name[i], bttn_box[I]);
        } else {
          off_button(&ion_code[i], ion_name[i], bttn_box[I]);
        }
      }
    }

/*
--------------------
*/

    y_pos = 0.939;

    if (ERROR_FLAG[TDSECZ] == ON && GRT_NUM > 0) {
      cpgsfs(2);
      cpgrect(0.020, 0.485, y_pos-0.045, y_pos+0.035);
      cpgsfs(1);

      I = TROPOS_SECTION + trp_num;
      cpgsci(1);
      cpgtext(0.035, y_pos + 0.3 * pitch,
              "Tropospheric Zenith Delay Error [cm]\0");
      bttn_box[I][0] = 0.36;
      bttn_box[I][1] = bttn_box[I][0] + 0.11;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
              0.0, 1.0, ch_tdscz);
      cpgsci(1);
    }

/*
--------------------
*/

    y_pos -= 0.040;
    if (ERROR_FLAG[IDSECZ] == ON && GRT_NUM > 0) {
      I = IONOS_SECTION + ion_num;
      cpgsci(1);
      cpgtext(0.035, y_pos + 0.3 * pitch,
              "Ionospheric Zenith Delay Error [TECU]\0");
      bttn_box[I][0] = 0.36;
      bttn_box[I][1] = bttn_box[I][0] + 0.11;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
              0.0, 1.0, ch_idscz);
      cpgsci(1);
    }

/*
-------------
*/

    if (ERROR_FLAG[APOSER] == ON && SRT_NUM > 0) {
      I = ORBIT_SECTION;

      y_pos = 0.939;

      cpgsfs(2);
      cpgrect(0.515, 0.980, y_pos-0.045, y_pos+0.035);
      cpgsfs(1);

      bttn_box[I][0] = 0.860;
      bttn_box[I][1] = bttn_box[I][0] + 0.11;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      cpgsci(1);
      cpgtext(0.535, y_pos + 0.3 * pitch,
              "SRT displacement at Apogee [cm]\0");
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
              0.0, 1.0, ch_orbae);
      cpgsci(1);

      I = ORBIT_SECTION + 1;

      y_pos -= 0.040;
      bttn_box[I][0] = 0.860;
      bttn_box[I][1] = bttn_box[I][0] + 0.11;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      cpgsci(1);
      cpgtext(0.535, y_pos + 0.3 * pitch,
              "SRT displacement at Perigee [cm]\0");
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
              0.0, 1.0, ch_orbpe);
      cpgsci(1);
    }

/*
--------------------
*/

    if (SRT_NUM >= 1) {
      y_pos = 0.850;
      tracking_button_disp(TRK_SECTION, y_pos, pitch,
                           bttn_box, *TRK_NUM, priority, trk_priority,
                           trk_name, trk_pos);
    }

/*
--------------------
*/

    if (SRT_NUM >= 1) {
      srtatt_y_pos = y_pos;
      I = SRTATT_SECTION;
      for (i=0; i<srtatt_num; i++) {
        bttn_box[I][0] = 0.58 + 0.11 * (float)i;
        bttn_box[I][1] = bttn_box[I][0] + 0.10;
        bttn_box[I][2] = srtatt_y_pos;
        bttn_box[I][3] = bttn_box[I][2] + pitch;
        I++;
      }
      srtatt_button_disp(srtatt_num, srtatt_code, trk_num, srtatt_y_pos,
                         pitch, srtatt_name, &bttn_box[SRTATT_SECTION]);
    }

/*
--------------------
*/

    y_pos = 0.740;

    cpgsfs(2);
    cpgrect(0.020, 0.980, y_pos-0.150, y_pos+0.060);
    cpgsfs(1);

    I = T_WAVE_SECTION;
    for (i=0; i<=wave_num/10; i++) {
      for (j=0; j<10; j++) {
        bttn_box[I][0] = 0.035 + (float)j * 0.092;
        bttn_box[I][1] = bttn_box[I][0] + 0.087;
        bttn_box[I][2] = y_pos - 0.035 * (float)i;
        bttn_box[I][3] = bttn_box[I][2] + pitch;
        I++;
        if (I == wave_num) {
          break;
        }
      }
    }
    cpgsci(1);
    cpgtext(0.035, bttn_box[T_WAVE_SECTION][3]+0.01,
            "Wave Band (Target)\0");
    cpgsci(7);
    cpgtext(0.235, bttn_box[T_WAVE_SECTION][3]+0.01,
        "[See aris_input/fixed_parameter.prm for the wavelength setting.]\0");
    cpgsci(1);

    for (i=0; i<wave_num; i++) {
      I = T_WAVE_SECTION + i;
      if (wave_swt[0][i] == ON) {
        on_button(&wave_swt[0][i], wave_name[i], bttn_box[I]);
      } else {
        off_button(&wave_swt[0][i], wave_name[i], bttn_box[I]);
      }
    }

/*
-----------------
*/

    y_pos -= 0.101;
    I = R_WAVE_SECTION;
    for (i=0; i<=wave_num/10; i++) {
      for (j=0; j<10; j++) {
        bttn_box[I][0] = 0.035 + (float)j * 0.092;
        bttn_box[I][1] = bttn_box[I][0] + 0.087;
        bttn_box[I][2] = y_pos - 0.035 * (float)i;
        bttn_box[I][3] = bttn_box[I][2] + pitch;
        I++;
        if (I == wave_num) {
          break;
        }
      }
    }
    cpgsci(1);
    cpgtext(0.035, bttn_box[R_WAVE_SECTION][3]+0.01,
            "Wave Band (Reference)\0");
    cpgsci(7);
    cpgtext(0.235, bttn_box[R_WAVE_SECTION][3]+0.01,
        "[See aris_input/fixed_parameter.prm for the wavelength setting.]\0");
    cpgsci(1);

    for (i=0; i<wave_num; i++) {
      I = R_WAVE_SECTION + i;
      if (wave_swt[1][i] == ON) {
        on_button(&wave_swt[1][i], wave_name[i], bttn_box[I]);
      } else {
        off_button(&wave_swt[1][i], wave_name[i], bttn_box[I]);
      }
    }

/*
-----------------
*/

    y_pos -= 0.114;

    cpgsfs(2);
    cpgrect(0.020, 0.980, y_pos-0.057, y_pos+0.060);
    cpgsfs(1);

    I = BW_SECTION;
    for (i=0; i<bw_num; i++) {
      bttn_box[I][0] = 0.035 + (float)i * 0.082;
      bttn_box[I][1] = bttn_box[I][0] + 0.078;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      I++;
    }
    cpgsci(1);
    cpgtext(0.035, bttn_box[BW_SECTION][3]+0.01, "Band Width [MHz]\0");

    for (i=0; i<bw_num; i++) {
      I = BW_SECTION + i;
      if (bw_code[i] == ON) {
        on_button(&bw_code[i], bw_name[i], bttn_box[I]);
      } else {
        off_button(&bw_code[i], bw_name[i], bttn_box[I]);
      }
    }

/*
-----------------
*/

    I = CFACT_SECTION;
    for (i=0; i<cfact_num; i++) {
      bttn_box[I][0] = 0.80 + (float)i * 0.08;
      bttn_box[I][1] = bttn_box[I][0] + 0.075;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      I++;
    }
    cpgsci(1);
    cpgtext(0.78, bttn_box[CFACT_SECTION][3]+0.01, "Sampling Bit Number\0");

    for (i=0; i<cfact_num; i++) {
      I = CFACT_SECTION + i;
      if (cfact_code[i] == ON) {
        on_button(&cfact_code[i], cfact_name[i], bttn_box[I]);
      } else {
        off_button(&cfact_code[i], cfact_name[i], bttn_box[I]);
      }
    }

/*
-----------------
*/

    y_pos -= 0.046;

    I = FRCHAN_SECTION;
    cpgsci(1);
    cpgtext(0.035, y_pos + 0.3 * pitch, "Frequency Channel\0");
    for (i=0; i<frchan_num; i++) {
      bttn_box[I][0] = 0.190 + (float)i * 0.080;
      bttn_box[I][1] = bttn_box[I][0] + 0.075;
      bttn_box[I][2] = y_pos;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      I++;
    }

    for (i=0; i<frchan_num; i++) {
      I = FRCHAN_SECTION + i;
      if (frchan_code[i] == ON) {
        on_button(&frchan_code[i], frchan_name[i], bttn_box[I]);
      } else {
        off_button(&frchan_code[i], frchan_name[i], bttn_box[I]);
      }
    }

/*
-----------------
*/

    I = SWTCYC_SECTION;
    cpgsci(1);
    cpgtext(0.625, y_pos + 0.3 * pitch, "Switching Cycle Time [sec]\0");
    bttn_box[I][0] = 0.85;
    bttn_box[I][1] = 0.95;
    bttn_box[I][2] = y_pos;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
    cpgsci(0);
    cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
            0.0, 1.0, ch_swttim);
    cpgsci(1);

/*
--------------------------------------
*/

    y_pos = 0.433;

    cpgsci(1);
    cpgsfs(2);
    cpgrect(0.020, 0.485, y_pos-0.160, y_pos+0.031);
    cpgsfs(1);

    I = T_FLUX_SECTION;
    bttn_box[I][0] = 0.230;
    bttn_box[I][1] = 0.240;
    bttn_box[I][2] = y_pos + 0.3 * pitch;
    bttn_box[I][3] = bttn_box[I][2] + 0.01;
    if (src[0].positionID == 0) {
      on_button (&i, "", bttn_box[I]);
    } else if (src[0].positionID == 1) {
      off_button(&i, "", bttn_box[I]);
    }
    cpgtext(bttn_box[I][0]+0.02, bttn_box[I][2], "Source-1\0");
    I++;
    bttn_box[I][0] = 0.350;
    bttn_box[I][1] = 0.360;
    bttn_box[I][2] = y_pos + 0.3 * pitch;
    bttn_box[I][3] = bttn_box[I][2] + 0.01;
    if (src[0].positionID == 0) {
      off_button(&i, "", bttn_box[I]);
    } else if (src[0].positionID == 1) {
      on_button (&i, "", bttn_box[I]);
    }
    cpgtext(bttn_box[I][0]+0.02, bttn_box[I][2], "Source-2\0");
    cpgtext(0.035, bttn_box[I][2], "Target Position\0");

    I = T_FLUX_SECTION + FLX_SECT;
    bttn_box[I][0] = 0.260;
    bttn_box[I][1] = 0.330;
    bttn_box[I][2] = bttn_box[T_FLUX_SECTION][2] - 1.3 * pitch;
    bttn_box[I][3] = bttn_box[I][2] + pitch;

    cpgtext(0.035, bttn_box[I][2] + 0.3 * pitch, "Target Total Flux [Jy]\0");
    cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
    cpgsci(0);
    cpgptxt(bttn_box[I][1]-0.015, text_bottom(bttn_box[I][2], bttn_box[I][3]),
            0.0, 1.0, ch_tflux);
    cpgsci(1);

    for (i=0; i<tgt_morpho_num; i++) {
      I = T_FLUX_SECTION + MRP_SECT + i;
      bttn_box[I][0] = 0.040 + 0.2 * (float)(i%2);
      bttn_box[I][1] = 0.050 + 0.2 * (float)(i%2);
      bttn_box[I][2] = bttn_box[T_FLUX_SECTION][2] - 2.0 * pitch
                       - pitch * (float)(i/2);
      bttn_box[I][3] = bttn_box[I][2] + 0.01;
      if (i == src[0].morphology) {
        on_button( &tgt_proc_flag[i], "", bttn_box[I]);
      } else {
        off_button(&tgt_proc_flag[i], "", bttn_box[I]);
      }
      cpgtext(bttn_box[I][0]+0.02, bttn_box[I][2], tgt_morphology[i]);
    }

    I = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE;
    bttn_box[I][0] = bttn_box[T_FLUX_SECTION+MRP_SECT        ][0];
    bttn_box[I][1] = bttn_box[T_FLUX_SECTION+MRP_SECT+1      ][0] + 0.18;
    bttn_box[I][2] = bttn_box[T_FLUX_SECTION+FLX_SECT+tgt_morpho_num][2] - 0.04;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    if (src[0].morphology == SRC_MULTI_COMP) {
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, text_bottom(bttn_box[I][2], bttn_box[I][3]),
              0.0, 1.0, ch_file[0].mcm);
      cpgsci(1);
      TV_menu_hatch(0.025, 0.40,
                    bttn_box[T_FLUX_SECTION+FLX_SECT][2],
                    bttn_box[T_FLUX_SECTION+FLX_SECT][3], 7, 4);
    }

    I = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 1;
    bttn_box[I][0] = bttn_box[T_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][0];
    bttn_box[I][1] = bttn_box[T_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][1];
    bttn_box[I][2] = bttn_box[T_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][2];
    bttn_box[I][3] = bttn_box[T_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][3];
    if (src[0].morphology == SRC_CC_COMP) {
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, text_bottom(bttn_box[I][2], bttn_box[I][3]),
              0.0, 1.0, ch_file[0].cct);
      cpgsci(1);
      TV_menu_hatch(0.025, 0.40,
                    bttn_box[T_FLUX_SECTION+FLX_SECT][2],
                    bttn_box[T_FLUX_SECTION+FLX_SECT][3], 7, 4);
    }

    I = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 2;
    bttn_box[I][0] = bttn_box[T_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][0];
    bttn_box[I][1] = bttn_box[T_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][1];
    bttn_box[I][2] = bttn_box[T_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][2];
    bttn_box[I][3] = bttn_box[T_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][3];
    if (src[0].morphology == SRC_BHS_MOD) {
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, text_bottom(bttn_box[I][2], bttn_box[I][3]),
              0.0, 1.0, ch_file[0].bhs);
      cpgsci(1);
      TV_menu_hatch(0.025, 0.40,
                    bttn_box[T_FLUX_SECTION+FLX_SECT][2],
                    bttn_box[T_FLUX_SECTION+FLX_SECT][3], 7, 4);
    }

/*
-----------------
*/

    cpgsci(1);
    cpgsfs(2);
    cpgrect(0.515, 0.980, y_pos-0.160, y_pos+0.031);
    cpgsfs(1);

    I = R_FLUX_SECTION;
    bttn_box[I][0] = 0.730;
    bttn_box[I][1] = 0.740;
    bttn_box[I][2] = y_pos + 0.3 * pitch;
    bttn_box[I][3] = bttn_box[I][2] + 0.01;
    if (src[1].positionID == 0) {
      on_button (&i, "", bttn_box[I]);
    } else if (src[1].positionID == 1) {
      off_button(&i, "", bttn_box[I]);
    }
    cpgtext(bttn_box[I][0]+0.02, bttn_box[I][2], "Source-1\0");
    I++;
    bttn_box[I][0] = 0.850;
    bttn_box[I][1] = 0.860;
    bttn_box[I][2] = y_pos + 0.3 * pitch;
    bttn_box[I][3] = bttn_box[I][2] + 0.01;
    if (src[1].positionID == 0) {
      off_button(&i, "", bttn_box[I]);
    } else if (src[1].positionID == 1) {
      on_button (&i, "", bttn_box[I]);
    }
    cpgtext(bttn_box[I][0]+0.02, bttn_box[I][2], "Source-2\0");
    cpgtext(0.535, bttn_box[I][2], "Reference Position\0");

    I = R_FLUX_SECTION + FLX_SECT;
    bttn_box[I][0] = 0.760;
    bttn_box[I][1] = 0.830;
    bttn_box[I][2] = bttn_box[R_FLUX_SECTION][2] - 1.3 * pitch;
    bttn_box[I][3] = bttn_box[I][2] + pitch;

    cpgtext(0.535, bttn_box[I][2] + 0.3 * pitch, "Reference Total Flux [Jy]\0");
    cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
    cpgsci(0);
    cpgptxt(bttn_box[I][1]-0.015, text_bottom(bttn_box[I][2], bttn_box[I][3]),
            0.0, 1.0, ch_rflux);
    cpgsci(1);

    for (i=0; i<ref_morpho_num; i++) {
      I = R_FLUX_SECTION + MRP_SECT + i;
      bttn_box[I][0] = 0.540 + 0.2 * (float)(i%2);
      bttn_box[I][1] = 0.550 + 0.2 * (float)(i%2);
      bttn_box[I][2] = bttn_box[R_FLUX_SECTION][2] - 2.0 * pitch
                       - pitch * (float)(i/2);
      bttn_box[I][3] = bttn_box[I][2] + 0.01;
      if (i == src[1].morphology) {
        on_button( &ref_proc_flag[i], "", bttn_box[I]);
      } else {
        off_button(&ref_proc_flag[i], "", bttn_box[I]);
      }
      cpgtext(bttn_box[I][0]+0.02, bttn_box[I][2], ref_morphology[i]);
    }

    I = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE;
    bttn_box[I][0] = bttn_box[R_FLUX_SECTION+MRP_SECT        ][0];
    bttn_box[I][1] = bttn_box[R_FLUX_SECTION+MRP_SECT+1      ][0] + 0.18;
    bttn_box[I][2] = bttn_box[R_FLUX_SECTION+FLX_SECT+tgt_morpho_num][2] - 0.04;
    bttn_box[I][3] = bttn_box[I][2] + pitch;
    if (src[1].morphology == SRC_MULTI_COMP) {
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, text_bottom(bttn_box[I][2], bttn_box[I][3]),
              0.0, 1.0, ch_file[1].mcm);
      cpgsci(1);
      TV_menu_hatch(0.525, 0.90,
                    bttn_box[R_FLUX_SECTION+FLX_SECT][2],
                    bttn_box[R_FLUX_SECTION+FLX_SECT][3], 7, 4);
    }

    I = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 1;
    bttn_box[I][0] = bttn_box[R_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][0];
    bttn_box[I][1] = bttn_box[R_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][1];
    bttn_box[I][2] = bttn_box[R_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][2];
    bttn_box[I][3] = bttn_box[R_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][3];
    if (src[1].morphology == SRC_CC_COMP) {
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, text_bottom(bttn_box[I][2], bttn_box[I][3]),
              0.0, 1.0, ch_file[1].cct);
      cpgsci(1);
      TV_menu_hatch(0.525, 0.90,
                    bttn_box[R_FLUX_SECTION+FLX_SECT][2],
                    bttn_box[R_FLUX_SECTION+FLX_SECT][3], 7, 4);
    }

    I = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 2;
    bttn_box[I][0] = bttn_box[R_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][0];
    bttn_box[I][1] = bttn_box[R_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][1];
    bttn_box[I][2] = bttn_box[R_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][2];
    bttn_box[I][3] = bttn_box[R_FLUX_SECTION+3+SRC_MORPH_CANDIDATE][3];
    if (src[1].morphology == SRC_BHS_MOD) {
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, text_bottom(bttn_box[I][2], bttn_box[I][3]),
              0.0, 1.0, ch_file[0].bhs);
      cpgsci(1);
      TV_menu_hatch(0.525, 0.90,
                    bttn_box[R_FLUX_SECTION+FLX_SECT][2],
                    bttn_box[R_FLUX_SECTION+FLX_SECT][3], 7, 4);
    }

/*
------------------------------------
*/

    while (1) {
      cpgcurs(cursor_pos, cursor_pos+1, string);

      if (button_chk(cursor_pos, bttn_box[0]) == ON) {
        on_button(&idum, "GO\0", bttn_box[0]);
        break;
      } else if (button_chk(cursor_pos, bttn_box[1]) == ON) {
        on_button(&idum, "EXIT (without parameter save)\0", bttn_box[1]);
        sprintf(string, "Exit ARIS. Good by!\0");
        comment_disp(cmnt, comment, string, ON);
        return (-1);
      }

/*
---------------------------
*/

      for (I=BLSEL_SECTION; I<BLSEL_SECTION+blsel_num; I++) {
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          BL_SELECT = I - BLSEL_SECTION;
          for (i=0; i<blsel_num; i++) {
            if (i == BL_SELECT) {
              on_button(&blsel_code[i], blsel_name[i], bttn_box[I]);
            } else {
              J = BLSEL_SECTION + i;
              off_button(&blsel_code[i], blsel_name[i], bttn_box[J]);
            }
          }
        }
      }

/*
---------------------------
*/

      if (ERROR_FLAG[TWVTRB] == ON && array_id != ACA) {
        for (I=TROPOS_SECTION; I<TROPOS_SECTION+trp_num; I++) {
          if (button_chk(cursor_pos, bttn_box[I]) == ON) {
            TRP_CONDITION = I - TROPOS_SECTION;
            for (i=0; i<trp_num; i++) {
              if (i == TRP_CONDITION) {
                on_button(&trp_code[i], trp_name[i], bttn_box[I]);
              } else {
                J = TROPOS_SECTION + i;
                off_button(&trp_code[i], trp_name[i], bttn_box[J]);
              }
            }
          }
        }
      }

/*
---------------------------
*/

      if ((ERROR_FLAG[IONTRB] == ON)
        && array_id != ACA) {
        for (I=IONOS_SECTION; I<IONOS_SECTION+ion_num; I++) {
          if (button_chk(cursor_pos, bttn_box[I]) == ON) {
            ION_CONDITION = I - IONOS_SECTION;
            for (i=0; i<ion_num; i++) {
              if (i == ION_CONDITION) {
                on_button(&ion_code[i], ion_name[i], bttn_box[I]);
              } else {
                J = IONOS_SECTION + i;
                off_button(&ion_code[i], ion_name[i], bttn_box[J]);
              }
            }
          }
        }
      }

/*
---------------------------
*/

      if (SRT_NUM >= 1) {
        for (I=TRK_SECTION; I<TRK_SECTION+*TRK_NUM+TRK_GEN_CMD; I++) {
          if (button_chk(cursor_pos, bttn_box[I]) == ON) {

            if (I == TRK_SECTION) {
              for (itrk=0; itrk<*TRK_NUM; itrk++) {
                J = TRK_SECTION + TRK_GEN_CMD + itrk;
                trk_priority[itrk] = 1;
                sprintf(string, "%s(%d)\0", trk_name[itrk], trk_priority[itrk]);
                on_button(&i, string, bttn_box[J]);
              }
            } else if (I == TRK_SECTION + 1) {
              for (itrk=0; itrk<*TRK_NUM; itrk++) {
                J = TRK_SECTION + TRK_GEN_CMD + itrk;
                trk_priority[itrk] = 0;
                off_button(&i, trk_name[itrk], bttn_box[J]);
              }
            } else {
              itrk = I - TRK_GEN_CMD - TRK_SECTION;
              if (trk_priority[itrk] >= 1) {
                trk_priority[itrk] = 0;
              } else {
                trk_priority[itrk] = *TRK_NUM;
              }
              trk_priority_check(*TRK_NUM, trk_priority, trk_name);
              I = TRK_SECTION + TRK_GEN_CMD;
              for (itrk=0; itrk<*TRK_NUM; itrk++) {
                if (trk_priority[itrk] >= 1) {
                  sprintf(string, "%s(%d)", trk_name[itrk], trk_priority[itrk]);
                  on_button(&i, string, bttn_box[I]);
                } else {
                  off_button(&i, trk_name[itrk], bttn_box[I]);
                }
                I++;
              }

#ifdef __DEBUG__
              for (j=1; j<=*TRK_NUM; j++) {
                for (k=0; k<*TRK_NUM; k++) {
                  if (trk_priority[k] == j) {
                    printf("%d. %s\n", j, trk_pos[k].IDC);
                  }
                }
              }
              printf("\n");
#endif /* __DEBUG__ */
            }

            trk_num = 0;
            for (itrk=0; itrk<*TRK_NUM; itrk++) {
              if (trk_priority[itrk] >= 1) {
                trk_num++;
              }
            }

            srtatt_button_disp(srtatt_num, srtatt_code, trk_num, srtatt_y_pos,
                               pitch, srtatt_name, &bttn_box[SRTATT_SECTION]);
          }
        }
      }

/*
---------------------------
*/

      for (I=T_WAVE_SECTION; I<T_WAVE_SECTION+wave_num; I++) {
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          wave_id[0] = wave_code[I - T_WAVE_SECTION];
          wave_id[1] = wave_id[0];
          for (i=0; i<wave_num; i++) {
            if (wave_id[0] == wave_code[i]) {
              on_button(&wave_swt[0][i], wave_name[i], bttn_box[I]);
              J = R_WAVE_SECTION + i;
              on_button(&wave_swt[1][i], wave_name[i], bttn_box[J]);
            } else {
              J = T_WAVE_SECTION + i;
              off_button(&wave_swt[0][i], wave_name[i], bttn_box[J]);
              J = R_WAVE_SECTION + i;
              off_button(&wave_swt[1][i], wave_name[i], bttn_box[J]);
            }
          }
        }
      }

/*
---------------------------
*/

      for (I=R_WAVE_SECTION; I<R_WAVE_SECTION+wave_num; I++) {
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          wave_id[1] = wave_code[I - R_WAVE_SECTION];
          for (i=0; i<wave_num; i++) {
            if (wave_id[1] == wave_code[i]) {
              on_button(&wave_swt[1][i], wave_name[i], bttn_box[I]);
            } else {
              J = R_WAVE_SECTION + i;
              off_button(&wave_swt[1][i], wave_name[i], bttn_box[J]);
            }
          }
        }
      }

/*
---------------------------
*/

      for (I=BW_SECTION; I<BW_SECTION+bw_num; I++) {
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          bw_id = I - BW_SECTION;
          for (i=0; i<bw_num; i++) {
            if (i == bw_id) {
              on_button(&bw_code[i], bw_name[i], bttn_box[I]);
            } else {
              J = BW_SECTION + i;
              off_button(&bw_code[i], bw_name[i], bttn_box[J]);
            }
          }
        }
      }

/*
---------------------------
*/

      for (I=FRCHAN_SECTION; I<FRCHAN_SECTION+frchan_num; I++) {
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          frchan_id = I - FRCHAN_SECTION;
          for (i=0; i<frchan_num; i++) {
            if (i == frchan_id) {
              on_button(&frchan_code[i], frchan_name[i], bttn_box[I]);
            } else {
              J = FRCHAN_SECTION + i;
              off_button(&frchan_code[i], frchan_name[i], bttn_box[J]);
            }
          }
          *FRCHAN_NUM = channel_num_set(frchan_id);
        }
      }

/*
---------------------------
*/

      for (I=CFACT_SECTION; I<CFACT_SECTION+cfact_num; I++) {
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          cfact_id = I - CFACT_SECTION;
          for (i=0; i<cfact_num; i++) {
            if (i == cfact_id) {
              on_button(&cfact_code[i], cfact_name[i], bttn_box[I]);
            } else {
              J = CFACT_SECTION + i;
              off_button(&cfact_code[i], cfact_name[i], bttn_box[J]);
            }
          }
        }
      }

/*
---------------------------
*/

      if (ERROR_FLAG[TDSECZ] == ON && GRT_NUM > 0) {
        I = TROPOS_SECTION + trp_num;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          tv_get_param("double", cursor_pos, bttn_box[I],
                       pitch, ch_tdscz, 0.0, 0.0);
          sscanf(ch_tdscz, "%lf", &tdscz);
        }

        I = IONOS_SECTION + ion_num;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          tv_get_param("double", cursor_pos, bttn_box[I],
                       pitch, ch_idscz, 0.0, 0.0);
          sscanf(ch_idscz, "%lf", &idscz);
        }
      }

/*
---------------------------
*/

      if (ERROR_FLAG[APOSER] == ON && SRT_NUM > 0) {
        I = ORBIT_SECTION;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          tv_get_param("double", cursor_pos, bttn_box[I],
                       pitch, ch_orbae, 0.0, 0.0);
          sscanf(ch_orbae, "%lf", &orbit_error_ap);
          orbit_error_ap *= 1.0e-2;
        }

        I = ORBIT_SECTION + 1;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          tv_get_param("double", cursor_pos, bttn_box[I],
                       pitch, ch_orbpe, 0.0, 0.0);
          sscanf(ch_orbpe, "%lf", &orbit_error_pe);
          orbit_error_pe *= 1.0e-2;
        }
      }

/*
---------------------------
*/

      if (SRT_NUM >= 1 && trk_num >= 1) {
        for (I=SRTATT_SECTION; I<SRTATT_SECTION+srtatt_num; I++) {
          if (button_chk(cursor_pos, bttn_box[I]) == ON) {
            srtatt_code = I - SRTATT_SECTION;
            for (i=0; i<srtatt_num; i++) {
              if (i == srtatt_code) {
                on_button(&idum, srtatt_name[i], bttn_box[I]);
              } else {
                J = SRTATT_SECTION + i;
                off_button(&idum, srtatt_name[i], bttn_box[J]);
              }
            }
          }
        }
      }

/*
---------------------------
*/

      if (button_chk(cursor_pos, bttn_box[T_FLUX_SECTION  ]) == ON) {
        src[0].positionID = 0;
        on_button (&i, "", bttn_box[T_FLUX_SECTION  ]);
        off_button(&i, "", bttn_box[T_FLUX_SECTION+1]);
      }

      if (button_chk(cursor_pos, bttn_box[T_FLUX_SECTION+1]) == ON) {
        src[0].positionID = 1;
        off_button(&i, "", bttn_box[T_FLUX_SECTION  ]);
        on_button (&i, "", bttn_box[T_FLUX_SECTION+1]);
      }

/*
----
*/

      if (button_chk(cursor_pos, bttn_box[T_FLUX_SECTION+FLX_SECT]) == ON &&
          src[0].morphology != SRC_CC_COMP &&
          src[0].morphology != SRC_BHS_MOD) {
        tv_get_param("double", cursor_pos, bttn_box[T_FLUX_SECTION+FLX_SECT],
                     pitch, ch_tflux, 0.0, 0.0);
        sscanf(ch_tflux, "%lf", &src[0].flux);
      }

/*
----
*/

      for (I=T_FLUX_SECTION+MRP_SECT;
           I<T_FLUX_SECTION+MRP_SECT+tgt_morpho_num; I++) {
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          src[0].morphology = I - T_FLUX_SECTION - MRP_SECT;
          for (i=0; i<tgt_morpho_num; i++) {
            J = i + T_FLUX_SECTION + MRP_SECT;
            if (i == src[0].morphology) {
              on_button( &tgt_proc_flag[i], "", bttn_box[J]);
            } else {
              off_button(&tgt_proc_flag[i], "", bttn_box[J]);
            }
          }
          if (src[0].morphology == SRC_MULTI_COMP) {
            J = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE;
            cpgsci(1);
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);
            cpgsci(0);
            cpgptxt(bttn_box[J][1]-0.015,
                    text_bottom(bttn_box[J][2], bttn_box[J][3]),
                    0.0, 1.0, ch_file[0].mcm);
            cpgsci(1);
            TV_menu_hatch(0.025, 0.40,
                          bttn_box[T_FLUX_SECTION+FLX_SECT][2],
                          bttn_box[T_FLUX_SECTION+FLX_SECT][3], 7, 4);
          } else if (src[0].morphology == SRC_CC_COMP) {
            J = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 1;
            cpgsci(1);
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);
            cpgsci(0);
            cpgptxt(bttn_box[J][1]-0.015,
                    text_bottom(bttn_box[J][2], bttn_box[J][3]),
                    0.0, 1.0, ch_file[0].cct);
            cpgsci(1);
            TV_menu_hatch(0.025, 0.40,
                          bttn_box[T_FLUX_SECTION+FLX_SECT][2],
                          bttn_box[T_FLUX_SECTION+FLX_SECT][3], 7, 4);
          } else if (src[0].morphology == SRC_BHS_MOD) {
            J = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 2;
            cpgsci(1);
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);
            cpgsci(0);
            cpgptxt(bttn_box[J][1]-0.015,
                    text_bottom(bttn_box[J][2], bttn_box[J][3]),
                    0.0, 1.0, ch_file[0].bhs);
            cpgsci(1);
            TV_menu_hatch(0.025, 0.40,
                          bttn_box[T_FLUX_SECTION+FLX_SECT][2],
                          bttn_box[T_FLUX_SECTION+FLX_SECT][3], 7, 4);
          }

          if (src[0].morphology == SRC_POINT         ||
              src[0].morphology == SRC_DISK_JETCJET  ||
              src[0].morphology == SRC_DISK_VSOP2JET) {
            cpgsci(0);
            J = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE;
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);

            J = T_FLUX_SECTION + FLX_SECT;
            TV_menu_hatch(0.025, 0.40,
                          bttn_box[J][2], bttn_box[J][3], 0, 1);
            cpgtext(0.035, bttn_box[J][2] + 0.3 * pitch,
                    "Target Total Flux [Jy]\0");
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);
            cpgsci(0);
            cpgptxt(bttn_box[J][1]-0.015,
                    text_bottom(bttn_box[J][2], bttn_box[J][3]),
                    0.0, 1.0, ch_tflux);
            cpgsci(1);
          }
          break;
        }
      }

/*
----
*/

      J = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE;
      if (src[0].morphology == SRC_MULTI_COMP &&
          button_chk(cursor_pos, bttn_box[J]) == ON) {
        tv_get_param("char", cursor_pos, bttn_box[J],
                     pitch, ch_file[0].mcm, 0.0, 0.0);
      }

      J = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 1;
      if (src[0].morphology == SRC_CC_COMP &&
          button_chk(cursor_pos, bttn_box[J]) == ON) {
        tv_get_param("char", cursor_pos, bttn_box[J],
                     pitch, ch_file[0].cct, 0.0, 0.0);
      }

      J = T_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 2;
      if (src[0].morphology == SRC_BHS_MOD &&
          button_chk(cursor_pos, bttn_box[J]) == ON) {
        tv_get_param("char", cursor_pos, bttn_box[J],
                     pitch, ch_file[0].bhs, 0.0, 0.0);
      }

/*
---------------------------
*/

      if (button_chk(cursor_pos, bttn_box[R_FLUX_SECTION  ]) == ON) {
        src[1].positionID = 0;
        on_button (&i, "", bttn_box[R_FLUX_SECTION  ]);
        off_button(&i, "", bttn_box[R_FLUX_SECTION+1]);
      }

      if (button_chk(cursor_pos, bttn_box[R_FLUX_SECTION+1]) == ON) {
        src[1].positionID = 1;
        off_button(&i, "", bttn_box[R_FLUX_SECTION  ]);
        on_button (&i, "", bttn_box[R_FLUX_SECTION+1]);
      }

/*
----
*/

      if (button_chk(cursor_pos, bttn_box[R_FLUX_SECTION+FLX_SECT]) == ON &&
          src[1].morphology != SRC_CC_COMP &&
          src[1].morphology != SRC_BHS_MOD) {
        tv_get_param("double", cursor_pos, bttn_box[R_FLUX_SECTION+FLX_SECT],
                     pitch, ch_rflux, 0.0, 0.0);
        sscanf(ch_rflux, "%lf", &src[1].flux);
      }

/*
----
*/

      for (I=R_FLUX_SECTION+MRP_SECT;
           I<R_FLUX_SECTION+MRP_SECT+ref_morpho_num; I++) {
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          src[1].morphology = I - R_FLUX_SECTION - MRP_SECT;
          for (i=0; i<ref_morpho_num; i++) {
            J = i + R_FLUX_SECTION + MRP_SECT;
            if (i == src[1].morphology) {
              on_button( &ref_proc_flag[i], "", bttn_box[J]);
            } else {
              off_button(&ref_proc_flag[i], "", bttn_box[J]);
            }
          }
          if (src[1].morphology == SRC_MULTI_COMP) {
            J = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE;
            cpgsci(1);
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);
            cpgsci(0);
            cpgptxt(bttn_box[J][1]-0.015,
                    text_bottom(bttn_box[J][2], bttn_box[J][3]),
                    0.0, 1.0, ch_file[1].mcm);
            cpgsci(1);
            TV_menu_hatch(0.525, 0.90,
                          bttn_box[R_FLUX_SECTION+FLX_SECT][2],
                          bttn_box[R_FLUX_SECTION+FLX_SECT][3], 7, 4);
          } else if (src[1].morphology == SRC_CC_COMP) {
            J = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 1;
            cpgsci(1);
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);
            cpgsci(0);
            cpgptxt(bttn_box[J][1]-0.015,
                    text_bottom(bttn_box[J][2], bttn_box[J][3]),
                    0.0, 1.0, ch_file[1].cct);
            cpgsci(1);
            TV_menu_hatch(0.525, 0.90,
                          bttn_box[R_FLUX_SECTION+FLX_SECT][2],
                          bttn_box[R_FLUX_SECTION+FLX_SECT][3], 7, 4);
          } else if (src[1].morphology == SRC_BHS_MOD) {
            J = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 2;
            cpgsci(1);
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);
            cpgsci(0);
            cpgptxt(bttn_box[J][1]-0.015,
                    text_bottom(bttn_box[J][2], bttn_box[J][3]),
                    0.0, 1.0, ch_file[1].bhs);
            cpgsci(1);
            TV_menu_hatch(0.525, 0.90,
                          bttn_box[R_FLUX_SECTION+FLX_SECT][2],
                          bttn_box[R_FLUX_SECTION+FLX_SECT][3], 7, 4);
          }

          if (src[1].morphology == SRC_POINT         ||
              src[1].morphology == SRC_DISK_JETCJET  ||
              src[1].morphology == SRC_DISK_VSOP2JET) {
            cpgsci(0);
            J = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE;
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);

            J = R_FLUX_SECTION + FLX_SECT;
            TV_menu_hatch(0.525, 0.90,
                          bttn_box[J][2], bttn_box[J][3], 0, 1);
            cpgtext(0.535, bttn_box[J][2] + 0.3 * pitch,
                    "Reference Total Flux [Jy]\0");
            cpgrect(bttn_box[J][0], bttn_box[J][1],
                    bttn_box[J][2], bttn_box[J][3]);
            cpgsci(0);
            cpgptxt(bttn_box[J][1]-0.015,
                    text_bottom(bttn_box[J][2], bttn_box[J][3]),
                    0.0, 1.0, ch_rflux);
            cpgsci(1);
          }
          break;
        }
      }

/*
----
*/

      J = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE;
      if (src[1].morphology == SRC_MULTI_COMP &&
          button_chk(cursor_pos, bttn_box[J]) == ON) {
        tv_get_param("char", cursor_pos, bttn_box[J],
                     pitch, ch_file[1].mcm, 0.0, 0.0);
      }

      J = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 1;
      if (src[1].morphology == SRC_CC_COMP &&
          button_chk(cursor_pos, bttn_box[J]) == ON) {
        tv_get_param("char", cursor_pos, bttn_box[J],
                     pitch, ch_file[1].cct, 0.0, 0.0);
      }

      J = R_FLUX_SECTION + MRP_SECT + SRC_MORPH_CANDIDATE + 2;
      if (src[1].morphology == SRC_BHS_MOD &&
          button_chk(cursor_pos, bttn_box[J]) == ON) {
        tv_get_param("char", cursor_pos, bttn_box[J],
                     pitch, ch_file[1].bhs, 0.0, 0.0);
      }

/*
---------------------------
*/

      if (button_chk(cursor_pos, bttn_box[SWTCYC_SECTION]) == ON) {
        tv_get_param("double", cursor_pos, bttn_box[SWTCYC_SECTION],
                     pitch, ch_swttim, 0.0, 0.0);
        sscanf(ch_swttim, "%lf", &swt_cyc_time);

/*
--------
*/
        *nswt    = (int)rint(swt_cyc_time);
        if (*nswt % 2 == 1) {
          (*nswt)++;
          sprintf(string,
                  "Swtching cycle time is changed to %d [sec].\0", *nswt);
          comment_disp(cmnt, comment, string, ON);
        }
        swt_cyc_time = (double)(*nswt);

        for (i=0; i<sizeof(string); i++) {
          string[i] = 0;
        }
      }

/*
---------------------------
*/

    }
  }

/*
------------------------------------------------------
*/

  sprintf(string, "ARIS continues...\0");
  if (TVSWT == OFF) {
    printf("%s\n", string);
  } else if (TVSWT == ON) {
    comment_disp(cmnt, comment, string, ON);
  }

/*
------------------------------------------------------
*/

  if (BL_SELECT == ALLBL) {
    *BGN_ANT_I = 0;
    *END_ANT_I = ANT_NUM;
    *BGN_ANT_J = 0;
    *END_ANT_J = ANT_NUM;
  } else if (BL_SELECT == GG_BL) {
    *BGN_ANT_I = 0;
    *END_ANT_I = GRT_NUM;
    *BGN_ANT_J = 0;
    *END_ANT_J = GRT_NUM;
  } else if (BL_SELECT == GS_BL) {
    *BGN_ANT_I = 0;
    *END_ANT_I = GRT_NUM;
    *BGN_ANT_J = GRT_NUM;
    *END_ANT_J = ANT_NUM;
  } else if (BL_SELECT == SS_BL) {
    *BGN_ANT_I = GRT_NUM;
    *END_ANT_I = ANT_NUM;
    *BGN_ANT_J = GRT_NUM;
    *END_ANT_J = ANT_NUM;
  }

/*
------
*/

  if (       TRP_CONDITION == 0) {
    *CW = 100.0e-6 / pow(100.0, 0.5*1.67) / sqrt(2.0);
  } else if (TRP_CONDITION == 1) {
    *CW = 1.0e-7 * sqrt(1.4 * 1.0e3);
  } else if (TRP_CONDITION == 2) {
    *CW = 2.0e-7 * sqrt(1.4 * 1.0e3);
  } else if (TRP_CONDITION == 3) {
    *CW = 4.0e-7 * sqrt(1.4 * 1.0e3);
  }
  *CW /= speed_of_light;

  /*                                                        */
  /*  1.67 X 10^{-16/3} [m^{1-5/6}] :  Asaki et al., 1996   */
  /*         ----> Cn = 2.1e-7 [m^{-1/3}]                   */
  /*  0.67 X 10^{-16/3} [m^{1-5/6}] :  Asaki et al., 1998   */
  /*         ----> Cn = 0.8e-7 [m^{-1/3}]                   */
  /*                                                        */
  /*  In Beasley and Conway, the coefficient is defined by  */
  /*  CW^2 = 1.4*Cn^2*L, where L is the inner scale. Then,  */
  /*  a factor sqrt(1.4 * 1000[m]) has to be multiplied     */
  /*  to change their defined coefficient to the exact      */
  /*  structure coefficient defined Drvskii and Finkelstein.*/
  /*                                                        */
  /*  VERY GOOD SITUATION:                                  */
  /*  The value is described in Asaki et al. (2005).        */
  /*                                                        */

/*
------
*/

  if (ION_CONDITION == 0) {
    *CI = 0.5;
  } else if (ION_CONDITION == 1) {
    *CI = 1.0;
  } else if (ION_CONDITION == 2) {
    *CI = 2.0;
  }

/*
------
*/

  if (SRT_NUM > 0) {
    if (ERROR_FLAG[APOSER] == ON) {
      for (iant=0; iant<SRT_NUM; iant++) {
        srt[iant].ODDA = orbit_error_ap;
        srt[iant].ODDP = orbit_error_pe;
      }
    } else {
      for (iant=0; iant<SRT_NUM; iant++) {
        srt[iant].ODDA = 0.0;
        srt[iant].ODDP = 0.0;
      }
    }

    if (srtatt_code == 0) {
      *BODY_X_SUN = +1;
    } else if (srtatt_code == 1) {
      *BODY_X_SUN = -1;
    } else if (srtatt_code == 2) {
      *BODY_X_SUN =  0;
    }
  }

/*
------
*/

  for (itrk=0; itrk<*TRK_NUM; itrk++) {
    trk_pos[itrk].UFL = OFF;
  }

  trk_num = 0;
  for (I=1; I<=*TRK_NUM; I++) {

    for (itrk=0; itrk<*TRK_NUM; itrk++) {
      if (trk_priority[itrk] == I) {
        tracking_config(-1, trk_name[itrk], trk_pos+trk_num);
        trk_pos[trk_num].UFL = trk_priority[itrk];
#ifdef __DEBUG__
        printf("%d. %s\n", trk_pos[trk_num].UFL,  trk_pos[trk_num].IDC);
#endif /* __DEBUG__ */
        trk_num++;
      }
    }
  }
  *TRK_NUM = trk_num;

/*
---------------
*/

  if (ERROR_FLAG[TDSECZ] == ON) {
    for (iant=0; iant<GRT_NUM; iant++) {
      dz[iant].trp *= (tdscz * 1.0e-2 / speed_of_light);
    }
  }

/*
---------------
*/

  if (ERROR_FLAG[IDSECZ] == ON) {
    for (iant=0; iant<GRT_NUM; iant++) {
      dz[iant].tec *= (idscz * 1.0e+16);
    }
  }

/*
---------------
*/

  wave_select(wave_id[0], &wave_length[0], &nu[0]);
  wave_select(wave_id[1], &wave_length[1], &nu[1]);
  wave_id[2]     = wave_id[0];
  nu[2]          = nu[0];
  wave_length[2] = wave_length[0];

/*
------
*/

  *band_width = band_width_set(bw_id);
  *cfact      = cfact_set(cfact_id);

/*
------
*/

  number_char_cut(ch_tdscz);
  number_char_cut(ch_idscz);
  number_char_cut(ch_orbae);
  number_char_cut(ch_orbpe);
  number_char_cut(ch_swttim);
  number_char_cut(ch_tflux);
  number_char_cut(ch_rflux);

  if ((fp = fopen("aris_input/sim.prm", "w")) != NULL) {
    fprintf(fp, "BASELINE SELECT     %d\n", BL_SELECT);
    fprintf(fp, "TROPOS CONDITION    %d\n", TRP_CONDITION);
    fprintf(fp, "IONOS CONDITION     %d\n", ION_CONDITION);
    fprintf(fp, "TROPOS ZENITH ERROR %s\n", ch_tdscz);
    fprintf(fp, "IONOS ZENITH ERROR  %s\n", ch_idscz);
    fprintf(fp, "ORBIT ERROR APOGEE  %s\n", ch_orbae);
    fprintf(fp, "ORBIT ERROR PERIGEE %s\n", ch_orbpe);
    fprintf(fp, "X_AXIS_SUN_ANGLE    %d\n", *BODY_X_SUN);
    for (itrk=0; itrk<*TRK_NUM; itrk++) {
      fprintf(fp, "TRACKING NETWORK    %s,%d\n",
              trk_pos[itrk].IDC, trk_pos[itrk].UFL);
    }
    fprintf(fp, "TGT WAVE ID         %d\n", wave_id[0]);
    fprintf(fp, "REF WAVE ID         %d\n", wave_id[1]);
    fprintf(fp, "BAND WIDTH          %d\n", bw_id);
    fprintf(fp, "FREQUENCY CHANNEL   %d\n", frchan_id);
    fprintf(fp, "COHERENCE FACTOR    %d\n", cfact_id);
    fprintf(fp, "SWITCHING CYC TIME  %s\n", ch_swttim);
    fprintf(fp, "TGT FLUX DENSITY    %s\n", ch_tflux);
    fprintf(fp, "TGT POSITION        %d\n", src[0].positionID);
    fprintf(fp, "TGT MORPHOLOGY      %d\n", src[0].morphology);
    fprintf(fp, "TGT MULTI COMPONENT %s\n", ch_file[0].mcm);
    fprintf(fp, "TGT CC TABLE        %s\n", ch_file[0].cct);
    fprintf(fp, "TGT BHS MODEL       %s\n", ch_file[0].bhs);
    fprintf(fp, "REF FLUX DENSITY    %s\n", ch_rflux);
    fprintf(fp, "REF POSITION        %d\n", src[1].positionID);
    fprintf(fp, "REF MORPHOLOGY      %d\n", src[1].morphology);
    fprintf(fp, "REF MULTI COMPONENT %s\n", ch_file[1].mcm);
    fprintf(fp, "REF CC TABLE        %s\n", ch_file[1].cct);
    fprintf(fp, "REF BHS MODEL       %s\n", ch_file[1].bhs);
    fclose (fp);
  } else {
    printf("CAUTION: Sim parameters cannot be saved. ");
    printf("Make directory \"./aris_input/\".\n");
  }

  return (1);
}



double  band_width_set(int  bw_id)
{
  double band_width;
  if (bw_id == 0) {
    band_width =    4.0e6;
  } else if (bw_id == 1) {
    band_width =    8.0e6;
  } else if (bw_id == 2) {
    band_width =   16.0e6;
  } else if (bw_id == 3) {
    band_width =   32.0e6;
  } else if (bw_id == 4) {
    band_width =  128.0e6;
  } else if (bw_id == 5) {
    band_width =  256.0e6;
  } else if (bw_id == 6) {
    band_width =  512.0e6;
  } else if (bw_id == 7) {
    band_width = 1024.0e6;
  } else if (bw_id == 8) {
    band_width = 4096.0e6;
  }
  return band_width;
}


double  cfact_set(int  cfact_id)
{
  double cfact;
  if (cfact_id == 0) {         /* Two-level sampling  + three-level FR */
    cfact = 0.637 * 0.960;
  } else if (cfact_id == 1) {  /* four-level sampling + three-level FR */
    cfact = 0.881 * 0.960;
  }
  return cfact;
}


int      channel_num_set(int  frchan_id)
{
  if (frchan_id == 0) {
    return (1);
  } else if (frchan_id == 1) {
    return (4);
  } else if (frchan_id == 2) {
    return (8);
  } else if (frchan_id == 3) {
    return (16);
  } else if (frchan_id == 4) {
    return (32);
  }
}




void  srtatt_button_disp(int srtatt_num, int srtatt_code,
                         int trk_num, float y_pos, float pitch,
                         char srtatt_name[][10], float bttn_box[][4])
{
  int    i, idum;
  float  pgxmin, pgxmax, pgymin, pgymax;

  pgxmin = bttn_box[0][0]            - 0.13;
  pgxmax = bttn_box[srtatt_num-1][1] + 0.02;
  pgymin = y_pos         - 0.005;
  pgymax = y_pos + pitch + 0.005;

  TV_menu_hatch(pgxmin, pgxmax, pgymin, pgymax, 0, 1);
  cpgsci(1);
  cpgtext(pgxmin+0.025, y_pos + 0.3 * pitch, "SRT Attitude\0");
  for (i=0; i<srtatt_num; i++) {
    if (i == srtatt_code) {
      on_button(&idum, srtatt_name[i], bttn_box[i]);
    } else {
      off_button(&idum, srtatt_name[i], bttn_box[i]);
    }
  }
  if (trk_num == 0) {
    TV_menu_hatch(pgxmin, pgxmax, pgymin, pgymax, 7, 4);
  }

  return;
}
