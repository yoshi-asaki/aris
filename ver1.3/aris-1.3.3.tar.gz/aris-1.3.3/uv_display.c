#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <aris.h>

/****
#define __FINE_STRUCTURE__
****/
#define __FINE_STRUCTURE__
#ifndef __FINE_STRUCTURE__ 
  #define __COARSE_STRUCTURE__
#endif

int     uv_display(
              int nobs,      double *uv_max,
              int ANT_NUM,
              int BGN_ANT_I, int END_ANT_I,
              int BGN_ANT_J, int END_ANT_J,
              struct st_observable *int_obs[],
              double *wave_length, int  nswt,
              int    WAVE_NORM,   float pgsch_prm, int    DISP_SWT)
{
  int    iant, jant, iobs;
  int    i, j, I, J, k, l, m, n, ns;
  int    n_blank;
  float  *pgx, *pgy;
  float  scaling_factor;
  double uv_length, wl;
  char   xlab[30], ylab[30];
  int    FACTOR;
  float  src_flag;

/*
---------------------------------
*/

  if (*uv_max <= 0.0) {
    for (iant=0; iant<ANT_NUM; iant++) {
      if (iant >= BGN_ANT_I && iant < END_ANT_I) {
        for (jant=iant+1; jant<ANT_NUM; jant++) {
          if (jant >= BGN_ANT_J && jant < END_ANT_J) {
            for (k=0; k<nobs; k++) {
              I = iant * nobs + k;
              J = jant * nobs + k;
              for (ns=0; ns<SRC_NUM; ns++) {
                src_flag = 100.0 * (float)(ns + 1);
                if (int_obs[ns][I].wt >= src_flag &&
                    int_obs[ns][J].wt >= src_flag) {
                  uv_length =
                       pow(diff(int_obs[ns][I].u, int_obs[ns][J].u), 2.0) +
                       pow(diff(int_obs[ns][I].v, int_obs[ns][J].v), 2.0);
                  if (uv_length > *uv_max) {
                    *uv_max = uv_length;
                  }
                }
              }
            }
          }
        }
      }
    }
    *uv_max = sqrt(*uv_max);
  }
  if (DISP_SWT == OFF) {
    return ( ON);
  }

/*
---------------------------------
*/

/**
  cpgpap(pgpap_prm, 1.0); 
  cpgpap(3.0, 1.0);
  cpgpap(pgpap_prm, 1.0); 
**/

  if ((pgx = calloc(nobs, sizeof(float))) == NULL) {
    printf("ERROR: UV_DISPLAY: calloc fail for pgx.\n");
    return ( NG);
  }
  if ((pgy = calloc(nobs, sizeof(float))) == NULL) {
    printf("ERROR: UV_DISPLAY: calloc fail for pgy.\n");
    free (pgx);
    return ( NG);
  }

  cpgsch(pgsch_prm);
  if (WAVE_NORM == ON) {
    if (wave_length[0] <= wave_length[1]) {
      wl = wave_length[0];
    } else {
      wl = wave_length[1];
    }

    scaling_factor = 1.0;
    sprintf(xlab, "\\fiu\\fn [\\gl\\fn]\0");
    sprintf(ylab, "\\fiv\\fn [\\gl\\fn]\0");

    for (i=1; i<=3; i++) {
      FACTOR = (int)(*uv_max/wl * pow(10.0, (double)(-3*i)));
      if (FACTOR >= 1 && FACTOR < 1000) {
        if (i == 1) {
          scaling_factor = (float)pow(10.0, (double)(-3*i));
          sprintf(xlab, "\\fiu\\fn [k\\gl\\fn]\0");
          sprintf(ylab, "\\fiv\\fn [k\\gl\\fn]\0");
          break;
        } else if (i == 2) {
          scaling_factor = (float)pow(10.0, (double)(-3*i));
          sprintf(xlab, "\\fiu\\fn [M\\gl\\fn]\0");
          sprintf(ylab, "\\fiv\\fn [M\\gl\\fn]\0");
          break;
        } else if (i == 3) {
          scaling_factor = (float)pow(10.0, (double)(-3*i));
          sprintf(xlab, "\\fiu\\fn [G\\gl\\fn]\0");
          sprintf(ylab, "\\fiv\\fn [G\\gl\\fn]\0");
          break;
        }
      }
    }
/**
    cpgsvp(0.15, 0.90, 0.15, 0.90);
**/
    cpgswin(-1.2* *uv_max/wl*scaling_factor, 1.2* *uv_max/wl*scaling_factor,
            -1.2* *uv_max/wl*scaling_factor, 1.2* *uv_max/wl*scaling_factor);
    cpgbox("BCNTS", 0, 0, "BCNTS", 0, 0);
    cpglab(xlab, ylab, 
           "(\\fiu\\fn, \\fiv\\fn) plot (normalized by wave length)");
  } else {
    scaling_factor = 1.0;
    sprintf(xlab, "\\fiu\\fn [m]\0");
    sprintf(ylab, "\\fiv\\fn [m]\0");

    FACTOR = (int)(*uv_max * pow(10.0, -3.0));
    if (FACTOR >= 1 && FACTOR < 10) {
      scaling_factor = (float)pow(10.0, -3);
      sprintf(xlab, "\\fiu\\fn [km]\0");
      sprintf(ylab, "\\fiv\\fn [km]\0");
    }
/**
    cpgsvp(0.15, 0.90, 0.15, 0.90);
**/
    cpgswin(-1.2* *uv_max*scaling_factor, 1.2* *uv_max*scaling_factor,
            -1.2* *uv_max*scaling_factor, 1.2* *uv_max*scaling_factor);
    cpgbox("BCNTS", 0, 0, "BCNTS", 0, 0);
    cpglab(xlab, ylab, "(\\fiu\\fn, \\fiv\\fn) plot\0");
  }

/*
--------
*/

  for (ns=0; ns<SRC_NUM; ns++) {
    src_flag = 100.0 * (float)(ns + 1);
    cpgsci(ns+1);
    cpgsls(3*ns+1);

    for (iant=0; iant<ANT_NUM; iant++) {
      if (iant >= BGN_ANT_I && iant < END_ANT_I) {
        for (jant=iant+1; jant<ANT_NUM; jant++) {
          if (jant >= BGN_ANT_J && jant < END_ANT_J) {


            if (DISP_SWT == F_STRUCTURE) {


            iobs = 0;
            while (1) {
              l = 0;
              I = iant * nobs + iobs;
              J = jant * nobs + iobs;
              for (k=iobs; k<nobs; k++) {
                if (int_obs[ns][I].wt >= src_flag &&
                    int_obs[ns][J].wt >= src_flag) {
                  pgx[l] = scaling_factor
                                 * diff(int_obs[ns][I].u, int_obs[ns][J].u);
                  pgy[l] = scaling_factor
                                 * diff(int_obs[ns][I].v, int_obs[ns][J].v);
                  l++;
                } else {
                  iobs = k + 1;
                  break;
                }
                I++;
                J++;
              }
              if (WAVE_NORM == ON) {
                for (m=0; m<l; m++) {
                  pgx[m] /= wave_length[ns];
                  pgy[m] /= wave_length[ns];
                }
              }
              cpgline(l, pgx, pgy);
              for (m=0; m<l; m++) {
                pgx[m] *= -1.0;
                pgy[m] *= -1.0;
              }
              cpgline(l, pgx, pgy);

              if (k >= nobs - 1) {
                break;
              }
            }



            } else if (DISP_SWT == C_STRUCTURE) {



            if (nswt != 0) {
              iobs = 0;
              while (1) {
                l = 0;
                m = 0;
                pgx[l] = 0.0;
                pgy[l] = 0.0;
                n_blank = 0;
                I = iant * nobs + iobs;
                J = jant * nobs + iobs;
                for (k=iobs; k<nobs; k++) {
                  if (int_obs[ns][I].wt >= src_flag &&
                      int_obs[ns][J].wt >= src_flag) {
                    pgx[l] += scaling_factor
                                   * diff(int_obs[ns][I].u, int_obs[ns][J].u);
                    pgy[l] += scaling_factor
                                   * diff(int_obs[ns][I].v, int_obs[ns][J].v);
                    m++;
                    n_blank = 0;
                  } else {
                    if (n_blank == 0) {
                      if (m != 0) {
                        pgx[l] /= (float)m;
                        pgy[l] /= (float)m;
                        m = 0;
                        l++;
                        pgx[l] = 0.0;
                        pgy[l] = 0.0;
                      }
                      n_blank++;
                    } else {
                      n_blank++;
                    }
                  }

                  if (n_blank > nswt) {
                    iobs = k + 1;
                    break;
                  }
                  I++;
                  J++;
                }

                if (WAVE_NORM == ON) {
                  for (m=0; m<l; m++) {
                    pgx[m] /= wave_length[ns];
                    pgy[m] /= wave_length[ns];
                  }
                }
                cpgline(l, pgx, pgy);
                for (m=0; m<l; m++) {
                  pgx[m] *= -1.0;
                  pgy[m] *= -1.0;
                }
                cpgline(l, pgx, pgy);

                if (k >= nobs - 1) {
                  break;
                }
              }
            } else if (nswt == 0) {
              nswt = 60;
              iobs = 0;
              n    = 0;
              while (1) {
                for (k=iobs; k<nobs/nswt; k++) {
                  pgx[n] = 0.0;
                  pgy[n] = 0.0;
                  m = 0;
                  I = iant * nobs + k * nswt;
                  J = jant * nobs + k * nswt;
                  for (i=0; i<nswt; i++) {
                    if (int_obs[ns][I].wt >= src_flag &&
                        int_obs[ns][J].wt >= src_flag) {
                      pgx[n] += scaling_factor
                                 * diff(int_obs[ns][I].u, int_obs[ns][J].u);
                      pgy[n] += scaling_factor
                                 * diff(int_obs[ns][I].v, int_obs[ns][J].v);
                      m++;
                    }
                    I++;
                    J++;
                  }
                  if (m != 0) {
                    pgx[n] /= (float)m;
                    pgy[n] /= (float)m;
                    if (WAVE_NORM == ON) {
                      pgx[n] /= wave_length[ns];
                      pgy[n] /= wave_length[ns];
                    }
                    n++;
                  } else if (m == 0) {
                    cpgline(n, pgx, pgy);
                    for (l=0; l<n; l++) {
                      pgx[l] *= -1.0;
                      pgy[l] *= -1.0;
                    }
                    cpgline(n, pgx, pgy);
                    n = 0;
                  }
                  iobs += nswt;
                }
                if (iobs >= nobs / nswt) {
                  cpgline(n, pgx, pgy);
                  for (l=0; l<n; l++) {
                    pgx[l] *= -1.0;
                    pgy[l] *= -1.0;
                  }
                  cpgline(n, pgx, pgy);
                  break;
                }
              }
              nswt = 0;
            }


            }


          }
        }
      }
    }
  }
  cpgsch(1.2);
  cpgsls(1);

/*
--------
*/

  free (pgx);
  free (pgy);

  return ( ON);
}
