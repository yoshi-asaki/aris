#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>


int  tracking_status(int  TRK_STATUS_CHK,  float  *WEIGHT_FLAG_DATA,
              int *ntrk,
              int *TimUTC, double UT1_UTC,
              struct srt_orbit_parameter      srt,
              struct source_parameter         src,
              struct source_parameter         sun,
              double OBS_T, double OBS_p,
              int    TRK_NUM,
              double *ant_XYZ,     double *err_XYZ,  double *V_xyz_CIP,
              struct antenna_parameter    *trk_pos,
              struct srt_data_link        *srt_link,
              double *AZ, double *EL, double *dAZdt, double *dELdt,
              double *srt_AZ, double *srt_EL,
              double sep_angle_limit,
              double *ptrk, double *pdis,
              double *init_l,
              int    BODY_X_SUN)
{
  int    itrk, I;
  int    TRK_SWT;
  int    trk_status[ANTMAX], trk_priority[ANTMAX];
  double L, R;
  double Oe_rdc_CIP[3];
  double srt_dAZdt, srt_dELdt;

/*
--------
*/

  *ntrk   = -1;

/*
-- SRT Orbit Status Check      --
*/

  spacecraft_position(srt, TimUTC, UT1_UTC, (double)1,
                      ant_XYZ, err_XYZ, Oe_rdc_CIP, V_xyz_CIP, init_l);
  if (TRK_STATUS_CHK == OFF) {
    return ON;
  }

/*
----
*/

  if (earth_eclipse(sun.s, ant_XYZ, &R, &L, sep_angle_limit) == NIGHT) {
    *WEIGHT_FLAG_DATA += SRT_EARTH_ECLIPS_SUN;
  }

  if (earth_eclipse(src.s, ant_XYZ, &R, &L, sep_angle_limit) == NIGHT) {
    *WEIGHT_FLAG_DATA += SRT_EARTH_ECLIPS_SRC;
  }

  if (TRK_NUM == 0) {
    return ON;
  }

  for (itrk=0; itrk<TRK_NUM; itrk++) {
    trk_priority[itrk] = trk_pos[itrk].UFL % ON_TRK;
    trk_status[itrk]   = trk_pos[itrk].UFL / ON_TRK;
  }

/*
-- Tracking Continuation Check --
*/

  TRK_SWT = OFF;
  for (I=1; I<=TRK_NUM; I++) {
    for (itrk=0; itrk<TRK_NUM; itrk++) {
      if (trk_priority[itrk] == I && trk_status[itrk] == 1) {
        if (tracking_condition(TimUTC, UT1_UTC, trk_pos[itrk],
                    OBS_T, OBS_p, OFF, ant_XYZ, V_xyz_CIP,
                    AZ, EL, dAZdt, dELdt,
                    srt_link, src, sun,
                    srt_AZ, srt_EL, &srt_dAZdt, &srt_dELdt, ptrk, pdis,
                    BODY_X_SUN) == 0) {
          *ntrk   = itrk;
          TRK_SWT = ON;
          break;
        }
      }
    }

    if (TRK_SWT == OFF) {
      for (itrk=0; itrk<TRK_NUM; itrk++) {
        if (trk_priority[itrk] == I && trk_status[itrk] != 1) {
          if (tracking_condition(TimUTC, UT1_UTC, trk_pos[itrk],
                      OBS_T, OBS_p, OFF, ant_XYZ, V_xyz_CIP,
                      AZ, EL, dAZdt, dELdt,
                      srt_link, src, sun,
                      srt_AZ, srt_EL, &srt_dAZdt, &srt_dELdt, ptrk, pdis,
                      BODY_X_SUN) == 0) {
            *ntrk   = itrk;
            TRK_SWT = ON;
            break;
          }
        }
      }
    }

    if (TRK_SWT == ON) {
      break;
    }
  }

/*
--------
*/

  if (TRK_SWT == ON) {
    for (itrk=0; itrk<TRK_NUM; itrk++) {
      trk_pos[itrk].UFL = trk_priority[itrk];
    }
    trk_pos[*ntrk].UFL += ON_TRK;
  } else if (TRK_SWT == OFF) {
    *WEIGHT_FLAG_DATA += (float)SRT_TRACKING_CONDITION_LIMIT;
  }

  return TRK_SWT;
}
