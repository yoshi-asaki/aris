#include <stdio.h>
#include <string.h>
#include <math.h>
#include <aris.h>

/****
#define __DEBUG__
****/

int  tracking_config(int ARRAY_ID, char *station_code,
                     struct antenna_position *trk_pos)
{
  int    itrk, NTRK;
  double DPI;

/*
--------
*/

  DPI = dpi / 180.0;

/****
=+++++++++=+++++++++=+++++++++=+++++++++=+++++++++=+++++++++=
CODE      LATITUDE            LONGITUDE           HEIGHT
=+++++++++=+++++++++=+++++++++=+++++++++=+++++++++=+++++++++=
USUDA     +138:21:57.20       +36:07:45.30        0.0
GOLD      -116:47:41.63       +35:03:59.41        0.0
MADR      -004:14:52.80       +40:14:28.68        0.0
TIDB      -211:01:07.35       -35:13:15.60        0.0
GBANK     -079:50:09.08        38:15:02.93        0.0
HART      +027:26:26.52       -25:44:21.48        0.0
MALIND    +040:11:40.218      +02:59:44.007       0.0
****/

  NTRK = 0;

  if (ARRAY_ID == TRACKING_NETWORK ||
      ARRAY_ID == -1 && strncmp(station_code, "USUDA",  5) == 0) {
    sprintf(trk_pos[NTRK].IDC, "USUDA\0");
    trk_pos[NTRK].ARRAY  = TRACKING_NETWORK;
    trk_pos[NTRK].MNTSTA =             ALAZ;
    trk_pos[NTRK].UFL    = ON;
    trk_pos[NTRK].LLH[0] =  (138.0 + 21.0/60.0 + 57.200/3600.0) * DPI;
    trk_pos[NTRK].LLH[1] =  ( 36.0 +  7.0/60.0 + 45.300/3600.0) * DPI;
    trk_pos[NTRK].LLH[2] =  0.0;
    trk_pos[NTRK].AZSV   =  3.0 * DPI;
    trk_pos[NTRK].ELSV   =  3.0 * DPI;
    trk_pos[NTRK].ELLIM  = 20.0 * DPI;
    NTRK++;
  }

  if (ARRAY_ID == TRACKING_NETWORK ||
      ARRAY_ID == -1 && strncmp(station_code, "GOLD",   4) == 0) {
    sprintf(trk_pos[NTRK].IDC, "GOLD\0");
    trk_pos[NTRK].ARRAY  = TRACKING_NETWORK;
    trk_pos[NTRK].MNTSTA =             ALAZ;
    trk_pos[NTRK].UFL    = ON;
    trk_pos[NTRK].LLH[0] = -(116.0 + 47.0/60.0 + 41.630/3600.0) * DPI;
    trk_pos[NTRK].LLH[1] =  ( 35.0 +  3.0/60.0 + 59.410/3600.0) * DPI;
    trk_pos[NTRK].LLH[2] =  0.0;
    trk_pos[NTRK].AZSV   =  3.0 * DPI;
    trk_pos[NTRK].ELSV   =  3.0 * DPI;
    trk_pos[NTRK].ELLIM  = 10.0 * DPI;
    NTRK++;
  }

  if (ARRAY_ID == TRACKING_NETWORK ||
      ARRAY_ID == -1 && strncmp(station_code, "MADR",   4) == 0) {
    sprintf(trk_pos[NTRK].IDC, "MADR\0");
    trk_pos[NTRK].ARRAY  = TRACKING_NETWORK;
    trk_pos[NTRK].MNTSTA =             ALAZ;
    trk_pos[NTRK].UFL    = ON;
    trk_pos[NTRK].LLH[0] = -(  4.0 + 14.0/60.0 + 52.800/3600.0) * DPI;
    trk_pos[NTRK].LLH[1] =  ( 40.0 + 14.0/60.0 + 28.680/3600.0) * DPI;
    trk_pos[NTRK].LLH[2] =  0.0;
    trk_pos[NTRK].AZSV   =  3.0 * DPI;
    trk_pos[NTRK].ELSV   =  3.0 * DPI;
    trk_pos[NTRK].ELLIM  = 10.0 * DPI;
    NTRK++;
  }

  if (ARRAY_ID == TRACKING_NETWORK ||
      ARRAY_ID == -1 && strncmp(station_code, "TIDB",   4) == 0) {
    sprintf(trk_pos[NTRK].IDC, "TIDB\0");
    trk_pos[NTRK].ARRAY  = TRACKING_NETWORK;
    trk_pos[NTRK].MNTSTA =             ALAZ;
    trk_pos[NTRK].UFL    = ON;
    trk_pos[NTRK].LLH[0] = -(211.0 +  1.0/60.0 +  7.350/3600.0) * DPI;
    trk_pos[NTRK].LLH[1] = -( 35.0 + 13.0/60.0 + 15.600/3600.0) * DPI;
    trk_pos[NTRK].LLH[2] =  0.0;
    trk_pos[NTRK].AZSV   =  3.0 * DPI;
    trk_pos[NTRK].ELSV   =  3.0 * DPI;
    trk_pos[NTRK].ELLIM  = 10.0 * DPI;
    NTRK++;
  }

  if (ARRAY_ID == TRACKING_NETWORK ||
      ARRAY_ID == -1 && strncmp(station_code, "GBANK",  5) == 0) {
    sprintf(trk_pos[NTRK].IDC, "GBANK\0");
    trk_pos[NTRK].ARRAY  = TRACKING_NETWORK;
    trk_pos[NTRK].MNTSTA =             ALAZ;
    trk_pos[NTRK].UFL    = ON;
    trk_pos[NTRK].LLH[0] = -( 79.0 + 50.0/60.0 +  9.080/3600.0) * DPI;
    trk_pos[NTRK].LLH[1] =  ( 38.0 + 15.0/60.0 +  2.930/3600.0) * DPI;
    trk_pos[NTRK].LLH[2] =  0.0;
    trk_pos[NTRK].AZSV   =  3.0 * DPI;
    trk_pos[NTRK].ELSV   =  3.0 * DPI;
    trk_pos[NTRK].ELLIM  = 10.0 * DPI;
    NTRK++;
  }

  if (ARRAY_ID == TRACKING_NETWORK ||
      ARRAY_ID == -1 && strncmp(station_code, "HART",   4) == 0) {
    sprintf(trk_pos[NTRK].IDC, "HART\0");
    trk_pos[NTRK].ARRAY  = TRACKING_NETWORK;
    trk_pos[NTRK].MNTSTA =             ALAZ;
    trk_pos[NTRK].UFL    = ON;
    trk_pos[NTRK].LLH[0] =  ( 27.0 + 26.0/60.0 + 26.520/3600.0) * DPI;
    trk_pos[NTRK].LLH[1] = -( 25.0 + 44.0/60.0 + 21.480/3600.0) * DPI;
    trk_pos[NTRK].LLH[2] =  0.0;
    trk_pos[NTRK].AZSV   =  3.0 * DPI;
    trk_pos[NTRK].ELSV   =  3.0 * DPI;
    trk_pos[NTRK].ELLIM  = 10.0 * DPI;
    NTRK++;
  }

  if (ARRAY_ID == TRACKING_NETWORK ||
      ARRAY_ID == -1 && strncmp(station_code, "MALIND", 6) == 0) {
    sprintf(trk_pos[NTRK].IDC, "MALIND\0");
    trk_pos[NTRK].ARRAY  = TRACKING_NETWORK;
    trk_pos[NTRK].MNTSTA =             ALAZ;
    trk_pos[NTRK].UFL    = ON;
    trk_pos[NTRK].LLH[0] =  ( 40.0 + 11.0/60.0 + 40.218/3600.0) * DPI;
    trk_pos[NTRK].LLH[1] =  (  2.0 + 59.0/60.0 + 44.007/3600.0) * DPI;
    trk_pos[NTRK].LLH[2] =  0.0;
    trk_pos[NTRK].AZSV   =  3.0 * DPI;
    trk_pos[NTRK].ELSV   =  3.0 * DPI;
    trk_pos[NTRK].ELLIM  = 10.0 * DPI;
    NTRK++;
  }

  if (ARRAY_ID == TRACKING_NETWORK ||
      ARRAY_ID == -1 && strncmp(station_code, "KIRUNA", 6) == 0) {
    sprintf(trk_pos[NTRK].IDC, "KIRUNA\0");
    trk_pos[NTRK].ARRAY  = TRACKING_NETWORK;
    trk_pos[NTRK].MNTSTA =             ALAZ;
    trk_pos[NTRK].UFL    = ON;
    trk_pos[NTRK].LLH[0] =  ( 20.0 + 20.0/60.0 + 44.000/3600.0) * DPI;
    trk_pos[NTRK].LLH[1] =  ( 67.0 + 49.0/60.0 + 19.000/3600.0) * DPI;
    trk_pos[NTRK].LLH[2] =  0.0;
    trk_pos[NTRK].AZSV   =  3.0 * DPI;
    trk_pos[NTRK].ELSV   =  3.0 * DPI;
    trk_pos[NTRK].ELLIM  =    5.0 * DPI;
    NTRK++;
  }

/********
  if (ARRAY_ID == TRACKING_NETWORK ||
      ARRAY_ID == -1 && strncmp(station_code, "GEOCEN", 6) == 0) {
    sprintf(trk_pos[NTRK].IDC, "GEOCEN\0");
    trk_pos[NTRK].ARRAY  = TRACKING_NETWORK;
    trk_pos[NTRK].MNTSTA =             ALAZ;
    trk_pos[NTRK].UFL    = ON;
    trk_pos[NTRK].LLH[0] =  (  0.0 +  0.0/60.0 +  0.000/3600.0) * DPI;
    trk_pos[NTRK].LLH[1] =  (  0.0 +  0.0/60.0 +  0.000/3600.0) * DPI;
    trk_pos[NTRK].LLH[2] =  -earth_radius;
    trk_pos[NTRK].AZSV   = 90.0 * DPI;
    trk_pos[NTRK].ELSV   = 90.0 * DPI;
    trk_pos[NTRK].ELLIM  = -180.0 * DPI;
    NTRK++;
  }
********/

/*
--------------------------------------------------
*/

  for (itrk=0; itrk<NTRK; itrk++) {
    J_system_geocentric_equatorial_rectangular_coordinate(
        trk_pos[itrk].LLH[0],
        trk_pos[itrk].LLH[1],
        trk_pos[itrk].LLH[2], trk_pos[itrk].XYZ);
#ifdef __DEBUG__
    printf("__DEBUG__  %s\n", trk_pos[itrk].IDC);
    printf("__DEBUG__  %lf  %lf  %lf\n",
        trk_pos[itrk].XYZ[0] / earth_radius,
        trk_pos[itrk].XYZ[1] / earth_radius,
        trk_pos[itrk].XYZ[2] / earth_radius);
#endif /* __DEBUG__ */
  }

  return NTRK;
}
