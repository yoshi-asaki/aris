#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <aris.h>


int  antenna_selection(int *ANT_NUM, int *GRT_NUM, int *SRT_NUM,
                       int *wave_id,
                       double grt_elevation_limit,
                       struct antenna_parameter *ant_prm,
                       char   antenna_code[][10] )
{
  int    iant, itmp, I;

/*
----------
*/

  I = 0;
  for (iant=0; iant<*GRT_NUM; iant++) {
    if (ant_prm[iant].UFL == ON) {
      array_config(-1, wave_id, 0,  &itmp,
                   ant_prm[iant].IDC, ant_prm+I,  ON);
      strncpy(antenna_code[I], ant_prm[I].IDC, strlen(ant_prm[I].IDC));
      if (grt_elevation_limit > ant_prm[I].ELLIM) {
        ant_prm[I].ELLIM = grt_elevation_limit;
      }
      I++;
    }
  }
  *GRT_NUM = I;
  *ANT_NUM = I;
  if (*SRT_NUM > 0) {
    I = array_config(ORBITING, wave_id, *SRT_NUM,  &itmp,
                     "",       ant_prm + *ANT_NUM,  ON);
    for (iant=0; iant<*SRT_NUM; iant++) {
      strncpy(antenna_code[*ANT_NUM+iant],
              ant_prm[*ANT_NUM+iant].IDC,
              strlen(ant_prm[*ANT_NUM+iant].IDC));
    }
    *ANT_NUM += I;
  }

  for (iant=0; iant<*ANT_NUM; iant++) {
    ant_prm[iant].NOSTA = iant + 1;
  }

  return 1;
}
