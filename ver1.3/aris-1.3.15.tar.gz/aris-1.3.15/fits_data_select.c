#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>


#define  SLCT_SECTION   10
#define  NAME_SECTION   20


int  fits_data_select(char fits_fname[][40], int *dsel_flag,
                      float sel_pos, float *cursor_pos, int TV_SWT)
{
  char   string[100];
  int    i, j, I, J, idum, ns;
  int    data_num;
  char   data_sel[3][40];
  float  bttn_box[30][4];
  float  pitch = 0.03;

  data_num = 3;
  for (i=0; i<data_num; i++) {
    dsel_flag[i] = OFF;
    sprintf(fits_fname[i]+1, "ARIS-0%1d.FITS\0", i+1);
    fits_fname[i][0] = '!';
  }

  if (TV_SWT == OFF) {

    printf("Which data is selected : \n");
    printf("[1.target without P-R  2.Cal source  ");
    printf("3.target with P-R  0.RETURN] : ");
    if (fgets(string, sizeof(string), stdin) == NULL) {
      printf("ERROR: FITS_DATA_SELECT: Invalid input.\n");
      return NG;
    }
    sscanf(string, "%d", &ns);
    if (ns == 0) {
      return OFF;
    } else {
      ns--;
    }
    dsel_flag[ns] = ON;

    printf("File name (CR->%s) : ", fits_fname[ns]+1);
    if (fgets(string, sizeof(string), stdin) == NULL) {
      printf("ERROR: FITS_DATA_SELECT: Invalid input.\n");
      return NG;
    }
    if (string[0] != '\n') {
      char_copy(fits_fname[ns]+1, string);
    }
    printf("File name : %s\n", fits_fname[ns]+1);

  } else if (TV_SWT == ON) {

    bttn_box[0][0] = 0.80;
    bttn_box[0][1] = 0.94;
    bttn_box[0][2] = sel_pos;
    bttn_box[0][3] = bttn_box[0][2] + pitch;
    off_button(&idum, "SAVE\0", bttn_box[0]);
    bttn_box[1][0] = 0.80;
    bttn_box[1][1] = 0.94;
    bttn_box[1][2] = sel_pos - 0.04;
    bttn_box[1][3] = bttn_box[1][2] + pitch;
    off_button(&idum, "QUIT\0", bttn_box[1]);

/*
-------------------------------
*/

    sprintf(data_sel[0], "Target without P-R\0");
    sprintf(data_sel[1], "Cal source\0");
    sprintf(data_sel[2], "Target with P-R\0");
    for (i=0; i<data_num; i++) {
      I = SLCT_SECTION + i;
      bttn_box[I][0] = 0.07;
      bttn_box[I][1] = 0.32;
      bttn_box[I][2] = sel_pos - (float)i * 0.04;
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      off_button(&dsel_flag[i], data_sel[i], bttn_box[I]);
    }

/*
-------------------------------
*/

    for (i=0; i<data_num; i++) {
      I = NAME_SECTION + i;
      bttn_box[I][0] = 0.48;
      bttn_box[I][1] = 0.75;
      bttn_box[I][2] = bttn_box[SLCT_SECTION + i][2];
      bttn_box[I][3] = bttn_box[I][2] + pitch;
      cpgsci(1);
      cpgtext(0.38, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3], "File Name\0");
      cpgrect(bttn_box[I][0], bttn_box[I][1], bttn_box[I][2], bttn_box[I][3]);
      cpgsci(0);
      cpgptxt(bttn_box[I][1]-0.015, 0.6*bttn_box[I][2]+0.4*bttn_box[I][3],
              0.0, 1.0, fits_fname[i]+1);
      cpgsci(1);
    }

/*
-------------------------------
*/

    while (1) {
      cpgcurs(cursor_pos, cursor_pos+1, string);

      if (button_chk(cursor_pos, bttn_box[0]) == ON) {
        on_button(&idum, "SAVE\0", bttn_box[0]);
        return ON;
      }

      if (button_chk(cursor_pos, bttn_box[1]) == ON) {
        on_button(&idum, "QUIT\0", bttn_box[1]);
        return OFF;
      }

      for (i=0; i<data_num; i++) {
        I = SLCT_SECTION + i;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          toggle_button(&dsel_flag[i], data_sel[i], bttn_box[I]);
        }
      }

      for (i=0; i<data_num; i++) {
        I = NAME_SECTION + i;
        if (button_chk(cursor_pos, bttn_box[I]) == ON) {
          tv_get_param("char", cursor_pos, bttn_box[I],
                       pitch, fits_fname[i]+1, 0, 0);
        }
      }
    }
  }
}
