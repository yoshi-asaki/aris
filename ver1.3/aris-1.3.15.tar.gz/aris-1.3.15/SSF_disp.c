#include <stdio.h>
#include <math.h>
#include <cpgplot.h>
#include <mathtools.h>
#include <aris.h>

/**
#define __LANDSCAPE__
**/
#define __LANDSCAPE__
#ifndef __LANDSCAPE__
  #define __PORTRATE__
#endif

/****
#define __FILE_OUT__
#define __DEBUG__
****/


int   SSF_disp(int    ANT_NUM,
               int    GRT_NUM,
               int    BGN_ANT_I, int END_ANT_I,
               int    BGN_ANT_J, int END_ANT_J,
               int    nobs,      int nfrq,
               int    *TimUT,    double UT1_UTC,
               double *nu,
               struct antenna_parameter *ant_prm,
               struct fringe            *frng[],
               float  *fringe_weight[])
{
  int    i, j, k, iobs, ifrq, NS;
  int    ibase, nbase[2];
  int    I, IF;
  int    ndat;
  int    iant, jant;
  int    idat, jdat;
  int    nmin, nmax;
  float  *pgx[2], *pgy[2];
  float  ftmp1,  ftmp2;
  float  pgxmin, pgxmax;
  float  pgymin, pgymax;
  float  dphs;
  float  a, b, c;
  double ar, ai;
  float  *phs, *tim;
  char   p_title[50], y_lab[50];

#ifdef __FILE_OUT__
  FILE   *log_fp;
#endif /* __FILE_OUT__ */

/*
-----------------------------
*/

  cpgscr(0, 1.0, 1.0, 1.0);
  cpgscr(1, 0.0, 0.0, 0.0);
  cpgpap(1.5*pgpap_prm, 1.0);
  cpgsch(1.0);

/*
-----------------------------
*/

  ibase = 0;
  for (iant=BGN_ANT_I; iant<END_ANT_I; iant++) {
    for (jant=BGN_ANT_J; jant<END_ANT_J; jant++) {
      ibase++;
    }
  }

/*
-----------------------------
*/

  if ((pgx[0] = (float *)calloc(ibase, sizeof(float))) == NULL) {
    printf("ERROR: allanv_disp: memory allocation for pgx.\n");
    return ( NG);
  }
  if ((pgx[1] = (float *)calloc(ibase, sizeof(float))) == NULL) {
    printf("ERROR: allanv_disp: memory allocation for pgx.\n");
    free (pgx[0]);
    return ( NG);
  }
  if ((pgy[0] = (float *)calloc(ibase, sizeof(float))) == NULL) {
    printf("ERROR: allanv_disp: memory allocation for pgy.\n");
    free (pgx[0]);
    free (pgx[1]);
    return ( NG);
  }
  if ((pgy[1] = (float *)calloc(ibase, sizeof(float))) == NULL) {
    printf("ERROR: allanv_disp: memory allocation for pgy.\n");
    free (pgx[0]);
    free (pgx[1]);
    free (pgy[0]);
    return ( NG);
  }

  if ((tim = (float *)calloc(nobs,  sizeof(float))) == NULL) {
    printf("ERROR: allanv_disp: memory allocation for tim.\n");
    free (pgx[0]);
    free (pgx[1]);
    free (pgy[0]);
    free (pgy[1]);
    return ( NG);
  }
  if ((phs = (float *)calloc(nobs,  sizeof(float))) == NULL) {
    printf("ERROR: allanv_disp: memory allocation for rms.\n");
    free (pgx[0]);
    free (pgx[1]);
    free (pgy[0]);
    free (pgy[1]);
    free (tim);
    return ( NG);
  }

/*
-----------------------------
*/

  for (IF=0; IF<2; IF++) {
    if (IF == 0) {
      NS = 0;
    } else {
      NS = 2;
    }

    nbase[IF] = 0;
    for (iant=0; iant<ANT_NUM; iant++) {
      for (jant=iant+1; jant<ANT_NUM; jant++) {
        if (iant >= BGN_ANT_I && iant < END_ANT_I &&
            jant >= BGN_ANT_J && jant < END_ANT_J) {
          i = 0;
          for (iobs=0; iobs<nobs; iobs++) {
            j = nbase[IF] * nobs + iobs;
            if (fringe_weight[NS][j] > 0.0) {
              tim[i] = (float)(3600*TimUT[3] + 60*TimUT[4] + TimUT[5] + iobs);
              ar = 0.0;
              ai = 0.0;
              for (ifrq=0; ifrq<nfrq; ifrq++) {
                k = j * nfrq + ifrq;
                ar += frng[NS][k].rl;
                ai += frng[NS][k].im;
              }
              phs[i] = atan2(ai, ar);
              i++;
            }
          }

          if (i != 0) {
            ndat = i;
            for (i=0; i<ndat-1; i++) {
              dphs = phs[i+1] - phs[i];
              if (fabs(dphs) > (float)dpi) {
                phs[i+1] -= 2.0 * dpi * rint(dphs / 2.0 / dpi);
              }
            }
            lstsqr(ndat, tim, phs, &a, &b, &c, 1);
            pgy[IF][nbase[IF]] = sqrt(c) / 2.0 / dpi / nu[NS] * speed_of_light;
            pgx[IF][nbase[IF]] = sqrt(
                      pow(diff(ant_prm[iant].XYZ[0], ant_prm[jant].XYZ[0]), 2.0) 
                    + pow(diff(ant_prm[iant].XYZ[1], ant_prm[jant].XYZ[1]), 2.0) 
                    + pow(diff(ant_prm[iant].XYZ[2], ant_prm[jant].XYZ[2]), 2.0));
            nbase[IF]++;
          }
        }
      }
    }
  }

/*
-----------------------------
*/

#ifdef __FILE_OUT__
  if ((log_fp = fopen("aris_log/ssf.log", "w")) == NULL) {
    printf("Warning; ORBIT_DISP: ./aris_log/ssf.log cannot be made.\n");
  } else {
    fprintf(log_fp, "time [s]  %s\n", y_lab);
    for (ibase=0; ibase<nbase[0]; ibase++) {
      fprintf(log_fp, "%12f,   %12.8f\n", pgx[0][ibase], pgy[0][ibase]);
    }
    for (ibase=0; ibase<nbase[1]; ibase++) {
      fprintf(log_fp, "%12f,   %12.8f\n", pgx[1][ibase], pgy[1][ibase]);
    }
    fclose (log_fp);
  }
#endif /* __FILE_OUT__ */

/*
-----------------------------
*/

  fmaxmin(nbase[0], pgx[0], &ftmp1, &ftmp2, &nmin, &nmax);
  pgxmin = ftmp1;
  pgxmax = ftmp2;
  fmaxmin(nbase[0], pgy[0], &ftmp1, &ftmp2, &nmin, &nmax);
  pgymin = ftmp1;
  pgymax = ftmp2;

  fmaxmin(nbase[1], pgx[1], &ftmp1, &ftmp2, &nmin, &nmax);
  if (pgxmin > ftmp1) {
    pgxmin = ftmp1;
  }
  if (pgxmax < ftmp2) {
    pgxmax = ftmp2;
  }
  fmaxmin(nbase[1], pgy[1], &ftmp1, &ftmp2, &nmin, &nmax);
  if (pgymin > ftmp1) {
    pgymin = ftmp1;
  }
  if (pgymax < ftmp2) {
    pgymax = ftmp2;
  }

  pgxmin = log10(pgxmin);
  pgxmax = log10(pgxmax);
  pgymin = log10(pgymin);
  pgymax = log10(pgymax);

  ftmp1 = pgxmax - pgxmin;
  ftmp2 = pgymax - pgymin;
  if (ftmp1 > ftmp2) {
    ftmp1 = 0.5 * (ftmp1 - ftmp2);
    pgymin -= ftmp1;
    pgymax += ftmp1;
  } else {
    ftmp1 = 0.5 * (ftmp2 - ftmp1);
    pgxmin -= ftmp1;
    pgxmax += ftmp1;
  }
  ftmp1 = 0.05 * (pgxmax - pgxmin);
  pgxmin -= ftmp1;
  pgxmax += ftmp1;
  pgymin -= ftmp1;
  pgymax += ftmp1;

  for (IF=0; IF<2; IF++) {
    for (ibase=0; ibase<nbase[IF]; ibase++) {
      pgx[IF][ibase] = log10(pgx[IF][ibase]);
      pgy[IF][ibase] = log10(pgy[IF][ibase]);
    }
  }

  cpgsvp(0.15, 0.90, 0.15, 0.90);
  cpgswin(pgxmin, pgxmax, pgymin, pgymax);
  cpgsci(1);
  cpgtbox("BCNLTS", 0.0, 0, "BCNLTS", 0.0, 0);
  cpglab("Baseline [m]", "RMS Phase (EPL) [m]", "");

  cpgsci(1);
  cpgpt(nbase[0], pgx[0], pgy[0], 17);
  cpgsci(2);
  cpgpt(nbase[1], pgx[1], pgy[1], 17);

/*
-----------------------------
*/

  for (IF=0; IF<2; IF++) {
    i = 0;
    for (ibase=0; ibase<nbase[IF]; ibase++) {
      if (pgx[IF][ibase] >= 3.0) {
        pgx[IF][i] = pgx[IF][ibase];
        pgy[IF][i] = pgy[IF][ibase];
        i++;
      }
    }
    lstsqr(i, pgx[IF], pgy[IF], &a, &b, &c, 0);
    printf("aaaaaaaaaaaaa   %f    %f\n", pow(10.0, a*3.0+b) * 1.0e6, pow(10.0, a*4.0+b) * 1.0e6);
  }



/*
-----------------------------
*/

  free (pgx[0]);
  free (pgx[1]);
  free (pgy[0]);
  free (pgy[1]);
  free (tim);
  free (phs);

  return (1);
}
