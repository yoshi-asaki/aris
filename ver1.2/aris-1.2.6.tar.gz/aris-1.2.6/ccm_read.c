#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <aris.h>


int   ccm_read(char *cc_file, float *dist, int dsize,
               double *pix_uvl, double *pix_mas, double wave_length,
               double uv_max,   double *uv_factor)
{
  FILE   *ccfp;
  double dx, dy, delta_x, delta_y;
  double a00, a01, a10, a11;
  double dist_flux;
  double cflux, lfdum;
  int    ix, iy, idum;
  int    ncnt;
  char   string[500];
  int    i, j;
  double nd, pix_mas_tmp_x, pix_mas_tmp_y;
  double d_pix, d_pix_tmp, *d_x, *d_y;

/*
------------------------------------
*/

  if ((ccfp=fopen(cc_file, "r")) == NULL) {
    printf("ERROR: ccm_read: CC FILE [%s] does not exit.\n", cc_file);
    return (NG);
  }

/*
--------
*/

  while (1) {
    if (fgets(string, sizeof(string), ccfp) == NULL) {
      break;
    }
    if (strncmp(string, "    Comp", 8) == 0) {
      break;
    }
  }
  if (fgets(string, sizeof(string), ccfp) == NULL) {
    printf("ERROR: CC_READ: Invalid input\n");
    fclose (ccfp);
    return (NG);
  }
  if (fgets(string, sizeof(string), ccfp) == NULL) {
    printf("ERROR: CC_READ: Invalid input\n");
    fclose (ccfp);
    return (NG);
  }

/*
--------
*/

  ncnt = 1;
  while (1) {
    if (fgets(string, sizeof(string), ccfp) == NULL) {
      break;
    }
    sscanf(string, "%d %lf %lf %lf %lf",
           &idum, &delta_x, &delta_y, &cflux, &lfdum);

    if (idum == ncnt) {
      if (cflux >= 0.0) {
        ncnt++;
      } else {
        while (1) {
          if (fgets(string, sizeof(string), ccfp) == NULL) {
            break;
          }
          if (strncmp(string, "    Comp", 8) == 0) {
            break;
          }
        }
        if (fgets(string, sizeof(string), ccfp) == NULL) {
          break;
        }
        if (fgets(string, sizeof(string), ccfp) == NULL) {
          break;
        }
      }
    }
  }
  fclose (ccfp);

/*
====================================
*/

  if ((ccfp=fopen(cc_file, "r")) == NULL) {
    printf("ERROR: ccm_read: CC FILE [%s] does not exit.\n", cc_file);
    return (NG);
  }

/*
--------
*/

  while (1) {
    if (fgets(string, sizeof(string), ccfp) == NULL) {
      break;
    }
    if (strncmp(string, "    Comp", 8) == 0) {
      break;
    }
  }
  if (fgets(string, sizeof(string), ccfp) == NULL) {
    printf("ERROR: CC_READ: Invalid input\n");
    fclose (ccfp);
    return (NG);
  }
  if (fgets(string, sizeof(string), ccfp) == NULL) {
    printf("ERROR: CC_READ: Invalid input\n");
    fclose (ccfp);
    return (NG);
  }

/*
--------
*/

  if ((d_x = (double *)calloc(ncnt, sizeof(double))) == NULL) {
    printf("ERROR: ccm_read: cannot allocate memory for d_x.\n");
    return (NG);
  }
  if ((d_y = (double *)calloc(ncnt, sizeof(double))) == NULL) {
    printf("ERROR: ccm_read: cannot allocate memory for d_y.\n");
    free (d_x);
    return (NG);
  }

  ncnt = 0;
  while (1) {
    if (fgets(string, sizeof(string), ccfp) == NULL) {
      break;
    }
    sscanf(string, "%d %lf %lf %lf %lf",
           &idum, &delta_x, &delta_y, &cflux, &lfdum);
    if (cflux >= 0.0) {
      d_x[ncnt] = delta_x;
      d_y[ncnt] = delta_y;
      ncnt++;
    } else {
      while (1) {
        if (fgets(string, sizeof(string), ccfp) == NULL) {
          break;
        }
        if (strncmp(string, "    Comp", 8) == 0) {
          break;
        }
      }
      if (fgets(string, sizeof(string), ccfp) == NULL) {
        break;
      }
      if (fgets(string, sizeof(string), ccfp) == NULL) {
        break;
      }
    }
  }
  fclose (ccfp);

/*
--------
*/

  d_pix = -1.0;
  for (i=0; i<ncnt; i++) {
    for (j=i+1; j<ncnt; j++) {
      d_pix_tmp = fabs(d_x[i] - d_x[j]);
      if (d_pix_tmp > 0.0) {
        if (d_pix_tmp < d_pix || d_pix < 0.0) {
          d_pix = d_pix_tmp;
        }
      }
      d_pix_tmp = fabs(d_y[i] - d_y[j]);
      if (d_pix_tmp > 0.0) {
        if (d_pix_tmp < d_pix || d_pix < 0.0) {
          d_pix = d_pix_tmp;
        }
      }
    }
  }

  d_pix /= 1000.0;

  if (*pix_mas <= 0.0) {
    *pix_mas = d_pix;
    pixel_calc(pix_uvl, pix_mas, wave_length, uv_max, uv_factor, dsize, -1);
  } else {
    if (d_pix >= 0.0) {
      if (d_pix > *pix_mas) {
        nd = rint(d_pix / *pix_mas);
        *pix_mas = d_pix / nd;
      } else if (d_pix <= *pix_mas) {
        if (*pix_mas / d_pix < 2.0) {
          *pix_mas = d_pix;
        }
      }
      pixel_calc(pix_uvl, pix_mas, wave_length, uv_max, uv_factor, dsize, -1);
    } else if (d_x[0] != 0.0 || d_y[0] != 0.0) {
      if (d_x[0] != 0.0) {
        if (d_x[0] > *pix_mas) {
          nd = rint(d_x[0] / *pix_mas);
          pix_mas_tmp_x = d_x[0] / nd;
        } else if (d_x[0] <= *pix_mas) {
          if (*pix_mas / d_x[0] < 2.0) {
            pix_mas_tmp_x = d_x[0];
          }
        }
      }
      if (d_y[0] != 0.0) {
        if (d_y[0] > *pix_mas) {
          nd = rint(d_y[0] / *pix_mas);
          pix_mas_tmp_y = d_y[0] / nd;
        } else if (d_y[0] <= *pix_mas) {
          if (*pix_mas / d_y[0] < 2.0) {
            pix_mas_tmp_y = d_y[0];
          }
        }
      }
      if (pix_mas_tmp_x <= pix_mas_tmp_y) {
        *pix_mas = pix_mas_tmp_x;
      } else {
        *pix_mas = pix_mas_tmp_y;
      }
      pixel_calc(pix_uvl, pix_mas, wave_length, uv_max, uv_factor, dsize, -1);
    }
  }

  free (d_x);
  free (d_y);

/*
====================================
*/

  if ((ccfp=fopen(cc_file, "r")) == NULL) {
    printf("ERROR: ccm_read: CC FILE [%s] does not exit.\n", cc_file);
    return (NG);
  }

/*
--------
*/

  while (1) {
    if (fgets(string, sizeof(string), ccfp) == NULL) {
      break;
    }
    if (strncmp(string, "    Comp", 8) == 0) {
      break;
    }
  }
  if (fgets(string, sizeof(string), ccfp) == NULL) {
    printf("ERROR: CC_READ: Invalid input\n");
    fclose (ccfp);
    return (NG);
  }
  if (fgets(string, sizeof(string), ccfp) == NULL) {
    printf("ERROR: CC_READ: Invalid input\n");
    fclose (ccfp);
    return (NG);
  }

/*
--------
*/

  ncnt = 1;
  while (1) {
    if (fgets(string, sizeof(string), ccfp) == NULL) {
      break;
    }
    sscanf(string, "%d %lf %lf %lf %lf",
           &idum, &delta_x, &delta_y, &cflux, &lfdum);

    if (idum == ncnt) {
      delta_x /= 1000.0;
      delta_y /= 1000.0;
      ix = (int)rint(delta_x / *pix_mas) + dsize / 2;
      iy = (int)rint(delta_y / *pix_mas) + dsize / 2;

      if (ix >= 0 && ix < dsize &&
          iy >= 0 && iy < dsize && cflux >= 0.0) {
        dx = delta_x - (double)ix;
        dy = delta_y - (double)iy;
        dist[dsize *  ix + iy ] += cflux;
        ncnt++;

      } else {
        while (1) {
          if (fgets(string, sizeof(string), ccfp) == NULL) {
            break;
          }
          if (strncmp(string, "    Comp", 8) == 0) {
            break;
          }
        }
        if (fgets(string, sizeof(string), ccfp) == NULL) {
          break;
        }
        if (fgets(string, sizeof(string), ccfp) == NULL) {
          break;
        }
      }
    }
  }
  fclose (ccfp);

/*
--------
*/

  if (ncnt == 1) {
    printf("ERROR: ccm_read: NO CC component exists.\n");
    return (NG);
  }

  return (1);
}
