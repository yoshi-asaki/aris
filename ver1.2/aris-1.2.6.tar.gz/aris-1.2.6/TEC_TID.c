#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>


int    TEC_TID(
         int GRT_NUM,         int iobs,
         double *ion_ds[],
         struct antenna_position        trk_pos,
         struct phase_screen_parameter  ion,
         struct st_observable  *int_obs[],
         struct TID TID, double elevation_limit)
{
  int    i, I, ns, iant;
  double AZ, EL, dAZdt, dELdt;
  double rho, el, ARC, R, r, dz, ehta, S[3];
  double ant_XYZ[3];
  double z, Z;
  double tdum, pdum;

/*
==============================================================
*/

  R = ion.H_d + earth_radius;

  ant_XYZ[0] = trk_pos.XYZ[0];
  ant_XYZ[1] = trk_pos.XYZ[1];
  ant_XYZ[2] = trk_pos.XYZ[2];

  if (EL >= elevation_limit) {
    spherical_geometry(ion.H_d, EL, &z, &rho, &el, &Z, &dz);
    r = sin(dz) / sin(z) * R;
    S[0] = r * cos(AZ) * cos(EL);
    S[1] = r * sin(AZ) * cos(EL);
    S[2] = r * sin(EL);

    drotate(S, trk_pos.LLH[1]-0.5*dpi, "x");
    drotate(S, trk_pos.LLH[0]-0.5*dpi, "z");

    S[0] += ant_XYZ[0];
    S[1] += ant_XYZ[1];
    S[2] += ant_XYZ[2];

    ARC = R * (0.5 * dpi - atan2(S[2], vlen2(S)));
    ehta = 2.0 * dpi * (TID.v[1] * (double)iobs - ARC) / TID.lambda;

    *(ion_ds[ns] + I) += TID.amp * sin(ehta);
  }

  return 1;
}
