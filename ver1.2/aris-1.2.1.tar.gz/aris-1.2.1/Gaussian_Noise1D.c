#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <aris.h>


void   Gaussian_Noise1D(int N, double sigma, double *gn)
{
  int    i, nlog;
  int    NDIV, M;
  float  fai;
  double amp;
  float  *wx, *wy;

  nlog = 0;
  M = 1;
  while (M < N) {
    M *= 2;
    nlog++;
  }
  if ((wx = (float *)calloc(M, sizeof(float))) == NULL) {
    printf("fail in Gaussian_Noise1D for memory allocation of wx.\n");;
    exit (-1);
  }
  if ((wy = (float *)calloc(M, sizeof(float))) == NULL) {
    printf("fail in Gaussian_Noise1D for memory allocation of wy.\n");;
    exit (-1);
  }

  for (i=0; i<M; i++) {
    fai = dpi * random_val1();
    wx[i] = (float)cos(fai);
    wy[i] = (float)sin(fai);
  }

  i = 0;
  fftrfm(wx, wy, &M, &nlog, &i);

  amp = 1.0 / sqrt((double)(M/2)) * sigma;
  for (i=0; i<N; i++) {
    gn[i] = amp * (double)wx[i];
  }

  free (wx);
  free (wy);
}
