#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <aris.h>

#define  NM  400

void pg_color_bar(float bias, float width,
                  float x1, float x2, float y1, float y2,
                  int NEGATIVE_COMP_SWT, char *mode)
{
  int    i, N1;
  float  e, tx[2], ty[2];
  float  CR, CB, CG;
  float  E, BIAS, WIDTH;

/*
----------
*/

  cpgsvp(x1, x2, y1, y2);
  cpgswin(bias, bias+width, 0.0, 1.0);
  cpgsci(1);
  cpgbox("BCN", 0.0, 0, "BC", 0.0, 0);

  if (NEGATIVE_COMP_SWT == OFF) {
    ty[0] = 0.0;
    ty[1] = 1.0;
    E = (float)NM;
    for (i=0; i<=NM; i++) {
      e = (float)i / E;
      set_color(e, &CR, &CG, &CB, NEGATIVE_COMP_SWT, mode);
      cpgscr(10, CR, CG, CB);
      cpgsci(10);
      e = bias + e * width;
      tx[0] = e;
      tx[1] = e;
      cpgline(2, tx, ty);
    }
  } else if (NEGATIVE_COMP_SWT == ON) {
    if (bias >= 0.0) {
      N1 = 0;
      BIAS  = bias;
      WIDTH = width;
    } else {
      if (bias + width < 0.0) {
        N1 = NM + 1;
        BIAS  = fabs(bias);
      } else {
        N1 = (int)rint((float)NM * (fabs(bias) / width));
        BIAS  = fabs(bias);
        WIDTH = width - BIAS;
      }
    }

    ty[0] = 0.0;
    ty[1] = 1.0;
    E = (float)N1;
    for (i=0; i<N1; i++) {
      e = (float)i / E - 1.0;
      set_color(e, &CR, &CG, &CB, NEGATIVE_COMP_SWT, mode);
      cpgscr(10, CR, CG, CB);
      cpgsci(10);
      e = e * BIAS;
      tx[0] = e;
      tx[1] = e;
      cpgline(2, tx, ty);
    }

    if (bias < 0.0) {
      BIAS = 0.0;
    }
    E = (float)(NM - N1);
    for (i=N1; i<=NM; i++) {
      e = (float)(i - N1) / E;
      set_color(e, &CR, &CG, &CB, NEGATIVE_COMP_SWT, mode);
      cpgscr(10, CR, CG, CB);
      cpgsci(10);
      e = BIAS + e * WIDTH;
      tx[0] = e;
      tx[1] = e;
      cpgline(2, tx, ty);
    }
  }
}
