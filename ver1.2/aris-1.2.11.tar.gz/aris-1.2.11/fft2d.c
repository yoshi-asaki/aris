#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <aris.h>


void  fft2d(float *mapr, float *mapi, int  fmax, int nflag)
{
  int    i, j, n, iter, N, ITER;
  int    IREF, JREF, LEN1, LEN2;
  float  *wx, *wy;

  wx = calloc(fmax, sizeof(float));
  wy = calloc(fmax, sizeof(float));

  IREF = fmax / 2;
  JREF = fmax / 2;

  LEN1 = sizeof(float) * fmax;
  LEN2 = sizeof(float) * JREF;

  n = fmax;
  iter = 0;
  while (1) {
    n /= 2;
    if (n == 1) {
      iter++;
      break;
    }
    iter++;
  }
  n = fmax;

  for (i=0; i<fmax; i++) {
    memcpy(wx, mapr+i*fmax, LEN1);
    memcpy(wy, mapi+i*fmax, LEN1);
    fftrfm(wx, wy, &n, &iter, &nflag);
    memcpy(mapr+i*fmax+JREF, wx,      LEN2);
    memcpy(mapi+i*fmax+JREF, wy,      LEN2);
    memcpy(mapr+i*fmax,      wx+JREF, LEN2);
    memcpy(mapi+i*fmax,      wy+JREF, LEN2);
  }

/*
----------------------------------
*/

  for (j=0; j<fmax; j++) {
    for (i=0; i<fmax; i++) {
      wx[i] = *(mapr + i*fmax + j);
      wy[i] = *(mapi + i*fmax + j);
    }
    fftrfm(wx, wy, &n, &iter, &nflag);
    for (i=0; i<IREF; i++) {
      *(mapr + (i+IREF)*fmax + j) = wx[i];
      *(mapi + (i+IREF)*fmax + j) = wy[i];
    }
    for (i=IREF; i<fmax; i++) {
      *(mapr + (i-IREF)*fmax + j) = wx[i];
      *(mapi + (i-IREF)*fmax + j) = wy[i];
    }
  }

  free (wx);
  free (wy);
}
