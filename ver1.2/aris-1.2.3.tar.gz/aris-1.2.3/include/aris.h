#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <fitsio.h>

#include <mathtools.h>
#include <astrotools.h>

#include "astro_tmp.h"
/****
#include <Crecipes.h>
#include <nrutil.h>
****/


/**/
#define __ACADEMO__
/**/

#define EPOCH          2000

#define SRC_NUM           2
#define SRC_NUM_P1        3
#define ANTMAX           60
#define SRTMAX            2
#define TRKMAX           10
#define NOISE_MTRX     8192

#define SRC_MORPH_CANDIDATE   5
#define SRC_POINT             0
#define SRC_MULTI_COMP        1
#define SRC_DISK_JETCJET      2
#define SRC_DISK_VSOP2JET     3
#define SRC_CC_COMP           4
#define SRC_BHS_MOD           5

#define LFDMAX          512
#define FLDMAX         2048

#define ON                1
#define OFF               0

#define OK                1
#define NG               -1

#define DAY               1
#define NIGHT             0

#define CTRL_C            3
#define CTRL_D            4
#define BACKSPACE_KEY     8
#define RETURN_KEY       13

#define NO_ANT           -1
#define ALL_ANT           0
#define VLBA              1
#define EVN               2
#define HSA               3
#define VERA              4
#define JNET              5
#define KVN               6
#define LBA               7
#define TRACKING_NETWORK  8
#define ACA               9
#define STAND_ALONE      10
#define INDIVIDUAL       20
#define SLR_NETWORK      30

#define PHS_SCR          10
#define ANT_VIS          20

#define ONBOARD           0
#define TRACKING          1

/**** HEMT ****/
#define L_BAND            1
#define S_BAND            2
#define C_BAND            3
#define X_BAND            4
#define KU_BAND           5
#define KA_BAND           6
#define Q_BAND            7
#define W_BAND            8

/**** SIS  ****/
#define BAND01           11
#define BAND02           12
#define BAND03           13
#define BAND04           14
#define BAND05           15
#define BAND06           16
#define BAND07           17
#define BAND08           18
#define BAND09           19
#define BAND10           20

#define TGT               0
#define REF               1

#define ERROR_NUM  10
#define APOSER      0   /* Antenna POSition ERror              */
#define RPOSER      1   /* Reference POSition ERror            */
#define EOPERR      2   /* Earth Orientation Parameter ERRor   */
#define TDSECZ      3   /* Tropospheric Delta SECZ             */
#define IDSECZ      4   /* Ionospheric Delta SECZ              */
#define TWVTRB      5   /* Tropospheric Water Vapor TuRBulence */
#define IONTRB      6   /* IONospheric TuRBulence              */
#define THRMNS      7   /* THeRMal NoiSe                       */
#define AMPERR      8   /* AMPlitude ERRor                     */
#define SRTAER      9   /* SRT Attitude ERror                  */

#define OFF_SOURCE                    -1.0
#define TELESCOPE_SLEW_SPEED_LIMIT    -2.0
#define GRT_ELEVATION_LIMIT           -4.0
#define SRT_TRACKING_CONDITION_LIMIT  -8.0
#define SRT_EARTH_ECLIPS_SRC         -16.0
#define SRT_EARTH_ECLIPS_SUN         -32.0

#define ALAZ        0   /* ALT AZIMUTH  */
#define EQUA        1   /* EQUATORIAL   */
#define ORBI        2   /* ORBITING     */

#define OFF_TRK   100
#define ON_TRK    200

#define TIME_STEP 300  /* TIME STEP [sec] */

#define NCOMLEN  100

/*
---------------------------------------------------------
      STRUCTURES
---------------------------------------------------------
*/

struct antenna_position
        {
          char   IDC[10];  /** IDentificatio Code of antenna **/
          int    ARRAY;    /** Array Code **/
          int    MNTSTA;   /** Mount Type **/
          int    NOSTA;    /** Station ID Number in Process **/
          int    UFL;      /** Use FLag **/
          double XYZ[3];   /** Position in Cartesian coordinate **/
          double ERR[3];   /** ERRor **/
          double LLH[3];   /** Latitude, Longitude, and Height **/
          double OFS[3];   /** position offset for some reasons **/
          double AZSV;     /** Azimuth Slew Velocity       [rad/s] */
          double ELSV;     /** Elevation Slew Velocity     [rad/s] */
          double AZSA;     /** Azimuth Slew Accerelation   [rad/s/s] */
          double ELSA;     /** Elevation Slew Accerelation [rad/s/s] */
          double ELLIM;    /** Elevation Limit [rad] */
        };
struct antenna_parameter
        {
          char   IDC[10];  /** IDentificatio Code of antenna **/
          int    ARRAY;    /** Array Code **/
          int    MNTSTA;   /** Mount Type **/
          int    NOSTA;    /** Station ID Number in Process **/
          int    UFL;      /** Use FLag **/
          double XYZ[3];   /** Position in Cartesian coordinate **/
          double ERR[3];   /** ERRor **/
          double LLH[3];   /** Latitude, Longitude, and Height **/
          double OFS[3];   /** position offset for some reasons **/
          double AZSV;     /** Azimuth Slew Velocity       [rad/s] */
          double ELSV;     /** Elevation Slew Velocity     [rad/s] */
          double AZSA;     /** Azimuth Slew Accerelation   [rad/s/s] */
          double ELSA;     /** Elevation Slew Accerelation [rad/s/s] */
          double ELLIM;    /** Elevation Limit [rad] */
          double STAXOF;   /** STAXOF **/

          int    FLAG[SRC_NUM];
          double Dm[SRC_NUM];
          double Ae[SRC_NUM];
          double Trx[SRC_NUM];
          double Tsky[SRC_NUM];
          double Tsys[SRC_NUM];
          double SEFD[SRC_NUM];
          double slewt;
          double nmfh[3];
          double nmfh_hcr[3];
          double nmfw[3];
          double d_gain;
        };
struct atmospheric_zenith_error
        {
          double trp;
          double tec;
        };
struct phase_screen_parameter
        {
          double pixel;
          double H_d;
          double H_s;
          double i_coeffi;
          double o_coeffi;
          double c_coeffi;
          double i_expon;
          double o_expon;
          double i_scale[2];
          double o_scale[2];
          double v[2];
        };
struct char_obs_time
        {
          char  start_t[6][10];
          char  obsd[20];
        };
struct char_srt_info
        {
          char  apo[20];
          char  per[20];
          char  inc[20];
          char  OMG[20];
          char  omg[20];
          char  t_0[20];
        };
struct char_src_info
        {
          char  tgt_ra[20];
          char  tgt_dc[20];
          char  ref_ra[20];
          char  ref_dc[20];
          char  mid_ra[20];
          char  mid_dc[20];
          char  dlt_ra[20];
          char  dlt_dc[20];
          char  sepang[20];
          char  posang[20];
        };
struct pair_src_info
        {
          double mid_ra, mid_dc;
          double dlt_ra, dlt_dc;
          double sepang, posang;
        };
struct TID
        {
          double amp;
          double lambda;
          double v[2];
        };
struct srt_data_link
        {
          double FOV_rot_axis[3];
          double FOV_rot_angle;
          int    nzenith;
          char   mask[54000];
        };
struct srt_orbit_parameter
        {
          double a;
          double apogee;
          double perigee;
          double inclination;
          double e;
          double t0;
          double n;
          double Omega;
          double omega;
          double d_Omega;
          double d_omega;
          double ODDA;    /* OD Displacement at Apogee  */
          double ODDP;    /* OD Displacement at Perigee */
          double initial_phase;
          double ef;
          double uplink_freq;
          double downlink_freq;
        };
struct source_parameter
        {
          double RA2k;
          double DC2k;
          double s2k[3];

          double RA;
          double DC;
          double s[3];

          double RA_e;
          double DC_e;
          double s_e[3];

          double flux;
          int    morphology;
        };
struct st_observable
        {
          double u;
          double v;
          double w;
          double grp_delay;
          double ion_delay;
          double local_phs;
          double amp_error;
          double az;
          double el;
          float  wt;
        };
/****
wt : TARGET          : 100 + weight  / 100 + FLAG
     REFERENCE       : 200 + weight  / 100 + FLAG
     (weight = 0 - 1)
     NO FLAG                      :   0
     OFF SOURCE                   : - 1
     TELESCOPE SLEW SPEED LIMIT   : - 2
     GRT ELEVATION LIMIT          : - 4
     SRT TRACKING CONDITION LIMIT : - 8
     SRT EARTH ECLIPS (SOURCE)    : -16
     SRT EARTH ECLIPS (SUN)       : -32
****/
struct fringe
        {
          double rl;
          double im;
          double wt;
        };
struct baseline_uvw
        {
          double u;
          double v;
          double w;
        };
struct EOP_data
        { 
          double WX, WY;
          double Qt[3][3];
          double W[3][3];
        };
struct earth_shape
        {
          int    n_day, n_ngt, n_shd;
          float  s_day[2][3000];
          float  s_ngt[2][3000];
          float  s_shd[2][3000];
        };
struct comment_param
        {
          int    ncol;
          float  xmin, xmax, ymin, ymax;
          float  pitch;
        };
struct morphology_file_name
        {
          char   mcm[100];
          char   cct[100];
          char   bhs[100];
          char   asc[100];
        };

/*
---------------------------------------------------------
      FUNCTIONS
---------------------------------------------------------
*/

void    free_memory_block
        (
          void   *[],    int  
        );
void    free_memory_block_char
        (
          char    **,    int  
        );
void    free_memory_block_float
        (
          float   **,    int  
        );
void    free_memory_block_double
        (
          double  **,    int  
        );
int     obs_param_set
        (
          int       *,    int       *,
          int       *,    int       *,    int       *,
          struct char_srt_info      *,
          struct srt_orbit_parameter                *,
          char      *,    double    *,
          double     ,
          struct char_obs_time      *,    int       *,    double    *,
          double    *,
          int        ,
          struct char_src_info      *,
          struct pair_src_info      *,
          struct source_parameter   *,
          struct source_parameter   *,
          struct antenna_parameter  *
        );
int     obs_param_input
        (
          int       *,    int       *,    int       *,
          int       *,    int       *,    int       *,
          struct srt_orbit_parameter                *,
          double    *,
          struct phase_screen_parameter             *,
          struct phase_screen_parameter             *,
          double    *,
          double            [][86400],
          float     *,
          double     ,
          int       *,    double    *,    double    *,
          struct source_parameter   *,
          struct source_parameter   *,
          struct antenna_parameter  *,
          struct comment_param      *,    char   [][NCOMLEN],
          int        ,    float     *,    int       *
        );
int     obs_param_file_io(
          int       *,    int       *,    int       *,
          int       *,    int       *,    int       *,
          struct srt_orbit_parameter                *,
          double    *,
          double     ,
          int       *,
          double    *,    double    *,
          int       *,    int       *,
          struct source_parameter   *,
          struct source_parameter   *,
          struct antenna_parameter  *,
          char      *,
          struct  pair_src_info     *,
          struct  char_src_info     *,
          struct  char_srt_info     *,
          struct  char_obs_time     *,
          int
        );
int     ch_time_set
        (
          int       *,    struct char_obs_time  *
        );
int     antenna_selection
        (
          int       *,    int       *,   int    *,
          int       *,    double     ,
          struct antenna_parameter  *,
          struct srt_orbit_parameter            *,
          char [][10]

        );
int     number_char_cut
        (
          char      *
        );
int     srt_info_disp
        (
          int        ,    float      ,    float [][4],    float      ,
          char      *,    int       *,
          struct char_srt_info      *
        );
int     err_parameter_set
        (
          int        ,    int        ,    int        ,
          int       *,    int       *,
          int       *,    int       *,
          int        ,
          double    *,    double    *,
          struct atmospheric_zenith_error           *,
          struct source_parameter   *,
          struct morphology_file_name               *,
          int       *,    double    *,    double    *,
          double    *,    int       *,    double    *,
          int       *,    struct srt_orbit_parameter                *,
          int       *,
          int       *,    struct antenna_parameter                  *,
          int       *,    struct antenna_position                   *,
          struct comment_param      *,
          char   [][NCOMLEN],
          int        ,    float     *,    int
        );
int     trk_priority_check
        (
          int        ,    int       *,    char [][10]
        );
double  sun_angle_check
        (
          int       *,    double     ,
          struct source_parameter   *,    struct source_parameter   *
        );
int     source_info_disp
        (
          int        ,    float      ,    float [][4],    float      ,
          struct char_src_info      *
        );
int     menu_config
        (
          int        ,    int        ,    int        ,    int        ,
          int        ,
          int        ,    int        ,    int        ,    int        ,
          int       *,    double     ,    int       *,    int        ,
          struct antenna_parameter                  *,
          struct atmospheric_zenith_error           *,
          struct st_observable     **,
          double     ,    double    *,    double    *,    double   **,
          int        ,    struct fringe            **,    float    **,
          double     ,
          int        ,    double     ,    struct baseline_uvw      **,
          struct source_parameter   *,
          struct source_parameter    ,
          double    *,    double    *,
          struct srt_orbit_parameter                *,
          struct antenna_position                   *,
          struct srt_data_link      *,
          int        ,
          double     ,
          double     ,    double     ,
          double   **,    double   **,
          int        ,    float     *,    int        ,    int
        );
int     on_source_disp
        ( 
          int        ,    int        ,    int        ,
          int       *,    double     ,    int        ,
          struct antenna_parameter  *,
          struct st_observable     **,    double 
        );
int     TV_menu_hatch
        (
          float      ,    float      ,    float      ,    float      ,
          int        ,    int        
        );
int     transformation_matrices
        (
          int       *,
          double [][3],
          double [][3],
          double     ,    double     ,
          double     ,    double
        );
int     fits_data_select
        (
          char [][40],    int       *,
          float      ,    float     *,    int
        );
float   text_bottom
        (
          float      ,    float
        );
void    comment_init
        (
          struct comment_param      *,    char   [][NCOMLEN],
          int        
        );
void    comment_disp
        (
          struct comment_param      *,    char   [][NCOMLEN],
          char      *,    int        
        );
int     source_position
        (
          struct source_parameter   *,
          struct pair_src_info      *,    struct char_src_info      *,
          int
        );
void    input_star_position
        (
          char      *,    char      *,    double    *,    double    *
        );
void    output_star_position
        (
          char      *,    char      *,    double    *
        );
void    on_button
        (
          int       *,    char      *,    float     *
        );
void    off_button
        (
          int       *,    char      *,    float     *
        );
void    toggle_button
        (
          int       *,    char      *,    float     *
        );
int     button_chk
        (
          float     *,    float     *
        );
int     tv_get_param
        (
          char      *,    float     *,    float     *,
          float      ,    char      *,    double     ,    double
        );
int     tv_button_disp
        (
          float     *,    char      *
        );
void    str_init
        (
          char      *,    int
        );
void    char_copy
        (
          char      *,    char      *
        );
void    char_ncopy
        (
          char      *,    char      *,    int
        );
int     minor_shift_refpos
        (
          double    *,    double    *,    double    *,    double    *,
          double    *,    double    *
        );
int     ref_pos_shift
        (
          struct source_parameter   *,
          struct comment_param      *,
          char   [][NCOMLEN],
          int        ,    int 
        );
int     array_config
        (
          int        ,    int       *,    int        ,    int       *,
          char      *,
          struct antenna_parameter  *,
          struct srt_orbit_parameter                *,
          int
        );
int     wave_select
        (
          int        ,    double    *,    double    *
        );

void    Gaussian_Noise1D
        (
          int        ,    double     ,    double    *
        );
double  gauss_dev
        (
          void
        );
int     atmospheric_fluctuation
        (
          int        ,    int        ,    int        ,    double  *[],
          int       *,    double     ,
          struct antenna_parameter  *,
          struct phase_screen_parameter             *,
          struct source_parameter                   *,
          double     ,    double     ,
          int        ,    int        ,    int        ,    int        ,
          int        ,    struct comment_param      *,
          char            [][NCOMLEN],    int
        );
int     turbulent_phase_screen
        (
          int        ,    int        ,    double    *,    double    *,
          double    *,
          struct phase_screen_parameter             *,
          int        ,    int        ,    int        ,
          int       *,    int       *,    double    *,
          int   [][2],    int
        );
int     phase_screen_check
        (
          int        ,    struct phase_screen_parameter              ,
          float     *,    int        ,    int       *
        );
int     antenna_visibility
        (
          int       *,    int        ,    int        ,    int        ,
          struct antenna_parameter  *,
          struct source_parameter   *,    struct source_parameter    ,
          struct phase_screen_parameter             *,
          struct phase_screen_parameter             *,
          double    *,
          double            [][86400],
          float     *,
          struct srt_orbit_parameter                *,
          struct antenna_position   *,
          double     ,

          struct comment_param      *,    char   [][NCOMLEN],
          int        ,    int       *
        );
int     TEC_TID
        (
          int        ,    int        ,    double  *[],
          struct antenna_position    ,
          struct phase_screen_parameter              ,
          struct st_observable    *[],
          struct TID                 ,
          double
        );
int     GRT_TEC_TID
        (
          int        ,    int        ,    double  *[],
          struct antenna_parameter  *,
          struct phase_screen_parameter             *,
          struct st_observable    *[],
          struct TID                 
        );
int     TEC_fluctuation_amp
        (
          double [][86400],    int       *
        );
void    Gaussian_noise_check
        (
          void 
        );
void    source_model
        (
          float     *,    int        ,    float      ,    int        ,
          double    *,    float     *,    float     *,    float     *,
          char      *
        );
void    source_model2
        (
          float     *,    int        ,    float      ,    int        ,
          float     *,    float     *,
          float     *,    float     *,    float     *,
          float     *,    float     *,
          char      *
        );
void    jet_cjet
        (
          float     *,    int        ,    double     ,    double     ,
          double
        );
void    PA_rotate
        (
          int        ,    float     *,    float     *,    double
        );
void    ADAF_disk
        (
          float     *,    int        ,    double     ,    double     ,
          double
        );
void    VSOP2_logo
        (
          float     *,    int        ,    double     ,    double     ,
          double
        );
void    set_color
        (
          float      ,    float     *,    float     *,    float     *,
          int        ,    char      *
        );
double  random_val0
        (
          void
        );
double  random_val1
        (
          void
        );
void    fft2d
        (
          float     *,    float     *,    int        ,    int
        );
void    wfft2d
        (
          float     *,    float     *,    float     *,    int        ,
          int
        );
double  snrcal
        (
          double     ,    double     ,    double     ,    double     ,
          double     ,    double     ,    double     ,    double     ,
          double     ,    double
        );
double  thermal_noise_cal
        (
          double     ,    double     ,    double     ,    double     ,
          double     ,    double     ,    double     ,    double     ,
          double     ,    double
        );
void    parabo
        (
          float     *,    float     *,    float      ,    float      ,
          float     *,    float     *,    float     *,    float     *
        );



int     brightness_disp
        (
          int        ,    int        ,    int        ,    int        ,
          float      ,    float      ,    float      ,    float      ,
          float      ,    float      ,
          int        ,
          float     *,    float     *,    float     *,    float     *,
          float   *[],    char      *,    char    *[],
          int        ,    int        ,    int        ,    int        ,
          int        ,    int        ,
          char      *,
          float     *,    float     *,    float     *,
          float     *,    float     *,    float     *,    float     *
        );


void    get_vis
        (
          float     *,    float     *,    int        ,    float     *,
          int
        );
int     visibility_calc
        (
          float     *,    float     *,    int        ,
          double    *,    double    *,
          struct source_parameter    ,
          struct morphology_file_name               *,
          struct comment_param      *,    char            [][NCOMLEN],
          int        ,    int       
        );
int     bhs_model
        (
          float     *,    int        ,    double    *,    double    *,
          char      *
        );
int     cc_read
        (
          char      *,    float     *,    int        ,    double      
        );
void    vis_smoothing
        (
          double    *,    double    *,    float     *,    float     *,
          double     ,    double     ,    int        ,    int        ,
          int        ,    double
        );
void    seed_random
        (
          int
        );
int     qlook_imager
        (
          int        ,
          int        ,    int        ,    int        ,    int        ,
          int        ,    int        ,    struct baseline_uvw     *[],
          struct fringe           *[],    float   *[],
          double    *,    double    *,    double    *
        );
void    imager
        (
          int        ,    struct baseline_uvw       *,    double     ,
          int        ,    struct fringe             *,    float     *,
          float     *,    float     *,    float     *,    int
        );
int     pixel_calc
        (
          double    *,    double    *,    double     ,    double     ,
          double    *,    int        ,    int
        );
int     phase_reference
        (
          int        ,    int        ,
          int        ,    int        ,    int        ,    int        ,
          int        ,    int        ,    double    *,
          struct fringe           *[],    float   *[]
        );
void    pg_color_bar
        (
          float      ,    float      ,    float      ,    float      ,
          float      ,    float      ,    int        ,    char      *
        );
void    pg_color_map
        (
          int        ,    int        ,    int        ,
          float      ,    float      ,    float      ,    float      ,
          float      ,    float      ,    float      ,    float      ,
          float     *,    float      ,
          float      ,    float      ,    float      ,
          char      *,    char      *,    char      *,
          int        ,    int        ,    char      *
        );
void    pgcont_map
        (
          int        ,    int        ,    int        ,
          float      ,    float      ,    float      ,    float      ,
          float      ,    float      ,    float      ,    float      ,
          float     *,    float      ,
          float      ,    float      ,    float      ,
          char      *,    char      *,    char      *,
          int        ,    int        ,    char      *
        );
void    peak_normalize
        (
          int        ,
          float     *,    float     *,    float     *,
          float     *,    float     *,
          float     *,    float     *,
          float      ,
          float      ,
          int        ,    int        ,    int        ,    int        ,
          float     *
        );
int     fitsidi_save
        (
          char      *,    int        ,    int        ,
          int        ,    int        ,    int        ,
          int        ,    int        ,    int        ,    int        ,
          int       *,    double     ,    double     ,
          int        ,    double     ,    double    *,
          struct baseline_uvw     *[],
          struct fringe           *[],    float   *[],
          struct antenna_parameter  *,    struct source_parameter   *,
          struct srt_orbit_parameter                *
        );
int     uvw_calc
        (
          float      ,
          int        ,    int        ,    int        ,
          int        ,    int        ,    int        ,
          int       *,    double     ,
          struct antenna_parameter                  *,
          struct source_parameter                    ,
          struct source_parameter                    ,
          struct phase_screen_parameter             *,
          struct phase_screen_parameter             *,
          double    *,    double [][86400],
          double    *,
          double    *,
          int        ,    int       *,    double [][3],
          double     ,
          struct st_observable      *,
          double     ,    double     ,
          struct atmospheric_zenith_error           *,
          int        ,
          struct srt_orbit_parameter                *,
          double    *,
          int        ,
          struct antenna_position                   *,
          struct srt_data_link      *,
          double     ,    int        ,    struct TID ,    int
        );
int     az_rotation
        (
          int        ,    int        ,    struct st_observable      *,
          struct antenna_parameter   *
        );
int     az_adjustment
        (
          int        ,    int        ,    struct st_observable    *[],
          struct antenna_parameter   *
        );
int     weight_flag_add
        (
          float      ,    float     *,    float
        );
int     weight_flag_chk
        (
          float      ,    float     *,    float
        );
int     attitude_Q
        (
          int        ,
          struct source_parameter    ,
          struct source_parameter    ,
          double    *
        );
int     tracking_condition
        (
          int       *,    double     ,
          struct antenna_position    ,
          double     ,    double     ,    int        ,
          double    *,    double    *,
          double    *,    double    *,
          double    *,    double    *,
          struct srt_data_link      *,
          struct source_parameter    ,
          struct source_parameter    ,
          double    *,    double    *,    double    *,    double    *,
          double    *,    double    *,
          int
        );
int     tracking_status
        (
          int        ,    float     *,    int       *,
          int       *,    double     ,
          struct srt_orbit_parameter ,
          struct source_parameter    ,
          struct source_parameter    ,
          double     ,    double     ,
          int        ,
          double    *,    double    *,    double    *,
          struct antenna_position   *,
          struct srt_data_link      *,
          double    *,    double    *,    double    *,    double    *,
          double    *,    double    *,
          double     ,
          double    *,    double    *,    double    *,
          int        
        );

int     get_srt_link
        (
          struct srt_data_link      *,    double    *
        );
int     allocate_uvcalc_param
        (
          int        ,    double  *[]
        );
int     uv_display
        (
          int        ,    double    *,    int        ,
          int        ,    int        ,    int        ,    int        ,
          struct st_observable    *[],
          double    *,    int        ,    int        ,    float      ,
          int
        );
double  airmass
        (
          double
        );
int     nmf20_coeffi
        (
          double     ,    int        ,
          double    *,    double    *,    double    *
        );
int     nmf20
        (
          double    *,    double    *,
          double    *,    double    *,    double    *,
          double     ,    double     
        );
void    spherical_geometry
        (
          double     ,    double     ,    double    *,
          double    *,    double    *,    double    *,    double    *
        );
int     station_select
        (
          int        ,
          int        ,    int        ,    int        ,    int        ,
          int       *,    int       *,
          struct antenna_parameter  *,    float      ,
          float     *,    int        ,    int        
        );
int     baseline_number
        (
          int        ,    int        ,    int
        );
void    EPL_disp
        (
          int        ,    int        ,    int        ,
          struct antenna_parameter  *,    double    *,
          int       *,    struct st_observable    *[]
        );
int     spectl_disp
        (
          int        ,    int        ,    int        ,
          struct antenna_parameter  *,    double    *,
          int       *,    struct st_observable    *[]
        );
int     allanv_disp
        (
          int        ,    int        ,    int        ,
          struct antenna_parameter  *,    double    *,
          int       *,    struct st_observable    *[]
        );
int     fringe_disp
        (
          int        ,    int        ,
          int        ,    int        ,
          struct antenna_parameter  *,
          int        ,    int        ,
          int       *,    double     ,
          struct fringe           *[],    float   *[],
          float     *
        );
void    position2uvw
        (
          double    *,    double    *,    double    *,    double    *,
          double    *,    double    *,    double    *,
          double     ,    double     ,    double    *
        );
void    spacecraft_position
        (
          struct srt_orbit_parameter ,
          int       *,    double     ,    double     ,
          double    *,    double    *,
          double    *,    double    *,    double    *
        );
void    orbit_propagation
        (
          struct srt_orbit_parameter ,
          int       *,    double     ,    double     ,
          double    *,    double    *,
          double    *,    double    *,    double    *,    int        ,
          double    *,    double    *,    double    *
        );
void    RK04_init
        (
          double    *,    double    *,    double    *
        );
void    RK07_init
        (
          double    *,    double    *,    double    *
        );
void    RK_end
        (
          double    *,    double    *,    double    *
        );
double  f1
        (
          double     ,    double     ,    double     ,    double
        );
double  f2
        (
          double     ,    double     ,    double     ,    double
        );
double  Force_Model
        (
          double    *,    int       *,    double
        );
int     tracking_config
        (
          int        ,    char      *,    struct antenna_position   *
        );
int     slr_config
        (
          struct antenna_position   *
        );
void    intput_star_position
        (
          double    *,    double    *
        );
void    azel_disp
        (
          int        ,    int        ,
          struct antenna_parameter  *,
          struct st_observable    *[],
          int       *,    double
        );
void    orbit_disp
        (
          int        ,    int        ,
          struct srt_orbit_parameter                *,
          int       *,    double     ,    double     ,
          struct srt_data_link      *,
          double     ,    double     ,
          int        ,    int        ,
          struct antenna_position   *,
          struct source_parameter    ,
          struct source_parameter    
        );
void    draw_earth
        (
          double     ,    double     ,    double     ,
          struct source_parameter    ,
          struct source_parameter    ,
          struct earth_shape        *,
          int       *,    int        ,    int        ,    int
        );
void    data_link_schedule
        (
          int        ,    int        ,
          struct srt_orbit_parameter                *,
          struct antenna_position                   *,
          struct source_parameter    ,
          struct source_parameter    ,
          struct srt_data_link      *,
          int       *,    double     ,    double     ,
          double     ,    double     ,
          int        ,    int        ,    int        
        );
void    link_TRK_sim
        (
          int        ,    int        ,
          struct srt_orbit_parameter                *,
          struct antenna_position                   *,
          struct source_parameter    ,
          struct source_parameter    ,
          struct srt_data_link      *,
          int       *,    double     ,    double     ,
          double     ,    double     ,
          int        ,    int        ,    int        
        );
void    link_SLR_sim
        (
          int        ,    int        ,
          struct srt_orbit_parameter                *,
          struct antenna_position                   *,
          struct source_parameter    ,
          struct source_parameter    ,
          struct srt_data_link      *,
          int       *,    double     ,    double     ,
          double     ,    double     ,
          int        ,    int        ,    int        
        );
void    orbit_info_print
        (
          FILE      *,    int        ,
          struct srt_orbit_parameter *,
          int       *,    double
        );
void    delay_rate_disp
        (
          int        ,    int        ,
          struct antenna_parameter  *,
          int        ,
          int       *,
          struct st_observable    *[],    double  *[]
        );
float   ordinate_axis
        (
          int        ,    float     *,    float     *,
          float     *,    char      *
        );
void    position_on_screen
        (
          double     ,    double    *,
          struct phase_screen_parameter              ,
          double     ,    double     ,    double    *,    double    *
        );
int     earth_eclipse
        (
          double    *,    double    *,    double    *,    double    *,
          double
        );
double  diff
        (
          double     ,    double
        );
double  slew_time
        (
          double     ,    double     ,    double     ,
          double     ,    double     ,
          double     ,    double     ,    double     ,
          double     ,    double     
        );
double  SEFD
        (
          double     ,    double     ,    double     ,    double    
        );


double  mean_obliquity_of_the_ecliptic
        (
          int       *,    double
        );
void    nutation_calc
        (
          int       *,    double     ,    double    *,    double    *,
          double    *
        );



/****
#define __RANDOM_SEED__
****/
#define __RANDOM_SEED__



#define TYPE1        1
#define TYPE2        2
#define TYPE3        3

#define F_STRUCTURE  1   /* UV_display Fine Structure Option   */
#define C_STRUCTURE  2   /* UV_display Coarse Structure Option */

/****
static float  pgpap_prm      = 6.25;
****/
static float  pgpap_prm      = 5.50;

static double dpi            = 3.141592653589793238462643;
static double speed_of_light = 2.998e8;
static double OMEGA          = 7.29211585791599e-5;
/**  OMEGA = 2PI / (23*3600 + 56*60 + 4.0905)  **/
static double BOLTZ          = 1.3806503e-23;
static double TEC_CONST      = 40.308;
static double earth_radius   = 6.378137e6;
static double GM             = 398600.4415e9;
/********
#define   G   6.67259e-11
#define   M   5.974e24
********/

/*
XXXX
*/
int    GLOBAL_SWT[2];
/*
XXXX
*/
