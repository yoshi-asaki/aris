#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <aris.h>


void source_model2(float *dist, int dmax, float res,
                   int   n_source,
                   float  *pamp, float  *tamp,
                   float *radius1, float *radius2, float *pa,
                   float *xoff, float *yoff, char  *s_type)
{
  int    i, j, dref, N;
  int    ix0, ix1, iy0, iy1;
  float  amp, x, y, ar, ai;
  float  r_factor, r;
  float  phs, u, v;

/*
--------------------
*/

  dref = dmax / 2;

  for (N=0; N<n_source; N++) {
    amp = pamp[N];
    if (pamp[N] == 0.0) {
      amp = tamp[N];
    }
    if (radius1[N] == 0.0 || radius2[N] == 0.0) {
      *(dist + dmax * (dref + (int)rint(xoff[N]/res))
                     + dref + (int)rint(yoff[N]/res)) += amp;
    } else {
      if (n_source > 5) {
        if (s_type[N] == 'G') {
          r_factor = 8.0;
        } else if (s_type[N] == 'S') {
          r_factor = 2.0;
        }

        r = r_factor * radius1[N];
        ix0 = dref + (int)rint((xoff[N] - r) / res);
        if (ix0 < 0) {
          ix0 = 0;
        }
        ix1 = dref + (int)rint((xoff[N] + r) / res);
        if (ix1 > dmax) {
          ix1 = dmax;
        }
        iy0 = dref + (int)rint((yoff[N] - r) / res);
        if (iy0 < 0) {
          iy0 = 0;
        }
        iy1 = dref + (int)rint((yoff[N] + r) / res);
        if (iy1 > dmax) {
          iy1 = dmax;
        }
      } else {
        ix0 = 0;
        ix1 = dmax;
        iy0 = 0;
        iy1 = dmax;
      }

      phs = 0.5*dpi - pa[N];
      ar = cos(phs);
      ai = sin(phs);

      amp = pamp[N];
      if (pamp[N] == 0.0) {
        if (s_type[N] == 'G') {
          amp = tamp[N] * log(2.0) / dpi / radius1[N] / radius2[N];
        } else if (s_type[N] == 'S') {
          amp = tamp[N] *     2.0  / dpi / radius1[N] / radius2[N];
        }
      }

      for (i=ix0; i<ix1; i++) {
        for (j=iy0; j<iy1; j++) {
          u = res * (float)(i - dref) - xoff[N];
          v = res * (float)(j - dref) - yoff[N];

          x = ar * u - ai * v;
          y = ai * u + ar * v;

          if (s_type[N] == 'G') {
            *(dist + i*dmax + j) +=
                  amp * exp(-log(2.0) * (x*x/radius1[N]/radius1[N]
                                       + y*y/radius2[N]/radius2[N]));
          } else if (s_type[N] == 'S') {
            if (x <= radius1[N] && y <= radius2[N]) {
              *(dist + i*dmax + j) += amp;
            }
          }
        }
      }
    }
  }

  return;
}
