#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <aris.h>


void  wfft2d(float *mapr, float *mapi, float *weight, int  fmax, int nflag)
{
  int    i, j, n, iter;
  int    I, J, pnt_ad;
  int    IREF, JREF;
  int    LEN1, LEN2;
  float  *wx, *wy;
  float  wt;

  wx = (float *)calloc(fmax, sizeof(float));
  wy = (float *)calloc(fmax, sizeof(float));

  IREF = fmax / 2;
  JREF = fmax / 2;

  n = fmax;
  iter = 0;
  while (1) {
    n /= 2;
    if (n == 1) {
      iter++;
      break;
    }
    iter++;
  }
  n = fmax;

  LEN1 = sizeof(float) * fmax;
  LEN2 = sizeof(float) * JREF;
  for (i=0; i<fmax; i++) {
    I = i * fmax;
    memcpy(wx, mapr+I, LEN1);
    memcpy(wy, mapi+I, LEN1);

    fftrfm(wx, wy, &n, &iter, &nflag);
    if (nflag == 1) {
      for (j=0; j<fmax; j++) {
        wt = (float)n * *(weight + i*fmax + j);
        wx[j] *= wt;
        wy[j] *= wt;
      }
    }
    memcpy(mapr+I+JREF, wx,      LEN2);
    memcpy(mapi+I+JREF, wy,      LEN2);
    memcpy(mapr+I,      wx+JREF, LEN2);
    memcpy(mapi+I,      wy+JREF, LEN2);
  }


  for (j=0; j<fmax; j++) {
    for (i=0; i<fmax; i++) {
      pnt_ad = i*fmax + j;
      wx[i] = *(mapr + pnt_ad);
      wy[i] = *(mapi + pnt_ad);
    }
    fftrfm(wx, wy, &n, &iter, &nflag);
    for (i=0; i<IREF; i++) {
      pnt_ad = (i+IREF)*fmax + j;
      *(mapr + pnt_ad) = wx[i];
      *(mapi + pnt_ad) = wy[i];
    }
    for (i=IREF; i<fmax; i++) {
      pnt_ad = (i-IREF)*fmax + j;
      *(mapr + pnt_ad) = wx[i];
      *(mapi + pnt_ad) = wy[i];
    }
  }

  free (wx);
  free (wy);
}
