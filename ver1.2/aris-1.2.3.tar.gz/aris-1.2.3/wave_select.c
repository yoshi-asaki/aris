#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>

int   wave_select(int  wave_id, double *wave_length, double *nu)
{

  int   WID;

  if (wave_id == L_BAND) {
    *wave_length = 0.188;
/********
    *wave_length = 0.00188;
    *wave_length = 0.000188;
    *wave_length = 0.000500;
********/
    WID = 0;
  } else if (wave_id == S_BAND) {
    *wave_length = 0.136;
    WID = 1;
  } else if (wave_id == C_BAND) {
    *wave_length = 6.25e-2;
    WID = 2;
  } else if (wave_id == X_BAND) {
    *wave_length = 3.57e-2;
    WID = 3;
  } else if (wave_id == KU_BAND) {
    *wave_length = 1.96e-2;
    WID = 4;
  } else if (wave_id == KA_BAND) {
    *wave_length = 1.35e-2;
    WID = 5;
  } else if (wave_id == Q_BAND) {
    *wave_length = 6.98e-3;
    WID = 6;
  } else if (wave_id == W_BAND || wave_id == BAND03) {
    *wave_length = 3.49e-3;
    WID = 7;
  } else if (wave_id == BAND04) {
    *wave_length = 2.32e-3;
    WID = 8;
  } else {
    *wave_length = 1.0;
    WID = -1;
  }
  *nu = speed_of_light / *wave_length;

  return WID;
}
