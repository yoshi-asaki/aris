#include <stdio.h>
#include <aris.h>

#include <sys/time.h>
#include <unistd.h>
struct timeval  TV;
/****
struct timezone TZ;
****/


void seed_random(int RAND_SWT)
{
  if (RAND_SWT == ON) {
/****
    gettimeofday(&TV, &TZ);
****/
    gettimeofday(&TV, NULL);
    srand(TV.tv_usec);
  } else {
    srand(17);
  }
}
