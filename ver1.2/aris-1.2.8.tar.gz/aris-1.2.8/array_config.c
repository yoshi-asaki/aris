#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <aris.h>

/****
#define __DEBUG_LLH__
****/

int  array_config(
                  int    ARRAY_ID,
                  int    *wave_id,
                  int    SRT_NUM,
                  int    *GRT_NUM,
                  char   *station_code,
                  struct antenna_parameter *ant_prm,
                  struct srt_orbit_parameter *srt,
                  int    ERR_RESET_SWT)
{
  int    iant, IANT, ns, ANT_NUM;
  double x[3];
  double DPI;

/*
----------------
*/

  DPI = dpi / 180.0;
  IANT = 0;

/*
----------------
*/

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBASC", 6) == 0)) {

/** VLBA_SC **/
    sprintf(ant_prm[IANT].IDC, "VLBASC\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2607848.5623;
    ant_prm[IANT].XYZ[1] =    -5488069.6592;
    ant_prm[IANT].XYZ[2] =     1932739.5672;
    ant_prm[IANT].STAXOF =           2.1270;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -( 64.0 + 35.0/60.0 +  1.07/3600.0);
    ant_prm[IANT].LLH[1] =    17.0 + 45.0/60.0 + 23.68/3600.0;
    ant_prm[IANT].LLH[2] =    16.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBAHN", 6) == 0)) {

/** VLBA_HN **/
    sprintf(ant_prm[IANT].IDC, "VLBAHN\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     1446375.0704;
    ant_prm[IANT].XYZ[1] =    -4447939.6574;
    ant_prm[IANT].XYZ[2] =     4322306.1206;
    ant_prm[IANT].STAXOF =           2.1310;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -( 71.0 + 59.0/60.0 + 11.69/3600.0);
    ant_prm[IANT].LLH[1] =    42.0 + 56.0/60.0 +  0.99/3600.0;
    ant_prm[IANT].LLH[2] =   296.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.40;
        ant_prm[IANT].Trx[ns]  = 60.0;
        ant_prm[IANT].Tsky[ns] =190.0;
        ant_prm[IANT].Tsys[ns] =250.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBANL", 6) == 0)) {

/** VLBA_NL **/
    sprintf(ant_prm[IANT].IDC, "VLBANL\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -130872.2998;
    ant_prm[IANT].XYZ[1] =    -4762317.1197;
    ant_prm[IANT].XYZ[2] =     4226851.0234;
    ant_prm[IANT].STAXOF =           2.1350;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -( 91.0 + 34.0/60.0 + 26.88/3600.0);
    ant_prm[IANT].LLH[1] =    41.0 + 46.0/60.0 + 17.13/3600.0;
    ant_prm[IANT].LLH[2] =   222.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.40;
        ant_prm[IANT].Trx[ns]  = 60.0;
        ant_prm[IANT].Tsky[ns] =110.0;
        ant_prm[IANT].Tsys[ns] =270.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBAFD", 6) == 0)) {

/** VLBA_FD **/
    sprintf(ant_prm[IANT].IDC, "VLBAFD\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -1324009.1646;
    ant_prm[IANT].XYZ[1] =    -5332181.9794;
    ant_prm[IANT].XYZ[2] =     3231962.4457;
    ant_prm[IANT].STAXOF =           2.1350;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -(103.0 + 56.0/60.0 + 41.34/3600.0);
    ant_prm[IANT].LLH[1] =    30.0 + 38.0/60.0 +  6.11/3600.0;
    ant_prm[IANT].LLH[2] =  1606.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.40;
        ant_prm[IANT].Trx[ns]  = 60.0;
        ant_prm[IANT].Tsky[ns] = 60.0;
        ant_prm[IANT].Tsys[ns] =120.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBALA", 6) == 0)) {

/** VLBA_LA **/
    sprintf(ant_prm[IANT].IDC, "VLBALA\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -1449752.4013;
    ant_prm[IANT].XYZ[1] =    -4975298.5896;
    ant_prm[IANT].XYZ[2] =     3709123.8941;
    ant_prm[IANT].STAXOF =           2.1370;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -(106.0 + 14.0/60.0 + 44.15/3600.0);
    ant_prm[IANT].LLH[1] =    35.0 + 46.0/60.0 + 30.45/3600.0;
    ant_prm[IANT].LLH[2] =  1962.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.40;
        ant_prm[IANT].Trx[ns]  = 60.0;
        ant_prm[IANT].Tsky[ns] =100.0;
        ant_prm[IANT].Tsys[ns] =160.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBAPT", 6) == 0)) {

/** VLBA_PT **/
    sprintf(ant_prm[IANT].IDC, "VLBAPT\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -1640953.7550;
    ant_prm[IANT].XYZ[1] =    -5014816.0357;
    ant_prm[IANT].XYZ[2] =     3575411.8474;
    ant_prm[IANT].STAXOF =           2.1390;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -(108.0 +  7.0/60.0 +  9.06/3600.0);
    ant_prm[IANT].LLH[1] =    34.0 + 18.0/60.0 +  3.61/3600.0;
    ant_prm[IANT].LLH[2] =  2365.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.40;
        ant_prm[IANT].Trx[ns]  = 60.0;
        ant_prm[IANT].Tsky[ns] = 40.0;
        ant_prm[IANT].Tsys[ns] =100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBAKP", 6) == 0)) {

/** VLBA_KP **/
    sprintf(ant_prm[IANT].IDC, "VLBAKP\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -1995678.6669;
    ant_prm[IANT].XYZ[1] =    -5037317.7126;
    ant_prm[IANT].XYZ[2] =     3357328.0908;
    ant_prm[IANT].STAXOF =           2.1370;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -(111.0 + 36.0/60.0 + 44.72/3600.0);
    ant_prm[IANT].LLH[1] =    31.0 + 57.0/60.0 + 22.70/3600.0;
    ant_prm[IANT].LLH[2] =  1902.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.40;
        ant_prm[IANT].Trx[ns]  = 60.0;
        ant_prm[IANT].Tsky[ns] = 50.0;
        ant_prm[IANT].Tsys[ns] =110.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBAOV", 6) == 0)) {

/** VLBA_OV **/
    sprintf(ant_prm[IANT].IDC, "VLBAOV\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -2409150.1662;
    ant_prm[IANT].XYZ[1] =    -4478573.2036;
    ant_prm[IANT].XYZ[2] =     3838617.3620;
    ant_prm[IANT].STAXOF =           2.1340;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -(118.0 + 16.0/60.0 + 37.37/3600.0);
    ant_prm[IANT].LLH[1] =    37.0 + 13.0/60.0 + 53.95/3600.0;
    ant_prm[IANT].LLH[2] =  1196.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.40;
        ant_prm[IANT].Trx[ns]  = 60.0;
        ant_prm[IANT].Tsky[ns] = 40.0;
        ant_prm[IANT].Tsys[ns] =100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBABR", 6) == 0)) {

/** VLBA_BR **/
    sprintf(ant_prm[IANT].IDC, "VLBABR\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -2112065.0152;
    ant_prm[IANT].XYZ[1] =    -3705356.5082;
    ant_prm[IANT].XYZ[2] =     4726813.7484;
    ant_prm[IANT].STAXOF =           2.1320;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -(119.0 + 40.0/60.0 + 59.80/3600.0);
    ant_prm[IANT].LLH[1] =    48.0 +  7.0/60.0 + 52.42/3600.0;
    ant_prm[IANT].LLH[2] =   250.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VLBA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLBAMK", 6) == 0)) {

/** VLBA_MK **/
    sprintf(ant_prm[IANT].IDC, "VLBAMK\0");
    ant_prm[IANT].ARRAY  =          VLBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -5464075.0109;
    ant_prm[IANT].XYZ[1] =    -2495248.8834;
    ant_prm[IANT].XYZ[2] =     2148296.9570;
    ant_prm[IANT].STAXOF =           2.1370;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -(155.0 + 27.0/60.0 + 19.81/3600.0);
    ant_prm[IANT].LLH[1] =    19.0 + 48.0/60.0 +  4.97/3600.0;
    ant_prm[IANT].LLH[2] =  3763.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.5 * DPI;
    ant_prm[IANT].ELSA    =  0.5 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 32.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.40;
        ant_prm[IANT].Trx[ns]  = 60.0;
        ant_prm[IANT].Tsky[ns] = 40.0;
        ant_prm[IANT].Tsys[ns] =100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

/*
---- HSA: GBT -------------------------------------------
*/

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == HSA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "GBT", 3) == 0)) {

    sprintf(ant_prm[IANT].IDC, "GBT\0");
    ant_prm[IANT].ARRAY  =           HSA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =           0.0000;
    ant_prm[IANT].XYZ[1] =           0.0000;
    ant_prm[IANT].XYZ[2] =           0.0000;
    ant_prm[IANT].STAXOF =           0.0000;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -( 79.0 + 50.0/60.0 + 23.406/3600.0) * DPI;
    ant_prm[IANT].LLH[1] =  ( 38.0 + 25.0/60.0 + 59.236/3600.0) * DPI;
    ant_prm[IANT].LLH[2] =   807.43;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] = -( 79.0 + 50.0/60.0 + 23.406/3600.0);
    ant_prm[IANT].LLH[1] =    38.0 + 25.0/60.0 + 59.236/3600.0;
    ant_prm[IANT].LLH[2] =   807.43;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  35.2 / 60.0 * DPI;
    ant_prm[IANT].ELSV    =  17.6 / 60.0 * DPI;
    ant_prm[IANT].AZSA    =  0.25        * DPI;
    ant_prm[IANT].ELSA    =  0.13        * DPI;
    ant_prm[IANT].ELLIM   = 10.0         * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 100.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  6.0;
        ant_prm[IANT].Tsky[ns] = 14.0;
        ant_prm[IANT].Tsys[ns] = 20.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  = 10.0;
        ant_prm[IANT].Tsky[ns] = 12.0;
        ant_prm[IANT].Tsys[ns] = 22.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  5.0;
        ant_prm[IANT].Tsky[ns] = 13.0;
        ant_prm[IANT].Tsys[ns] = 18.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 13.0;
        ant_prm[IANT].Tsky[ns] = 14.8;
        ant_prm[IANT].Tsys[ns] = 27.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.67;
        ant_prm[IANT].Trx[ns]  = 14.0;
        ant_prm[IANT].Tsky[ns] = 16.0;
        ant_prm[IANT].Tsys[ns] = 30.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  = 21.0;
        ant_prm[IANT].Tsky[ns] = 14.2;
        ant_prm[IANT].Tsys[ns] = 35.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.43;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 45.3;
        ant_prm[IANT].Tsys[ns] =100.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

/*
---- HSA: VLA_Y27 ---------------------------------------
*/

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == HSA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "VLA_Y27", 3) == 0)) {

    sprintf(ant_prm[IANT].IDC, "VLA_Y27\0");
    ant_prm[IANT].ARRAY  =           HSA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =           0.0000;
    ant_prm[IANT].XYZ[1] =           0.0000;
    ant_prm[IANT].XYZ[2] =           0.0000;
    ant_prm[IANT].STAXOF =           0.0000;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -(107.0 + 37.0/60.0 +  5.910/3600.0) * DPI;
    ant_prm[IANT].LLH[1] =  ( 34.0 +  4.0/60.0 + 43.750/3600.0) * DPI;
    ant_prm[IANT].LLH[2] =  2115.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] = -(107.0 + 37.0/60.0 +  5.910/3600.0);
    ant_prm[IANT].LLH[1] =    34.0 +  4.0/60.0 + 43.750/3600.0;
    ant_prm[IANT].LLH[2] =  2115.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  35.2 / 60.0 * DPI;
    ant_prm[IANT].ELSV    =  17.6 / 60.0 * DPI;
    ant_prm[IANT].AZSA    =  0.50        * DPI;
    ant_prm[IANT].ELSA    =  0.25        * DPI;
    ant_prm[IANT].ELLIM   = 10.0         * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 100.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  6.0;
        ant_prm[IANT].Tsky[ns] = 14.0;
        ant_prm[IANT].Tsys[ns] = 20.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  = 10.0;
        ant_prm[IANT].Tsky[ns] = 12.0;
        ant_prm[IANT].Tsys[ns] = 22.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  5.0;
        ant_prm[IANT].Tsky[ns] = 13.0;
        ant_prm[IANT].Tsys[ns] = 18.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 13.0;
        ant_prm[IANT].Tsky[ns] = 14.8;
        ant_prm[IANT].Tsys[ns] = 27.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.67;
        ant_prm[IANT].Trx[ns]  = 14.0;
        ant_prm[IANT].Tsky[ns] = 16.0;
        ant_prm[IANT].Tsys[ns] = 30.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  = 21.0;
        ant_prm[IANT].Tsky[ns] = 14.2;
        ant_prm[IANT].Tsys[ns] = 35.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.43;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 45.3;
        ant_prm[IANT].Tsys[ns] =100.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

/*
---- HSA: ARECIBO ---------------------------------------
*/

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == HSA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "ARECIBO", 7) == 0)) {

    sprintf(ant_prm[IANT].IDC, "ARECIBO\0");
    ant_prm[IANT].ARRAY  =           HSA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =           0.0000;
    ant_prm[IANT].XYZ[1] =           0.0000;
    ant_prm[IANT].XYZ[2] =           0.0000;
    ant_prm[IANT].STAXOF =           0.0000;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] = -( 66.0 + 45.0/60.0 + 11.100/3600.0) * DPI;
    ant_prm[IANT].LLH[1] =  ( 18.0 + 20.0/60.0 + 36.600/3600.0) * DPI;
    ant_prm[IANT].LLH[2] =   497.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] = -( 66.0 + 45.0/60.0 + 11.100/3600.0);
    ant_prm[IANT].LLH[1] =    18.0 + 20.0/60.0 + 36.600/3600.0;
    ant_prm[IANT].LLH[2] =   497.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  35.2 / 60.0 * DPI;
    ant_prm[IANT].ELSV    =  17.6 / 60.0 * DPI;
    ant_prm[IANT].AZSA    =  0.50        * DPI;
    ant_prm[IANT].ELSA    =  0.25        * DPI;
    ant_prm[IANT].ELLIM   = 10.0         * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 100.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  6.0;
        ant_prm[IANT].Tsky[ns] = 14.0;
        ant_prm[IANT].Tsys[ns] = 20.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  = 10.0;
        ant_prm[IANT].Tsky[ns] = 12.0;
        ant_prm[IANT].Tsys[ns] = 22.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  5.0;
        ant_prm[IANT].Tsky[ns] = 13.0;
        ant_prm[IANT].Tsys[ns] = 18.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 13.0;
        ant_prm[IANT].Tsky[ns] = 14.8;
        ant_prm[IANT].Tsys[ns] = 27.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.67;
        ant_prm[IANT].Trx[ns]  = 14.0;
        ant_prm[IANT].Tsky[ns] = 16.0;
        ant_prm[IANT].Tsys[ns] = 30.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  = 21.0;
        ant_prm[IANT].Tsky[ns] = 14.2;
        ant_prm[IANT].Tsys[ns] = 35.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.43;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 45.3;
        ant_prm[IANT].Tsys[ns] =100.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

/*
---- EVN ------------------------------------------------
*/

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNJb-1", 7) == 0)) {

/** Jodorell Bank (UK) (Lovell) **/
    sprintf(ant_prm[IANT].IDC, "EVNJb-1\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     3822626.4970;
    ant_prm[IANT].XYZ[1] =     -154105.5889;
    ant_prm[IANT].XYZ[2] =     5086486.2618;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNJb-2", 7) == 0)) {

/** Jodorell Bank (UK) (Mk2) **/
    sprintf(ant_prm[IANT].IDC, "EVNJb-2\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     3822842.6600;
    ant_prm[IANT].XYZ[1] =     -153800.1300;
    ant_prm[IANT].XYZ[2] =     5086287.2200;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNCm", 5) == 0)) {

/** Cambridge (UK) **/
    sprintf(ant_prm[IANT].IDC, "EVNCm\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     3920354.8000;
    ant_prm[IANT].XYZ[1] =        2545.7000;
    ant_prm[IANT].XYZ[2] =     5014285.0000;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNWb", 5) == 0)) {

/** Westerbork (NL) **/
    sprintf(ant_prm[IANT].IDC, "EVNWb\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          EQUA;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     3828440.6400;
    ant_prm[IANT].XYZ[1] =      445226.0300;
    ant_prm[IANT].XYZ[2] =     5064923.0800;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNEb/Ef", 8) == 0)) {

/** Effersberg (D) **/
    sprintf(ant_prm[IANT].IDC, "EVNEb/Ef\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     4033947.4796;
    ant_prm[IANT].XYZ[1] =      486990.5252;
    ant_prm[IANT].XYZ[2] =     4900430.8024;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =     6.0 + 53.0/60.0 +  0.30/3600.0;
    ant_prm[IANT].LLH[1] =    50.0 + 31.0/60.0 + 30.00/3600.0;
    ant_prm[IANT].LLH[2] =   319.00;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 100.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNMc", 5) == 0)) {

/** Medicina (I) **/
    sprintf(ant_prm[IANT].IDC, "EVNMc\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     4461369.9883;
    ant_prm[IANT].XYZ[1] =      919596.8324;
    ant_prm[IANT].XYZ[2] =     4449559.1894;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNNt", 5) == 0)) {

/** Noto (I) **/
    sprintf(ant_prm[IANT].IDC, "EVNNt\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     4934563.1230;
    ant_prm[IANT].XYZ[1] =     1321201.2698;
    ant_prm[IANT].XYZ[2] =     3806484.4778;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNOn-85", 8) == 0)) {

/** Onsala (S) **/
    sprintf(ant_prm[IANT].IDC, "EVNOn-85\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     3370968.1810;
    ant_prm[IANT].XYZ[1] =      711464.9170;
    ant_prm[IANT].XYZ[2] =     5349664.1130;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNOn-60", 8) == 0)) {

/** Onsala (S) **/
    sprintf(ant_prm[IANT].IDC, "EVNOn-60\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     3370606.0322;
    ant_prm[IANT].XYZ[1] =      711917.4960;
    ant_prm[IANT].XYZ[2] =     5349830.7257;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNSh", 5) == 0)) {

/** Sheshan (Shanghai, CH) **/
    sprintf(ant_prm[IANT].IDC, "EVNSh\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -2831686.9201;
    ant_prm[IANT].XYZ[1] =     4675733.6809;
    ant_prm[IANT].XYZ[2] =     3275327.6821;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNUr", 5) == 0)) {

/** Nanshan (Urumqi, CH) **/
    sprintf(ant_prm[IANT].IDC, "EVNUr\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =      228310.7250;
    ant_prm[IANT].XYZ[1] =     4631922.8904;
    ant_prm[IANT].XYZ[2] =     4367064.0648;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNTr", 5) == 0)) {

/** Torunn (PL) **/
    sprintf(ant_prm[IANT].IDC, "EVNTr\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     3638558.0000;
    ant_prm[IANT].XYZ[1] =     1221967.0000;
    ant_prm[IANT].XYZ[2] =     5077041.0000;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNMh", 5) == 0)) {

/** Metsahovi (FI) **/
    sprintf(ant_prm[IANT].IDC, "EVNMh\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2892579.9681;
    ant_prm[IANT].XYZ[1] =     1311719.0699;
    ant_prm[IANT].XYZ[2] =     5512640.6897;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNYb", 5) == 0)) {

/** Yebes (E) **/
    sprintf(ant_prm[IANT].IDC, "EVNYb\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     4848780.2990;
    ant_prm[IANT].XYZ[1] =     -261702.0738;
    ant_prm[IANT].XYZ[2] =     4123035.7500;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNAr", 5) == 0)) {

/** Arecibo (USA) **/
    sprintf(ant_prm[IANT].IDC, "EVNAr\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2390486.9000;
    ant_prm[IANT].XYZ[1] =    -5564731.4400;
    ant_prm[IANT].XYZ[2] =     1994720.4500;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNHh", 5) == 0)) {

/** Hertebeesthhoek (SA) **/
    sprintf(ant_prm[IANT].IDC, "EVNHh\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     5085442.7827;
    ant_prm[IANT].XYZ[1] =     2668263.4870;
    ant_prm[IANT].XYZ[2] =    -2768697.0169;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == EVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "EVNWz", 5) == 0)) {

/** Wettzell (D) **/
    sprintf(ant_prm[IANT].IDC, "EVNWz\0");
    ant_prm[IANT].ARRAY  =           EVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     4075539.8938;
    ant_prm[IANT].XYZ[1] =      931735.2738;
    ant_prm[IANT].XYZ[2] =     4801629.3605;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

/**** TEMPORALLY SET VLBA PARAMETERS ****/
    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 26.0;
        ant_prm[IANT].Tsys[ns] = 35.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 33.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 41.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns] =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns] =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

/*
---------------------------------------------------------
*/

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VERA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VERAMZ", 6) == 0)) {

/** MIZUSAWA **/
    sprintf(ant_prm[IANT].IDC, "VERAMZ\0");
    ant_prm[IANT].ARRAY  =          VERA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =   -3857241.85520;
    ant_prm[IANT].XYZ[1] =    3108784.85090;
    ant_prm[IANT].XYZ[2] =    4003900.58580;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =  141.132555278;
    ant_prm[IANT].LLH[1] =   35.133535;
    ant_prm[IANT].LLH[2] =   75.7;
    ant_prm[IANT].OFS[0] =    0.0;
    ant_prm[IANT].OFS[1] =    0.0;
    ant_prm[IANT].OFS[2] =    0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 20.0;
      if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 480.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   = 0.71;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns]   = 240.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns]   =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns]   =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns] = 1.00;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 1.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VERA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VERAIR", 6) == 0)) {

/** IRIKI      **/
    sprintf(ant_prm[IANT].IDC, "VERAIR\0");
    ant_prm[IANT].ARRAY  =          VERA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =   -3521719.56830;  
    ant_prm[IANT].XYZ[1] =    4132174.75320;  
    ant_prm[IANT].XYZ[2] =    3336994.32590; 
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =  130.439886944;
    ant_prm[IANT].LLH[1] =   31.74789917;
    ant_prm[IANT].LLH[2] =  541.60;
    ant_prm[IANT].OFS[0] =    0.0;
    ant_prm[IANT].OFS[1] =    0.0;
    ant_prm[IANT].OFS[2] =    0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 20.0;
      if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns] = 0.63;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 480.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns] = 0.71;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 240.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns]   =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns]   =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns] = 1.00;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 1.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VERA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VERAOG", 6) == 0)) {

/** OGASAWARA  **/
    sprintf(ant_prm[IANT].IDC, "VERAOG\0");
    ant_prm[IANT].ARRAY  =          VERA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =   -4491068.89430;
    ant_prm[IANT].XYZ[1] =    3481544.82870;
    ant_prm[IANT].XYZ[2] =    2887399.62250;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =  142.216613611;
    ant_prm[IANT].LLH[1] =   27.091801944;
    ant_prm[IANT].LLH[2] =  223.00;
    ant_prm[IANT].OFS[0] =    0.0;
    ant_prm[IANT].OFS[1] =    0.0;
    ant_prm[IANT].OFS[2] =    0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 20.0;
      if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns] = 0.63;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 480.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns] = 0.71;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 240.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns]   =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns]   =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns] = 1.00;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 1.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == VERA ||
     (ARRAY_ID == -1 && strncmp(station_code, "VERAIS", 6) == 0)) {

/** ISHIGAKI   **/
    sprintf(ant_prm[IANT].IDC, "VERAIS\0");
    ant_prm[IANT].ARRAY  =          VERA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =   -3263994.64770;
    ant_prm[IANT].XYZ[1] =    4808056.35700;
    ant_prm[IANT].XYZ[2] =    2619949.39530;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =  124.17099389;
    ant_prm[IANT].LLH[1] =   24.41217611;
    ant_prm[IANT].LLH[2] =   38.50;
    ant_prm[IANT].OFS[0] =    0.0;
    ant_prm[IANT].OFS[1] =    0.0;
    ant_prm[IANT].OFS[2] =    0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 20.0;
      if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns] = 0.63;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 480.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns] = 0.71;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 240.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns]   =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns]   =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns] = 1.00;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 1.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == JNET ||
     (ARRAY_ID == -1 && strncmp(station_code, "KASHIM34", 8) == 0)) {

/** KASHIM34 **/
    sprintf(ant_prm[IANT].IDC, "KASHIM34\0");
    ant_prm[IANT].ARRAY  =          JNET;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =   -3997649.23600;
    ant_prm[IANT].XYZ[1] =    3276690.80710;
    ant_prm[IANT].XYZ[2] =    3724278.89240;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =          0.0;
    ant_prm[IANT].LLH[1] =          0.0;
    ant_prm[IANT].LLH[2] =          0.0;
    ant_prm[IANT].OFS[0] =          0.0;
    ant_prm[IANT].OFS[1] =          0.0;
    ant_prm[IANT].OFS[2] =          0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 34.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  20.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  20.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns] = 0.71;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  38.8;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns]   =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns]   =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns] = 1.00;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 1.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == JNET ||
     (ARRAY_ID == -1 && strncmp(station_code, "NRO45", 5) == 0)) {

/** NRO_45 **/
    sprintf(ant_prm[IANT].IDC, "NRO45\0");
    ant_prm[IANT].ARRAY  =          JNET;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =   -3871023.49;
    ant_prm[IANT].XYZ[1] =    3428106.80;
    ant_prm[IANT].XYZ[2] =    3724039.50;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =   138.0 + 28.0/60.0 + 27.4864/3600.0; /*Maruyama*/
    ant_prm[IANT].LLH[1] =    35.0 + 56.0/60.0 + 41.9522/3600.0; /*Maruyama*/
    ant_prm[IANT].LLH[2] = 1364.70;                              /*Maruyama*/
    ant_prm[IANT].OFS[0] =          0.0;
    ant_prm[IANT].OFS[1] =          0.0;
    ant_prm[IANT].OFS[2] =          0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 45.0;
      if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns]   =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.51;
        ant_prm[IANT].Trx[ns]  = 55.0;
        ant_prm[IANT].Tsky[ns] = 75.3;
        ant_prm[IANT].Tsys[ns]   =130.3;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns] = 1.00;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 1.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == JNET ||
     (ARRAY_ID == -1 && strncmp(station_code, "USUDA64", 7) == 0)) {

/** USUDA_64 **/
    sprintf(ant_prm[IANT].IDC, "USUDA64\0");
    ant_prm[IANT].ARRAY  =          JNET;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =   -3855355.50082;
    ant_prm[IANT].XYZ[1] =    3427427.52323;
    ant_prm[IANT].XYZ[2] =    3740971.23563;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =  138.21; /* Usuda*/
    ant_prm[IANT].LLH[1] =   36.07; /* Usuda*/
    ant_prm[IANT].LLH[2] = 1478.00; /* Usuda*/
    ant_prm[IANT].OFS[0] =          0.0;
    ant_prm[IANT].OFS[1] =          0.0;
    ant_prm[IANT].OFS[2] =          0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 64.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  20.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  20.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns] = 0.71;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 30.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 54.2;
        ant_prm[IANT].Tsys[ns]   =104.2;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns] = 1.00;
        ant_prm[IANT].Trx[ns] =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] = 1.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == KVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "KVNSEO", 6) == 0)) {

/** KVN_01 **/
    sprintf(ant_prm[IANT].IDC, "KVNSEO\0");
    ant_prm[IANT].ARRAY  =           KVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -3042590.4639;
    ant_prm[IANT].XYZ[1] =     4046014.1879;
    ant_prm[IANT].XYZ[2] =     3867250.9900;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]     =   25.0;
      if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.41;
        ant_prm[IANT].Trx[ns]  =   25.0;
        ant_prm[IANT].Tsky[ns] =    5.0;
        ant_prm[IANT].Tsys[ns]   =   30.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.71;
        ant_prm[IANT].Trx[ns]  =   25.0;
        ant_prm[IANT].Tsky[ns] =   15.0;
        ant_prm[IANT].Tsys[ns]   =   40.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.72;
        ant_prm[IANT].Trx[ns]  =   30.0;
        ant_prm[IANT].Tsky[ns] =   30.0;
        ant_prm[IANT].Tsys[ns]   =   60.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.74;
        ant_prm[IANT].Trx[ns]  =   50.0;
        ant_prm[IANT].Tsky[ns] =   80.0;
        ant_prm[IANT].Tsys[ns]   =  130.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == BAND03) {
        ant_prm[IANT].Ae[ns]   =    0.65;
        ant_prm[IANT].Trx[ns]  =  100.0;
        ant_prm[IANT].Tsky[ns] =  100.0;
        ant_prm[IANT].Tsys[ns]   =  200.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == BAND04) {
        ant_prm[IANT].Ae[ns]   =    0.45;
        ant_prm[IANT].Trx[ns]  =  150.0;
        ant_prm[IANT].Tsky[ns] =  150.0;
        ant_prm[IANT].Tsys[ns]   =  300.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else {
        ant_prm[IANT].Ae[ns]   =    0.00;
        ant_prm[IANT].Trx[ns]  =    0.0;
        ant_prm[IANT].Tsky[ns] =    0.0;
        ant_prm[IANT].Tsys[ns]   =    0.0;
        ant_prm[IANT].FLAG[ns] =    OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == KVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "KVNULS", 6) == 0)) {

/** KVN_02 **/
    sprintf(ant_prm[IANT].IDC, "KVNULS\0");
    ant_prm[IANT].ARRAY  =           KVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -3287572.5337;
    ant_prm[IANT].XYZ[1] =     4023628.5587;
    ant_prm[IANT].XYZ[2] =     3686850.4070;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]     =   25.0;
      if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.41;
        ant_prm[IANT].Trx[ns]  =   25.0;
        ant_prm[IANT].Tsky[ns] =    5.0;
        ant_prm[IANT].Tsys[ns]   =   30.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.71;
        ant_prm[IANT].Trx[ns]  =   25.0;
        ant_prm[IANT].Tsky[ns] =   15.0;
        ant_prm[IANT].Tsys[ns]   =   40.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.72;
        ant_prm[IANT].Trx[ns]  =   30.0;
        ant_prm[IANT].Tsky[ns] =   30.0;
        ant_prm[IANT].Tsys[ns]   =   60.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.74;
        ant_prm[IANT].Trx[ns]  =   50.0;
        ant_prm[IANT].Tsky[ns] =   80.0;
        ant_prm[IANT].Tsys[ns]   =  130.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == BAND03) {
        ant_prm[IANT].Ae[ns]   =    0.65;
        ant_prm[IANT].Trx[ns]  =  100.0;
        ant_prm[IANT].Tsky[ns] =  100.0;
        ant_prm[IANT].Tsys[ns]   =  200.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == BAND04) {
        ant_prm[IANT].Ae[ns]   =    0.45;
        ant_prm[IANT].Trx[ns]  =  150.0;
        ant_prm[IANT].Tsky[ns] =  150.0;
        ant_prm[IANT].Tsys[ns]   =  300.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else {
        ant_prm[IANT].Ae[ns]   =    0.00;
        ant_prm[IANT].Trx[ns]  =    0.0;
        ant_prm[IANT].Tsky[ns] =    0.0;
        ant_prm[IANT].Tsys[ns]   =    0.0;
        ant_prm[IANT].FLAG[ns] =    OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == KVN  ||
     (ARRAY_ID == -1 && strncmp(station_code, "KVNJEJ", 6) == 0)) {

/** KVN_03 **/
    sprintf(ant_prm[IANT].IDC, "KVNJEJ\0");
    ant_prm[IANT].ARRAY  =           KVN;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -3171853.3889;
    ant_prm[IANT].XYZ[1] =     4292473.5347;
    ant_prm[IANT].XYZ[2] =     3480958.6539;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]     =   25.0;
      if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.41;
        ant_prm[IANT].Trx[ns]  =   25.0;
        ant_prm[IANT].Tsky[ns] =    5.0;
        ant_prm[IANT].Tsys[ns]   =   30.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.71;
        ant_prm[IANT].Trx[ns]  =   25.0;
        ant_prm[IANT].Tsky[ns] =   15.0;
        ant_prm[IANT].Tsys[ns]   =   40.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.72;
        ant_prm[IANT].Trx[ns]  =   30.0;
        ant_prm[IANT].Tsky[ns] =   30.0;
        ant_prm[IANT].Tsys[ns]   =   60.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == Q_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.74;
        ant_prm[IANT].Trx[ns]  =   50.0;
        ant_prm[IANT].Tsky[ns] =   80.0;
        ant_prm[IANT].Tsys[ns]   =  130.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == BAND03) {
        ant_prm[IANT].Ae[ns]   =    0.65;
        ant_prm[IANT].Trx[ns]  =  100.0;
        ant_prm[IANT].Tsky[ns] =  100.0;
        ant_prm[IANT].Tsys[ns]   =  200.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else if (wave_id[ns] == BAND04) {
        ant_prm[IANT].Ae[ns]   =    0.45;
        ant_prm[IANT].Trx[ns]  =  150.0;
        ant_prm[IANT].Tsky[ns] =  150.0;
        ant_prm[IANT].Tsys[ns]   =  300.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else {
        ant_prm[IANT].Ae[ns]   =    0.00;
        ant_prm[IANT].Trx[ns]  =    0.0;
        ant_prm[IANT].Tsky[ns] =    0.0;
        ant_prm[IANT].Tsys[ns]   =    0.0;
        ant_prm[IANT].FLAG[ns] =    OFF;
      }
    }
    IANT++;
  }

/** TAEDUK **/

  if (ARRAY_ID == ALL_ANT ||
     (ARRAY_ID == -1 && strncmp(station_code, "TAEDUK", 6) == 0)) {

    sprintf(ant_prm[IANT].IDC, "TAEDUK\0");
    ant_prm[IANT].ARRAY  =   STAND_ALONE;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =    -3119892.9000;
    ant_prm[IANT].XYZ[1] =     4084793.6895;
    ant_prm[IANT].XYZ[2] =     3763951.4085;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].LLH[0] =           0.0;
    ant_prm[IANT].LLH[1] =           0.0;
    ant_prm[IANT].LLH[2] =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 25.0;
      if (wave_id[ns] == W_BAND) {
        ant_prm[IANT].Ae[ns]   =    0.37;
        ant_prm[IANT].Trx[ns]  =  150.0;
        ant_prm[IANT].Tsky[ns] =  150.0;
        ant_prm[IANT].Tsys[ns]   =  300.0;
        ant_prm[IANT].FLAG[ns] =     ON;
      } else {
        ant_prm[IANT].Ae[ns]   =    0.00;
        ant_prm[IANT].Trx[ns]  =    0.0;
        ant_prm[IANT].Tsky[ns] =    0.0;
        ant_prm[IANT].Tsys[ns]   =    0.00;
        ant_prm[IANT].FLAG[ns] =    OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == LBA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "LBANAR", 6) == 0)) {

/** Narrabri **/
    sprintf(ant_prm[IANT].IDC, "LBANAR\0");
    ant_prm[IANT].ARRAY  =           LBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2607848.5623;
    ant_prm[IANT].XYZ[1] =    -5488069.6592;
    ant_prm[IANT].XYZ[2] =     1932739.5672;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] =   149.57 * DPI;
    ant_prm[IANT].LLH[1] =   -30.31 * DPI;
    ant_prm[IANT].LLH[2] =   217.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] =   149.57;
    ant_prm[IANT].LLH[1] =   -30.31;
    ant_prm[IANT].LLH[2] =   217.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  0.7 * DPI;
    ant_prm[IANT].ELSV    =  0.3 * DPI;
    ant_prm[IANT].AZSA    =  0.7 * DPI;
    ant_prm[IANT].ELSA    =  0.3 * DPI;
    ant_prm[IANT].ELLIM   = 12.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 22.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 23.0;
        ant_prm[IANT].Tsys[ns] = 32.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 37.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 21.0;
        ant_prm[IANT].Tsys[ns] = 33.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  =102.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] =120.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 20.0;
        ant_prm[IANT].Tsky[ns] = 20.0;
        ant_prm[IANT].Tsys[ns] = 40.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == LBA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "LBAMOP", 6) == 0)) {

/** Mopra    **/
    sprintf(ant_prm[IANT].IDC, "LBAMOP\0");
    ant_prm[IANT].ARRAY  =           LBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2607848.5623;
    ant_prm[IANT].XYZ[1] =    -5488069.6592;
    ant_prm[IANT].XYZ[2] =     1932739.5672;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] =   149.07 * DPI;
    ant_prm[IANT].LLH[1] =   -31.30 * DPI;
    ant_prm[IANT].LLH[2] =   840.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] =   149.07;
    ant_prm[IANT].LLH[1] =   -31.30;
    ant_prm[IANT].LLH[2] =   840.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  0.6 * DPI;
    ant_prm[IANT].ELSV    =  0.3 * DPI;
    ant_prm[IANT].AZSA    =  0.6 * DPI;
    ant_prm[IANT].ELSA    =  0.3 * DPI;
    ant_prm[IANT].ELLIM   = 12.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 22.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 23.0;
        ant_prm[IANT].Tsys[ns] = 32.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  8.0;
        ant_prm[IANT].Tsky[ns] = 29.0;
        ant_prm[IANT].Tsys[ns] = 37.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 12.0;
        ant_prm[IANT].Tsky[ns] = 21.0;
        ant_prm[IANT].Tsys[ns] = 33.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 18.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 38.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  =102.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] =120.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 60.0;
        ant_prm[IANT].Tsky[ns] = 20.0;
        ant_prm[IANT].Tsys[ns] = 80.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == LBA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "LBAPKS", 6) == 0)) {

/** Parkes   **/
    sprintf(ant_prm[IANT].IDC, "LBAPKS\0");
    ant_prm[IANT].ARRAY  =           LBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2607848.5623;
    ant_prm[IANT].XYZ[1] =    -5488069.6592;
    ant_prm[IANT].XYZ[2] =     1932739.5672;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] =   148.26 * DPI;
    ant_prm[IANT].LLH[1] =   -33.00 * DPI;
    ant_prm[IANT].LLH[2] =   392.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] =   148.26;
    ant_prm[IANT].LLH[1] =   -33.00;
    ant_prm[IANT].LLH[2] =   392.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  0.4 * DPI;
    ant_prm[IANT].ELSV    =  0.2 * DPI;
    ant_prm[IANT].AZSA    =  0.4 * DPI;
    ant_prm[IANT].ELSA    =  0.2 * DPI;
    ant_prm[IANT].ELLIM   = 30.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 64.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  9.0;
        ant_prm[IANT].Tsky[ns] = 19.0;
        ant_prm[IANT].Tsys[ns] = 28.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  5.0;
        ant_prm[IANT].Tsky[ns] = 15.0;
        ant_prm[IANT].Tsys[ns] = 20.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 29.0;
        ant_prm[IANT].Tsky[ns] = 21.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  =  5.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 25.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 87.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] =105.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  =120.0;
        ant_prm[IANT].Tsky[ns] = 20.0;
        ant_prm[IANT].Tsys[ns] =140.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == LBA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "LBATID", 6) == 0)) {

/** Tidbinbilla : DSS43 **/
    sprintf(ant_prm[IANT].IDC, "LBATID\0");
    ant_prm[IANT].ARRAY  =           LBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2607848.5623;
    ant_prm[IANT].XYZ[1] =    -5488069.6592;
    ant_prm[IANT].XYZ[2] =     1932739.5672;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] =   148.98 * DPI;
    ant_prm[IANT].LLH[1] =   -35.40 * DPI;
    ant_prm[IANT].LLH[2] =   670.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] =   148.98;
    ant_prm[IANT].LLH[1] =   -35.40;
    ant_prm[IANT].LLH[2] =   670.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  0.2 * DPI;
    ant_prm[IANT].ELSV    =  0.2 * DPI;
    ant_prm[IANT].AZSA    =  0.2 * DPI;
    ant_prm[IANT].ELSA    =  0.2 * DPI;
    ant_prm[IANT].ELLIM   =  6.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 70.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  =  6.0;
        ant_prm[IANT].Tsky[ns] = 19.0;
        ant_prm[IANT].Tsys[ns] = 25.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  =  5.0;
        ant_prm[IANT].Tsky[ns] = 11.0;
        ant_prm[IANT].Tsys[ns] = 16.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  =  5.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 25.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  = 20.0;
        ant_prm[IANT].Tsky[ns] = 20.0;
        ant_prm[IANT].Tsys[ns] = 40.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == LBA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "LBAHBT", 6) == 0)) {

/** Hobart  **/
    sprintf(ant_prm[IANT].IDC, "LBAHBT\0");
    ant_prm[IANT].ARRAY  =           LBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2607848.5623;
    ant_prm[IANT].XYZ[1] =    -5488069.6592;
    ant_prm[IANT].XYZ[2] =     1932739.5672;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] =   147.44 * DPI;
    ant_prm[IANT].LLH[1] =   -42.80 * DPI;
    ant_prm[IANT].LLH[2] =   100.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] =   147.44;
    ant_prm[IANT].LLH[1] =   -42.80;
    ant_prm[IANT].LLH[2] =   100.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  0.7 * DPI;
    ant_prm[IANT].ELSV    =  0.7 * DPI;
    ant_prm[IANT].AZSA    =  0.7 * DPI;
    ant_prm[IANT].ELSA    =  0.7 * DPI;
    ant_prm[IANT].ELLIM   = 16.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 26.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  = 23.0;
        ant_prm[IANT].Tsky[ns] = 19.0;
        ant_prm[IANT].Tsys[ns] = 42.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 15.0;
        ant_prm[IANT].Tsys[ns] = 65.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 44.0;
        ant_prm[IANT].Tsky[ns] = 21.0;
        ant_prm[IANT].Tsys[ns] = 65.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 36.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 56.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  =102.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] =120.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  =160.0;
        ant_prm[IANT].Tsky[ns] = 20.0;
        ant_prm[IANT].Tsys[ns] =180.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == LBA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "LBACED", 6) == 0)) {

/** Ceduna  **/
    sprintf(ant_prm[IANT].IDC, "LBACED\0");
    ant_prm[IANT].ARRAY  =           LBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2607848.5623;
    ant_prm[IANT].XYZ[1] =    -5488069.6592;
    ant_prm[IANT].XYZ[2] =     1932739.5672;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] =   133.81 * DPI;
    ant_prm[IANT].LLH[1] =   -31.87 * DPI;
    ant_prm[IANT].LLH[2] =   160.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] =   133.81;
    ant_prm[IANT].LLH[1] =   -31.87;
    ant_prm[IANT].LLH[2] =   160.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  0.7 * DPI;
    ant_prm[IANT].ELSV    =  0.7 * DPI;
    ant_prm[IANT].AZSA    =  0.7 * DPI;
    ant_prm[IANT].ELSA    =  0.7 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 30.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  = 23.0;
        ant_prm[IANT].Tsky[ns] = 19.0;
        ant_prm[IANT].Tsys[ns] = 42.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  = 50.0;
        ant_prm[IANT].Tsky[ns] = 15.0;
        ant_prm[IANT].Tsys[ns] = 65.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 44.0;
        ant_prm[IANT].Tsky[ns] = 21.0;
        ant_prm[IANT].Tsys[ns] = 65.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 36.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 56.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  =102.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] =120.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KA_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.66;
        ant_prm[IANT].Trx[ns]  =160.0;
        ant_prm[IANT].Tsky[ns] = 20.0;
        ant_prm[IANT].Tsys[ns] =180.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

  if (ARRAY_ID == ALL_ANT || ARRAY_ID == LBA  ||
     (ARRAY_ID == -1 && strncmp(station_code, "HARTRO", 6) == 0)) {

/** Hartebeesthoek  **/
    sprintf(ant_prm[IANT].IDC, "HARTRO\0");
    ant_prm[IANT].ARRAY  =           LBA;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].XYZ[0] =     2607848.5623;
    ant_prm[IANT].XYZ[1] =    -5488069.6592;
    ant_prm[IANT].XYZ[2] =     1932739.5672;
    ant_prm[IANT].STAXOF =           0.0;
    ant_prm[IANT].OFS[0] =           0.0;
    ant_prm[IANT].OFS[1] =           0.0;
    ant_prm[IANT].OFS[2] =           0.0;
    ant_prm[IANT].LLH[0] =    27.67 * DPI;
    ant_prm[IANT].LLH[1] =   -25.89 * DPI;
    ant_prm[IANT].LLH[2] =  1391.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] =    27.67;
    ant_prm[IANT].LLH[1] =   -25.89;
    ant_prm[IANT].LLH[2] =  1391.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  0.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  0.071 * DPI;
    ant_prm[IANT].ELSA    =  0.071 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   = 10.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]   = 30.0;
      if (wave_id[ns] == L_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.63;
        ant_prm[IANT].Trx[ns]  = 20.0;
        ant_prm[IANT].Tsky[ns] = 19.0;
        ant_prm[IANT].Tsys[ns] = 39.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == S_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.70;
        ant_prm[IANT].Trx[ns]  = 29.0;
        ant_prm[IANT].Tsky[ns] = 15.0;
        ant_prm[IANT].Tsys[ns] = 44.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == C_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.72;
        ant_prm[IANT].Trx[ns]  = 29.0;
        ant_prm[IANT].Tsky[ns] = 21.0;
        ant_prm[IANT].Tsys[ns] = 50.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == X_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.71;
        ant_prm[IANT].Trx[ns]  = 40.0;
        ant_prm[IANT].Tsky[ns] = 20.8;
        ant_prm[IANT].Tsys[ns] = 60.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == KU_BAND) {
        ant_prm[IANT].Ae[ns]   =  0.69;
        ant_prm[IANT].Trx[ns]  = 77.0;
        ant_prm[IANT].Tsky[ns] = 18.0;
        ant_prm[IANT].Tsys[ns] = 95.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns] =  0.0;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }
    IANT++;
  }

/*
----------------------------------------------------
*/

  if (ARRAY_ID == ALL_ANT ||
     (ARRAY_ID == -1 && strncmp(station_code, "SEST", 4) == 0)) {

    sprintf(ant_prm[IANT].IDC, "SEST\0");
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].ARRAY  =   STAND_ALONE;
    ant_prm[IANT].STAXOF =     0.0;
    ant_prm[IANT].LLH[0] = -( 70.0 + 44.0/60.0 + 04.000/3600.0) * DPI;
    ant_prm[IANT].LLH[1] = -( 29.0 + 15.0/60.0 + 34.000/3600.0) * DPI;
    ant_prm[IANT].LLH[2] =  2300.00;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] = -( 70.0 + 44.0/60.0 + 04.000/3600.0);
    ant_prm[IANT].LLH[1] = -( 29.0 + 15.0/60.0 + 34.000/3600.0);
    ant_prm[IANT].LLH[2] =  2300.00;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt  =  2.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]  = 15.0;
      if (wave_id[ns] == BAND01) {
        ant_prm[IANT].Ae[ns]   =   0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns]   = 100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND02) {
        ant_prm[IANT].Ae[ns]   =   0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns]   = 100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND03) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND04) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND05) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND06) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND07) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND08) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND09) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND10) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns]   =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }

    ant_prm[IANT].OFS[0] =    0.0;
    ant_prm[IANT].OFS[1] =    0.0;
    ant_prm[IANT].OFS[2] =    0.0;

    IANT++;
  }

/*
----------------------------------------------------
*/

  if (ARRAY_ID == ALL_ANT ||
     (ARRAY_ID == -1 && strncmp(station_code, "ALMA", 4) == 0)) {

    sprintf(ant_prm[IANT].IDC, "ALMA\0");
    ant_prm[IANT].UFL    =            ON;
    ant_prm[IANT].MNTSTA =          ALAZ;
    ant_prm[IANT].ARRAY  =   STAND_ALONE;
    ant_prm[IANT].STAXOF =     0.0;
    ant_prm[IANT].LLH[0] =   -67.827315 * DPI;
    ant_prm[IANT].LLH[1] =   -22.943973 * DPI;
    ant_prm[IANT].LLH[2] =  5000.0;
    J_system_geocentric_equatorial_rectangular_coordinate(
         ant_prm[IANT].LLH[0], ant_prm[IANT].LLH[1], ant_prm[IANT].LLH[2],
         ant_prm[IANT].XYZ);
#ifdef __DEBUG_LLH__
    printf("%lf  %lf  %lf\n",
            ant_prm[IANT].XYZ[0], ant_prm[IANT].XYZ[1], ant_prm[IANT].XYZ[2]);
#endif /*__DEBUG_LLH__*/
    ant_prm[IANT].LLH[0] =   -67.827315;
    ant_prm[IANT].LLH[1] =   -22.943973;
    ant_prm[IANT].LLH[2] =  5000.0;
    if (ERR_RESET_SWT == ON) {
      ant_prm[IANT].ERR[0] =  ant_prm[IANT].XYZ[0];
      ant_prm[IANT].ERR[1] =  ant_prm[IANT].XYZ[1];
      ant_prm[IANT].ERR[2] =  ant_prm[IANT].XYZ[2];
    }

    ant_prm[IANT].AZSV    =  1.5 * DPI;
    ant_prm[IANT].ELSV    =  0.5 * DPI;
    ant_prm[IANT].AZSA    =  1.0 * DPI;
    ant_prm[IANT].ELSA    =  1.0 * DPI;
    ant_prm[IANT].ELLIM   = 10.0 * DPI;
    ant_prm[IANT].FQSST   = 10.0;
    ant_prm[IANT].slewt   =  2.0;

    for (ns=0; ns<SRC_NUM; ns++) {
      ant_prm[IANT].Dm[ns]  =  7.0;
      if (wave_id[ns] == BAND01) {
        ant_prm[IANT].Ae[ns]   =   0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns]   = 100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND02) {
        ant_prm[IANT].Ae[ns]   =   0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns]   = 100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND03) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND04) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND05) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND06) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND07) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND08) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND09) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else if (wave_id[ns] == BAND10) {
        ant_prm[IANT].Ae[ns] = 0.80;
        ant_prm[IANT].Trx[ns]  =   0.0;
        ant_prm[IANT].Tsky[ns] =   0.0;
        ant_prm[IANT].Tsys[ns] =  100.0;
        ant_prm[IANT].FLAG[ns] = ON;
      } else {
        ant_prm[IANT].Ae[ns]   =  0.00;
        ant_prm[IANT].Trx[ns]  =  0.0;
        ant_prm[IANT].Tsky[ns] =  0.0;
        ant_prm[IANT].Tsys[ns]   =  0.00;
        ant_prm[IANT].FLAG[ns] = OFF;
      }
    }

    ant_prm[IANT].OFS[0] =    0.0;
    ant_prm[IANT].OFS[1] =    0.0;
    ant_prm[IANT].OFS[2] =    0.0;

    IANT++;
  }

/*
----------------------------------------------------
*/

  if (ARRAY_ID == ACA) {

    ANT_NUM     = 3;
    *GRT_NUM    = 3;

    for (iant=0; iant<*GRT_NUM; iant++) {
      if (iant+1 < 10) {
        sprintf(ant_prm[iant].IDC, "ACA0%1d", iant+1);
      } else {
        sprintf(ant_prm[iant].IDC, "ACA%2d",  iant+1);
      }
      ant_prm[iant].UFL    =            ON;
      ant_prm[iant].MNTSTA =          ALAZ;
      ant_prm[iant].ARRAY  =           ACA;
      ant_prm[iant].STAXOF =     0.0;
      ant_prm[iant].LLH[0] =   -67.827315;
      ant_prm[iant].LLH[1] =   -22.943973;
      ant_prm[iant].LLH[2] =  5000.0;
      if (ERR_RESET_SWT == ON) {
        ant_prm[iant].ERR[0] =  ant_prm[iant].XYZ[0];
        ant_prm[iant].ERR[1] =  ant_prm[iant].XYZ[1];
        ant_prm[iant].ERR[2] =  ant_prm[iant].XYZ[2];
      }

      ant_prm[iant].AZSV    =  1.5 * DPI;
      ant_prm[iant].ELSV    =  0.5 * DPI;
      ant_prm[iant].AZSA    =  1.0 * DPI;
      ant_prm[iant].ELSA    =  1.0 * DPI;
      ant_prm[iant].ELLIM   = 10.0 * DPI;
      ant_prm[IANT].FQSST   = 10.0;
      ant_prm[iant].slewt   =  2.0;

      for (ns=0; ns<SRC_NUM; ns++) {
        ant_prm[iant].Dm[ns]  =  7.0;
        if (wave_id[ns] == BAND01) {
          ant_prm[iant].Ae[ns]   =   0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns]   = 100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else if (wave_id[ns] == BAND02) {
          ant_prm[iant].Ae[ns]   =   0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns]   = 100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else if (wave_id[ns] == BAND03) {
          ant_prm[iant].Ae[ns] = 0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns] =  100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else if (wave_id[ns] == BAND04) {
          ant_prm[iant].Ae[ns] = 0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns] =  100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else if (wave_id[ns] == BAND05) {
          ant_prm[iant].Ae[ns] = 0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns] =  100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else if (wave_id[ns] == BAND06) {
          ant_prm[iant].Ae[ns] = 0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns] =  100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else if (wave_id[ns] == BAND07) {
          ant_prm[iant].Ae[ns] = 0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns] =  100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else if (wave_id[ns] == BAND08) {
          ant_prm[iant].Ae[ns] = 0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns] =  100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else if (wave_id[ns] == BAND09) {
          ant_prm[iant].Ae[ns] = 0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns] =  100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else if (wave_id[ns] == BAND10) {
          ant_prm[iant].Ae[ns] = 0.80;
          ant_prm[iant].Trx[ns]  =   0.0;
          ant_prm[iant].Tsky[ns] =   0.0;
          ant_prm[iant].Tsys[ns] =  100.0;
          ant_prm[iant].FLAG[ns] = ON;
        } else {
          ant_prm[iant].Ae[ns]   =  0.00;
          ant_prm[iant].Trx[ns]  =  0.0;
          ant_prm[iant].Tsky[ns] =  0.0;
          ant_prm[iant].Tsys[ns]   =  0.00;
          ant_prm[iant].FLAG[ns] = OFF;
        }
      }
    }

    ant_prm[0].OFS[0] =    0.0;
    ant_prm[0].OFS[1] =    0.0;
    ant_prm[0].OFS[2] =    0.0;

    ant_prm[1].OFS[0] =    7.0 * 1.25;
    ant_prm[1].OFS[1] =    0.0;
    ant_prm[1].OFS[2] =    0.0;

    ant_prm[2].OFS[0] =   30.0;
    ant_prm[2].OFS[1] =    0.0;
    ant_prm[2].OFS[2] =    0.0;

  } else if (ARRAY_ID != ACA) {
    ANT_NUM  = IANT;
    *GRT_NUM = IANT;
  }

/*
----------------------------------------------------
*/

  for (iant=0; iant<*GRT_NUM; iant++) {
    ant_prm[iant].LLH[0] *= DPI;
    ant_prm[iant].LLH[1] *= DPI;
  }

  for (iant=0; iant<*GRT_NUM; iant++) {
#ifdef __DEBUG_LLH__
    printf("__DEBUG_LLH__[A]  %d  %lf  %lf  %lf\n", iant,
                                        ant_prm[iant].LLH[0] / DPI,
                                        ant_prm[iant].LLH[1] / DPI,
                                        ant_prm[iant].LLH[2]);
#endif /*__DEBUG_LLH__*/

    J_system_geocentric_equatorial_rectangular_coordinate2llh(
        &ant_prm[iant].LLH[0], &ant_prm[iant].LLH[1], &ant_prm[iant].LLH[2],
        ant_prm[iant].XYZ);

#ifdef __DEBUG_LLH__
    printf("__DEBUG_LLH__[B]  %d  %lf  %lf  %lf\n", iant,
                                         ant_prm[iant].LLH[0] / DPI,
                                         ant_prm[iant].LLH[1] / DPI,
                                         ant_prm[iant].LLH[2]);
    if (iant % 10 == 9) {
      getchar();
    }
#endif /*__DEBUG_LLH__*/
  }

  if (ARRAY_ID == ACA) {
    for (iant=0; iant<*GRT_NUM; iant++) {
      J_system_geocentric_equatorial_rectangular_coordinate(
          ant_prm[iant].LLH[0], ant_prm[iant].LLH[1], ant_prm[iant].LLH[2],
          ant_prm[iant].XYZ);
      x[0] = ant_prm[iant].OFS[0];
      x[1] = ant_prm[iant].OFS[1];
      x[2] = ant_prm[iant].OFS[2];
      drotate(x, dpi/2.0-ant_prm[iant].LLH[1], "x");
      drotate(x, dpi/2.0+ant_prm[iant].LLH[1], "z");
      ant_prm[iant].XYZ[0] += x[0];
      ant_prm[iant].XYZ[1] += x[1];
      ant_prm[iant].XYZ[2] += x[2];
    }
  }

/*
----------------------------------------------------
*/

  if (SRT_NUM >= 1) {
    for (iant=0; iant<SRT_NUM; iant++) {
      if (SRT_NUM == 1) {
        sprintf(ant_prm[ANT_NUM].IDC, "SRT\0",      iant+1);
      } else {
        if (iant+1 < 10) {
          sprintf(ant_prm[ANT_NUM].IDC, "SRT_0%1d\0", iant+1);
        } else if (iant+1 >= 10 && iant+1 < 100) {
          sprintf(ant_prm[ANT_NUM].IDC, "SRT_%2d\0",  iant+1);
        }
      }
      ant_prm[ANT_NUM].ARRAY  =    INDIVIDUAL;
      ant_prm[ANT_NUM].MNTSTA =          ORBI;
      ant_prm[ANT_NUM].UFL    =            ON;
      ant_prm[ANT_NUM].LLH[0] = 0.0;
      ant_prm[ANT_NUM].LLH[1] = 0.0;
      ant_prm[ANT_NUM].LLH[2] = 0.0;
      ant_prm[ANT_NUM].OFS[0] = 0.0;
      ant_prm[ANT_NUM].OFS[1] = 0.0;
      ant_prm[ANT_NUM].OFS[2] = 0.0;
      if (ERR_RESET_SWT == ON) {
        ant_prm[ANT_NUM].ERR[0] =  ant_prm[IANT].XYZ[0];
        ant_prm[ANT_NUM].ERR[1] =  ant_prm[IANT].XYZ[1];
        ant_prm[ANT_NUM].ERR[2] =  ant_prm[IANT].XYZ[2];
      }

      ant_prm[ANT_NUM].AZSV    =  1.5 * DPI;
      ant_prm[ANT_NUM].ELSV    =  0.5 * DPI;
      ant_prm[ANT_NUM].AZSA    =  1.0 * DPI;
      ant_prm[ANT_NUM].ELSA    =  1.0 * DPI;
      ant_prm[ANT_NUM].ELLIM   = 10.0 * DPI;
      ant_prm[ANT_NUM].FQSST   = 10.0;
      ant_prm[ANT_NUM].slewt   = 10.0;

/********
      for (ns=0; ns<SRC_NUM; ns++) {
        ant_prm[ANT_NUM].Dm[ns]   =  8.64;
        if (wave_id[ns] == L_BAND) {
          ant_prm[ANT_NUM].Ae[ns]   =  0.40;
          ant_prm[ANT_NUM].Trx[ns]  = 75.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 75.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == C_BAND) {
          ant_prm[ANT_NUM].Ae[ns]   =  0.40;
          ant_prm[ANT_NUM].Trx[ns]  = 94.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 94.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == X_BAND) {
          ant_prm[ANT_NUM].Ae[ns]   =  0.60;
          ant_prm[ANT_NUM].Trx[ns]  = 60.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 60.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == KA_BAND) {
          ant_prm[ANT_NUM].Ae[ns]   =  0.60;
          ant_prm[ANT_NUM].Trx[ns]  = 30.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 30.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == Q_BAND) {
          ant_prm[ANT_NUM].Ae[ns]   =  0.50;
          ant_prm[ANT_NUM].Trx[ns]  = 40.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 40.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else {
          ant_prm[ANT_NUM].Ae[ns]   =  1.00;
          ant_prm[ANT_NUM].Trx[ns]  =  0.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns]   =  1.00;
          ant_prm[ANT_NUM].FLAG[ns] = OFF;
        }
      }
********/
/********
      for (ns=0; ns<SRC_NUM; ns++) {
        if (wave_id[ns] == L_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  8.63;
          ant_prm[ANT_NUM].Ae[ns]   =  0.40;
          ant_prm[ANT_NUM].Trx[ns]  = 75.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 75.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == C_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  8.63;
          ant_prm[ANT_NUM].Ae[ns]   =  0.40;
          ant_prm[ANT_NUM].Trx[ns]  = 94.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 94.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == X_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  9.30;
          ant_prm[ANT_NUM].Ae[ns]   =  0.60;
          ant_prm[ANT_NUM].Trx[ns]  = 90.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 90.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == KA_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  9.30;
          ant_prm[ANT_NUM].Ae[ns]   =  0.59;
          ant_prm[ANT_NUM].Trx[ns]  = 52.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 52.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == Q_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  9.30;
          ant_prm[ANT_NUM].Ae[ns]   =  0.35;
          ant_prm[ANT_NUM].Trx[ns]  = 65.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns] = 65.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else {
          ant_prm[ANT_NUM].Dm[ns]   =  1.00;
          ant_prm[ANT_NUM].Ae[ns]   =  1.00;
          ant_prm[ANT_NUM].Trx[ns]  =  0.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns]   =  1.00;
          ant_prm[ANT_NUM].FLAG[ns] = OFF;
        }
      }
********/
/********
      for (ns=0; ns<SRC_NUM; ns++) {
        if (wave_id[ns] == L_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  8.63;
          ant_prm[ANT_NUM].Ae[ns]   =  0.40;
          ant_prm[ANT_NUM].Trx[ns]  = 75.0;
          ant_prm[ANT_NUM].Tsky[ns] =  7.0;
          ant_prm[ANT_NUM].Tsys[ns] = 82.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == C_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  8.63;
          ant_prm[ANT_NUM].Ae[ns]   =  0.40;
          ant_prm[ANT_NUM].Trx[ns]  = 94.0;
          ant_prm[ANT_NUM].Tsky[ns] =  7.0;
          ant_prm[ANT_NUM].Tsys[ns] =101.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == X_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  9.30;
          ant_prm[ANT_NUM].Ae[ns]   =  0.60;
          ant_prm[ANT_NUM].Trx[ns]  = 90.0;
          ant_prm[ANT_NUM].Tsky[ns] =  7.0;
          ant_prm[ANT_NUM].Tsys[ns] = 97.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == KA_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  9.30;
          ant_prm[ANT_NUM].Ae[ns]   =  0.59;
          ant_prm[ANT_NUM].Trx[ns]  = 52.0;
          ant_prm[ANT_NUM].Tsky[ns] =  7.0;
          ant_prm[ANT_NUM].Tsys[ns] = 59.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == Q_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  9.30;
          ant_prm[ANT_NUM].Ae[ns]   =  0.21;
          ant_prm[ANT_NUM].Trx[ns]  = 65.0;
          ant_prm[ANT_NUM].Tsky[ns] =  7.0;
          ant_prm[ANT_NUM].Tsys[ns] = 72.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else {
          ant_prm[ANT_NUM].Dm[ns]   =  1.00;
          ant_prm[ANT_NUM].Ae[ns]   =  1.00;
          ant_prm[ANT_NUM].Trx[ns]  =  0.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns]   =  1.00;
          ant_prm[ANT_NUM].FLAG[ns] = OFF;
        }
      }
********/
      for (ns=0; ns<SRC_NUM; ns++) {
        if (wave_id[ns] == L_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  8.63;
          ant_prm[ANT_NUM].Ae[ns]   =  0.40;
          ant_prm[ANT_NUM].Trx[ns]  = 75.0;
          ant_prm[ANT_NUM].Tsky[ns] =  7.0;
          ant_prm[ANT_NUM].Tsys[ns] = 82.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == C_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  8.63;
          ant_prm[ANT_NUM].Ae[ns]   =  0.40;
          ant_prm[ANT_NUM].Trx[ns]  = 94.0;
          ant_prm[ANT_NUM].Tsky[ns] =  7.0;
          ant_prm[ANT_NUM].Tsys[ns] =101.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == X_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  9.20;
          ant_prm[ANT_NUM].Ae[ns]   =  0.60;
          ant_prm[ANT_NUM].Trx[ns]  = 90.0;
          ant_prm[ANT_NUM].Tsky[ns] = 10.0;
          ant_prm[ANT_NUM].Tsys[ns] = 97.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == KA_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  9.20;
          ant_prm[ANT_NUM].Ae[ns]   =  0.59;
          ant_prm[ANT_NUM].Trx[ns]  = 52.0;
          ant_prm[ANT_NUM].Tsky[ns] = 15.0;
          ant_prm[ANT_NUM].Tsys[ns] = 59.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else if (wave_id[ns] == Q_BAND) {
          ant_prm[ANT_NUM].Dm[ns]   =  9.20;
          ant_prm[ANT_NUM].Ae[ns]   =  0.21;
          ant_prm[ANT_NUM].Trx[ns]  = 65.0;
          ant_prm[ANT_NUM].Tsky[ns] = 40.0;
          ant_prm[ANT_NUM].Tsys[ns] = 72.0;
          ant_prm[ANT_NUM].FLAG[ns] = ON;
        } else {
          ant_prm[ANT_NUM].Dm[ns]   =  1.00;
          ant_prm[ANT_NUM].Ae[ns]   =  1.00;
          ant_prm[ANT_NUM].Trx[ns]  =  0.0;
          ant_prm[ANT_NUM].Tsky[ns] =  0.0;
          ant_prm[ANT_NUM].Tsys[ns]   =  1.00;
          ant_prm[ANT_NUM].FLAG[ns] = OFF;
        }
      }
      ANT_NUM++;
    }
  }

  return (ANT_NUM);
}
