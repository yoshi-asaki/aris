#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <aris.h>


void source_model2(float *dist, int dmax, float res,
                   int   n_source,
                   float *pamp, float  *tamp,
                   float *radius_maj, float *radius_min, float *pa,
                   float *xoff, float *yoff, char  *s_type)
{
  int    i, j, dref, N;
  int    ix0, ix1, iy0, iy1;
  float  amp, x, y, ar, ai;
  float  r_factor, r, phs, u, v;
  float  RA2, RB2, ln2;

/*
--------------------
*/

  dref = dmax / 2;

  for (N=0; N<n_source; N++) {
    amp = pamp[N];
    if (pamp[N] == 0.0) {
      amp = tamp[N];
    }
    if (radius_maj[N] == 0.0 || radius_min[N] == 0.0) {
      *(dist + dmax * (dref + (int)rint(xoff[N]/res))
                     + dref + (int)rint(yoff[N]/res)) += amp;
    } else {
      if (n_source > 5) {
        if (s_type[N] == 'G') {
          r_factor = 8.0;
        } else if (s_type[N] == 'S') {
          r_factor = 2.0;
        }

        r = r_factor * radius_maj[N];
        ix0 = dref + (int)rint((xoff[N] - r) / res);
        if (ix0 < 0) {
          ix0 = 0;
        }
        ix1 = dref + (int)rint((xoff[N] + r) / res);
        if (ix1 > dmax) {
          ix1 = dmax;
        }
        iy0 = dref + (int)rint((yoff[N] - r) / res);
        if (iy0 < 0) {
          iy0 = 0;
        }
        iy1 = dref + (int)rint((yoff[N] + r) / res);
        if (iy1 > dmax) {
          iy1 = dmax;
        }
      } else {
        ix0 = 0;
        ix1 = dmax;
        iy0 = 0;
        iy1 = dmax;
      }

      phs = -(0.5*dpi - pa[N]);
      ar = cos(phs);
      ai = sin(phs);
      RA2 = radius_maj[N] * radius_maj[N];
      RB2 = radius_min[N] * radius_min[N];
      ln2 = log(2.0);

      amp = pamp[N];
      if (pamp[N] == 0.0) {
        if (s_type[N] == 'G') {
          amp = tamp[N] * ln2 / dpi / radius_maj[N] / radius_min[N];
        } else if (s_type[N] == 'S') {
          amp = tamp[N] * 2.0 / dpi / radius_maj[N] / radius_min[N];
        }
      }

      for (i=ix0; i<ix1; i++) {
        for (j=iy0; j<iy1; j++) {
          u = res * (float)(i - dref) - xoff[N];
          v = res * (float)(j - dref) - yoff[N];

          x = ar * u - ai * v;
          y = ai * u + ar * v;

          if (s_type[N] == 'G') {
            *(dist + i*dmax + j) +=
                  amp * exp(-ln2 * (x*x/RA2 + y*y/RB2));
          } else if (s_type[N] == 'S') {
            if (x <= radius_maj[N] && y <= radius_min[N]) {
              *(dist + i*dmax + j) += amp;
            }
          }
        }
      }
    }
  }

  return;
}
