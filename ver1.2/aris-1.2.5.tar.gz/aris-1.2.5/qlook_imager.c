#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>


int qlook_imager(int ANT_NUM,
                 int BGN_ANT_I, int END_ANT_I, int BGN_ANT_J, int END_ANT_J,
                 int nobs, int nfrq, struct baseline_uvw *bluvw[],
                 struct fringe *frng[], float *fringe_weight[],
                 double *pix_uvl, double *wave_length, double *pix_mas)
{
  int    i, j, I, ns, iobs, ibase, iant, jant, ifrq;
  int    TSAMPLE[SRC_NUM_P1];
  float  *dist[SRC_NUM];
  char   *title[SRC_NUM];
  float  mapr[FLDMAX][FLDMAX], mapi[FLDMAX][FLDMAX];
  float  weight[FLDMAX][FLDMAX];
  float  pmin[SRC_NUM], pmax[SRC_NUM], noise[SRC_NUM];
  float  err_x[SRC_NUM], err_y[SRC_NUM];
  float  delta_x[SRC_NUM], delta_y[SRC_NUM];
  double ar[3], ai[3];
  float  s_x_cnt[2], s_y_cnt[2], s_x_w[2], s_y_w[2];


  TSAMPLE[0] = 0;
  TSAMPLE[1] = 0;
  TSAMPLE[2] = 0;

  for (iant=0; iant<ANT_NUM; iant++) {
    for (jant=iant+1; jant<ANT_NUM; jant++) {
      if (iant >= BGN_ANT_I && iant < END_ANT_I &&
          jant >= BGN_ANT_J && jant < END_ANT_J) {
        ibase = baseline_number(ANT_NUM, iant, jant);

        for (iobs=0; iobs<nobs; iobs++) {
          I = ibase * nobs + iobs;
          if (fringe_weight[0][I] > 0.0 && fringe_weight[2][I] > 0.0) {
            ar[0] = 0.0;
            ai[0] = 0.0;
            ar[2] = 0.0;
            ai[2] = 0.0;
            for (ifrq=0; ifrq<nfrq; ifrq++) {
              j = I * nfrq + ifrq;
              ar[0] += frng[0][j].rl;
              ai[0] += frng[0][j].im;
              ar[2] += frng[2][j].rl;
              ai[2] += frng[2][j].im;
            }
            ar[0] /= (double)nfrq;
            ai[0] /= (double)nfrq;
            ar[2] /= (double)nfrq;
            ai[2] /= (double)nfrq;

            if (bluvw[0][I].u <= 0.0) {
              bluvw[0][TSAMPLE[0]].u =  bluvw[0][I].u; 
              bluvw[0][TSAMPLE[0]].v =  bluvw[0][I].v; 
              bluvw[0][TSAMPLE[0]].w =  bluvw[0][I].w; 
              frng[0][TSAMPLE[0]].rl =  ar[0];
              frng[0][TSAMPLE[0]].im =  ai[0];
              frng[2][TSAMPLE[0]].rl =  ar[2];
              frng[2][TSAMPLE[0]].im =  ai[2];
            } else {
              bluvw[0][TSAMPLE[0]].u = -bluvw[0][I].u; 
              bluvw[0][TSAMPLE[0]].v = -bluvw[0][I].v; 
              bluvw[0][TSAMPLE[0]].w = -bluvw[0][I].w; 
              frng[0][TSAMPLE[0]].rl =  ar[0];
              frng[0][TSAMPLE[0]].im = -ai[0];
              frng[2][TSAMPLE[2]].rl =  ar[2];
              frng[2][TSAMPLE[2]].im = -ai[2];
            }
            TSAMPLE[0]++;
            TSAMPLE[2]++;
          }

          if (fringe_weight[1][I] > 0.0) {
            ar[1] = 0.0;
            ai[1] = 0.0;
            for (ifrq=0; ifrq<nfrq; ifrq++) {
              j = I * nfrq + ifrq;
              ar[1] += frng[0][j].rl;
              ai[1] += frng[0][j].im;
            }
            ar[1] /= (double)nfrq;
            ai[1] /= (double)nfrq;

            if (bluvw[1][I].u <= 0.0) {
              bluvw[1][TSAMPLE[1]].u =  bluvw[1][I].u; 
              bluvw[1][TSAMPLE[1]].v =  bluvw[1][I].v; 
              bluvw[1][TSAMPLE[1]].w =  bluvw[1][I].w; 
              frng[1][TSAMPLE[1]].rl =  ar[1];
              frng[1][TSAMPLE[1]].im =  ai[1];
            } else {
              bluvw[1][TSAMPLE[1]].u = -bluvw[1][I].u; 
              bluvw[1][TSAMPLE[1]].v = -bluvw[1][I].v; 
              bluvw[1][TSAMPLE[1]].w = -bluvw[1][I].w; 
              frng[1][TSAMPLE[1]].rl =  ar[1];
              frng[1][TSAMPLE[1]].im = -ai[1];
            }
            TSAMPLE[1]++;
          }
        }
      }
    }
  }

  for (ns=0; ns<SRC_NUM; ns++) {
    if ((dist[ns]=(float *)calloc(LFDMAX*LFDMAX, sizeof(float))) == NULL) {
      printf("ERROR: qlook_iamger: calloc error.\n");
      exit (1);
    }
  }
  imager(TSAMPLE[0], bluvw[0], pix_uvl[0], FLDMAX,
         frng[0], mapr[0], mapi[0], weight[0], dist[0], LFDMAX);
  imager(TSAMPLE[2], bluvw[0], pix_uvl[0], FLDMAX,
         frng[2], mapr[0], mapi[0], weight[0], dist[1], LFDMAX);
  for (ns=0; ns<SRC_NUM; ns++) {
    if ((title[ns]=(char *)calloc(20, sizeof(char))) == NULL) {
      printf("ERROR: qlook_iamger: calloc error.\n");
      exit (1);
    }
  }
  sprintf(title[0], "Target (before P-R)\0");
  sprintf(title[1], "Target (after P-R)\0");
  brightness_disp(2, LFDMAX, LFDMAX/2+1, LFDMAX/2+1,
                  pix_mas[0], pix_mas[0],
                  100.0*pix_mas[0],   100.0*pix_mas[0], 0.0, 0.0,
                  OFF, s_x_cnt, s_y_cnt, s_x_w, s_y_w,
                  dist,
                  "[mas]",  title,  ON, ON, ON,  ON, ON, 64, "clr",
                  pmin, pmax, noise, err_x, err_y, delta_x, delta_y);
  for (ns=0; ns<SRC_NUM; ns++) {
    free (dist[ns]);
    free (title[ns]);
  }

  return 1;
}
