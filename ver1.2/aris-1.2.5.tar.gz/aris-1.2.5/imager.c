#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>


void  imager(int  TSAMPLE,   struct baseline_uvw *bluvw,
             double  pix_uvl,
             int     fmax,   struct fringe *frng,
             float   *mapr,  float  *mapi,  float   *weight,
             float   *dist,  int    dmax)
{
  int    i, j, I, J, CNT;
  int    pnt_ad, PNT_AD;
  int    nuvmax, nuvtmp;
  int    IFREF, JFREF;
  int    IDREF, JDREF;
  int    LEN;
  int    *USED;
  int    *nx, *ny;
  float  taper;
  double w;
  double MAPR, MAPI, WGHT;

/*
-------------------
*/

  IFREF = fmax / 2;
  JFREF = fmax / 2;
  IDREF = dmax / 2;
  JDREF = dmax / 2;

  USED  = (int    *)calloc(TSAMPLE,   sizeof(int)  );
  nx    = (int    *)calloc(TSAMPLE,   sizeof(int)  );
  ny    = (int    *)calloc(TSAMPLE,   sizeof(int)  );

/*
---------------------------------------
*/

  nuvmax = 0;
  for (i=0; i<TSAMPLE; i++) {
    nx[i] = (int)rint(bluvw[i].u / pix_uvl);
    ny[i] = (int)rint(bluvw[i].v / pix_uvl);
    nuvtmp = nx[i]*nx[i] + ny[i]+ny[i];
    if (nuvtmp > nuvmax) {
      nuvmax = nuvtmp;
    }
  }
  I = fmax * fmax;
  for (i=0; i<I; i++) {
    *(mapr   + i) = 0.0;
    *(mapi   + i) = 0.0;
    *(weight + i) = 0.0;
  }

  for (i=0; i<TSAMPLE; i++) {
    USED[i] = OFF;
  }

  for (i=0; i<TSAMPLE; i++) {
    if (USED[i] == OFF) {
      MAPR = frng[i].rl;
      MAPI = frng[i].im;
      WGHT = frng[i].wt;
      CNT = 1;
      for (j=i+1; j<TSAMPLE; j++) {
        if (USED[j] == OFF) {
          if (nx[j] ==  nx[i] && ny[j] ==  ny[i]) {
            MAPR += frng[j].rl;
            MAPI += frng[j].im;
            WGHT += frng[j].wt;
            USED[j] = ON;
            CNT++;
/****
          } else if (nx[j] == -nx[i] && ny[j] == -ny[i]) {
            MAPR += frng[j].rl;
            MAPI -= frng[j].im;
            WGHT += frng[j].wt;
            USED[j] = ON;
            CNT++;
****/
          }
        }
      }
      I = nx[i] + IFREF;
      PNT_AD = I*fmax + ny[i]+JFREF;
      *(mapr   + PNT_AD) = MAPR / (float)CNT;
      *(mapi   + PNT_AD) = MAPI / (float)CNT;
/****
      *(weight + PNT_AD) = 1.0;
      *(weight + PNT_AD) = WGHT / (float)CNT;
****/
      *(weight + PNT_AD) = 1.0;
    }
  }
  free (nx);
  free (ny);

/*
---------------------------------------
*/

  LEN = sizeof(float) * (JFREF - 1);
  for (i=IFREF+1; i<fmax; i++) {
    memcpy(mapr + i*fmax+fmax-1,       mapr  +(fmax-i)*fmax+1,       LEN);
    memcpy(mapi + i*fmax+fmax-1,       mapi  +(fmax-i)*fmax+1,       LEN);
    memcpy(mapr + i*fmax+fmax-JFREF-1, mapr  +(fmax-i)*fmax+JFREF+1, LEN);
    memcpy(mapi + i*fmax+fmax-JFREF-1, mapi  +(fmax-i)*fmax+JFREF+1, LEN);
    for (j=JFREF+1; j<fmax; j++) {
      *(mapi + i*fmax + fmax-j) *= -1.0;
    }
    memcpy(weight+i*fmax+fmax-1,       weight+(fmax-i)*fmax+1,       LEN);
    memcpy(weight+i*fmax+fmax-JFREF-1, weight+(fmax-i)*fmax+JFREF+1, LEN);
  }

/****
  for (i=0; i<fmax; i++) {
    for (j=0; j<fmax; j++) {
      taper = (float)((i-IFREF)*(i-IFREF) + (j-JFREF)*(j-JFREF))
                    / 2.0 / 0.42 / (float)nuvmax;
      taper = exp(taper);
      pnt_ad = i * fmax + j;
      *(mapr + pnt_ad) *= taper;
      *(mapi + pnt_ad) *= taper;
    }
  }
****/

/*
---------------------------------------
*/

  for (i=0; i<IFREF; i++) {
    I = fmax - IFREF + i;
    for (j=0; j<JFREF; j++) {
      pnt_ad = i*fmax + j;
      PNT_AD = I*fmax + fmax - JFREF + j;

      w = *(mapr + pnt_ad);
      *(mapr + pnt_ad) = *(mapr + PNT_AD);
      *(mapr + PNT_AD) = w;

      w = *(mapi + pnt_ad);
      *(mapi + pnt_ad) = *(mapi + PNT_AD);
      *(mapi + PNT_AD) = w;

      w = *(weight + pnt_ad);
      *(weight + pnt_ad) = *(weight + PNT_AD);
      *(weight + PNT_AD) = w;
    }
  }

  for (i=0; i<IFREF; i++) {
    I = fmax - IFREF + i;
    for (j=JFREF; j<fmax; j++) {
      pnt_ad = i*fmax + j;
      PNT_AD = I*fmax + j - JFREF;

      w = *(mapr + pnt_ad);
      *(mapr + pnt_ad) = *(mapr + PNT_AD);
      *(mapr + PNT_AD) = w;

      w = *(mapi + pnt_ad);
      *(mapi + pnt_ad) = *(mapi + PNT_AD);
      *(mapi + PNT_AD) = w;

      w = *(weight + pnt_ad);
      *(weight + pnt_ad) = *(weight + PNT_AD);
      *(weight + PNT_AD) = w;
    }
  }

/*
---------------------------------------
*/

/****
  w = 0.0;
  for (i=0; i<fmax; i++) {
    w += weight[i];
  }
  w /= (float)fmax;
  for (i=0; i<fmax; i++) {
    weight[i] = w;
  }
  wfft2d(mapr, mapi, weight, fmax, 1);
****/

  for (i=0; i<fmax; i++) {
    w = 0.0;
    for (j=0; j<fmax; j++) {
      w += *(weight + i * fmax + j);
    }
    for (j=0; j<fmax; j++) {
      if (w != 0.0) {
        *(weight + i * fmax + j) = 1.0 / w;
      }  else {
        *(weight + i * fmax + j) = 0.0;
      }
    }
  }
  wfft2d(mapr, mapi, weight, fmax, 1);

/*
---------------------------------------
*/

  LEN = sizeof(float) * dmax;
  for (i=0; i<dmax; i++) {
    I = IFREF - IDREF + i;
    memcpy(dist + i*dmax, mapr + I*fmax + JFREF - JDREF, LEN);
  }

  free (USED);
}
