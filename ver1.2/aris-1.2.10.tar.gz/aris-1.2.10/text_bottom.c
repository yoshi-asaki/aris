#include <stdio.h>
#include <math.h>
#include <aris.h>

float  text_bottom(float ymin, float ymax)
{
  return (0.60 * ymin + 0.40 * ymax);
}
