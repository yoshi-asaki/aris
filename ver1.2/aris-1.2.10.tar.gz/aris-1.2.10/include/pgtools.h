#include <stdio.h>
#include <stdlib.h>
#include <cpgplot.h>


int   pgarea(
         float        , float        , float       *, float       *);
int   pgregion(
         float        , float        , float       *, float       *);
