#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <aris.h>


int   ccm_read(char *cc_file, float *dist, int dsize, double pix_mas)
{
  FILE   *ccfp;
  double dx, dy, delta_x, delta_y;
  double a00, a01, a10, a11;
  double dist_flux;
  double cflux, lfdum;
  int    ix, iy, idum;
  int    ncnt;
  char   string[500];

/*
------------------------------------
*/

  if ((ccfp=fopen(cc_file, "r")) == NULL) {
    printf("ERROR: ccm_read: CC FILE does not exit.\n");
    return (NG);
  }

/*
--------
*/

  ncnt = 1;

  while (1) {
    if (fgets(string, sizeof(string), ccfp) == NULL) {
      break;
    }
    if (strncmp(string, "    Comp", 8) == 0) {
      break;
    }
  }
  if (fgets(string, sizeof(string), ccfp) == NULL) {
    printf("ERROR: CC_READ: Invalid input\n");
    fclose (ccfp);
    return (NG);
  }
  if (fgets(string, sizeof(string), ccfp) == NULL) {
    printf("ERROR: CC_READ: Invalid input\n");
    fclose (ccfp);
    return (NG);
  }

/*
--------
*/

  while (1) {
    if (fgets(string, sizeof(string), ccfp) == NULL) {
      break;
    }
    sscanf(string, "%d %lf %lf %lf %lf",
           &idum, &delta_x, &delta_y, &cflux, &lfdum);

    if (idum == ncnt) {
      delta_x /= 1000.0;
      delta_y /= 1000.0;
      ix = (int)(delta_x / pix_mas) + dsize / 2;
      iy = (int)(delta_y / pix_mas) + dsize / 2;

      if (ix >= 0 && ix < dsize &&
          iy >= 0 && iy < dsize && cflux >= 0.0) {
        dx = delta_x - (double)ix;
        dy = delta_y - (double)iy;

        a00 = sqrt(pow(      dx, 2.0) + pow(      dy, 2.0));
        a01 = sqrt(pow(1.0 - dx, 2.0) + pow(      dy, 2.0));
        a10 = sqrt(pow(      dx, 2.0) + pow(1.0 - dy, 2.0));
        a11 = sqrt(pow(1.0 - dx, 2.0) + pow(1.0 - dy, 2.0));

        dist_flux = cflux / (a00 + a01 + a10 + a11);
        dist[dsize *  ix      + iy     ] += a00 * dist_flux;
        dist[dsize * (ix+1)   + iy     ] += a01 * dist_flux;
        dist[dsize *  ix      + iy + 1 ] += a10 * dist_flux;
        dist[dsize * (ix+1)   + iy + 1 ] += a11 * dist_flux;

        ncnt++;

      } else {
        while (1) {
          if (fgets(string, sizeof(string), ccfp) == NULL) {
            break;
          }
          if (strncmp(string, "    Comp", 8) == 0) {
            break;
          }
        }
        if (fgets(string, sizeof(string), ccfp) == NULL) {
          break;
        }
        if (fgets(string, sizeof(string), ccfp) == NULL) {
          break;
        }
      }
    }
  }

  fclose (ccfp);

/*
--------
*/

  if (ncnt == 1) {
    printf("ERROR: ccm_read: NO CC component exists.\n");
    return (NG);
  }

  return (1);
}
