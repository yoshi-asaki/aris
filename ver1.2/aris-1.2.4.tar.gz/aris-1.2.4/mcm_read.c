#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <aris.h>


int  mcm_read(char *mcm_file, float *dist, int dmax, double pix_mas)
{
  int    n;
  char   string[500], comp;
  float  semi_maj, semi_min, pa;
  float  xoff,  yoff;
  float  pflux, tflux;
  FILE   *fp;

/*
-----------------------------------
*/

  if ((fp = fopen(mcm_file, "r")) == NULL) {
    printf("ERROR: visibility_calc: ASCII DATA FILE cannot be found.\n");
    return (NG);
  }
  while (1) {
    if (fgets(string, sizeof(string), fp) == NULL) {
      break;
    }
    if (string[0] != '#') {
      sscanf(string, "%f, %f, %f, %f, %f, %f, %f, %d",
             &pflux, &tflux, &semi_maj, &semi_min, &pa, &xoff, &yoff, &n);
      semi_maj *= 0.5;
      semi_min *= 0.5;
      pa *= (dpi / 180.0);
      if (n == 0) {
        comp = 'G';
      } else {
        comp = 'S';
      }
      source_model2(dist, dmax, pix_mas, 1, &pflux, &tflux,
                    &semi_maj, &semi_min, &pa, &xoff, &yoff, &comp);
    }
  }
  fclose (fp);

  return 1;
}
