double  mean_obliquity_of_the_ecliptic
        (
          int       *,    double
        );
void    nutation_calc
        (
          int       *,    double     ,    double    *,    double    *,    
          double    *
        );
