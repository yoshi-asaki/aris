#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <mathtools.h>
#include <astrotools.h>
#include <aris.h>


int  weight_flag_chk(float src_flag, float *weight, float flag)
{
  static int    i, N, nflag, npart, nchk;
  static float  wt;

  nflag = (int)fabs(flag);
  N = 32;
  for (i=5; i>=0 ; i--) {
    npart = nflag / N;
    if (npart == 1) {
      break;
    } else {
      nflag %= N;
      N /= 2;
    }
  }
  nchk = i;
/****
  printf("aaaaaaaaaa   %f  %f  %f  %d\n", src_flag, *weight, flag, nchk);
****/

  wt = *weight - src_flag;
  if (wt < 0.0) {
    nflag = (int)fabs(wt);
    N = 32;
    for (i=5; i>=nchk; i--) {
      npart = nflag / N;
      nflag %= N;
      N /= 2;
    }
    if (npart == 1) {
      return ( ON);
    }
  }

  return (OFF);
}
