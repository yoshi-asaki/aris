#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <aris.h>


int  visibility_calc(float *mapr, float *mapi, int fmax,
                     double *pix_mas, double *pix_uvl,
                     struct source_parameter src,
                     char *ch_cc_file, 
                     char *ch_bhs_file, 
                     char *ch_ascii_file, 
                     struct comment_param *cmnt,
                     char comment[][NCOMLEN], 
                     int  TV_SWT, int pgid)
{
  static int    i, j;
  static float  *dist;
  static int    dmax;
  static float  radius[10];
  static float  xoff[10], yoff[10];
  static double flux[10];
  static char   string[100];
  static double theta;
  static float  pmin[2], pmax[2], noise[2];
  static float  err_x[2], err_y[2], delta_x[2], delta_y[2];
  static float  s_x_cnt[2], s_y_cnt[2], s_x_w[2], s_y_w[2];
  static float  t_flux;
  static float  *DIST[2];
  static char   *title[2];

  static FILE   *fp;
  static int    itmp;
  static float  ftmp;

/*
-----------------------------------
*/

  dmax = fmax / 4;
  if ((dist = (float *)calloc(dmax*dmax, sizeof(float))) == NULL) {
    printf("ERROR: visibility_calc: calloc failure in visibility_calc.\n");
    return (NG);
  }

/*
-----------------------------------
*/

  if (src.morphology == SRC_POINT) {
    dist[dmax/2*dmax + dmax/2] = (float)src.flux;
    for (i=0; i<fmax; i++) {
      for (j=0; j<fmax; j++) {
        *(mapr + fmax*i + j) = (float)src.flux;
        *(mapi + fmax*i + j) = (float)0.0;
      }
    }

/*
-----------------------------------
*/

  } else {
    if (src.morphology == SRC_DISK_JETCJET) {
      theta = (45.0 - 90.0) / 180.0 * dpi;
      jet_cjet  (dist, dmax, theta, *pix_mas, src.flux);
      ADAF_disk (dist, dmax, theta, *pix_mas, src.flux);
    } else if (src.morphology == SRC_DISK_VSOP2JET) {
      theta = (45.0 - 90.0) / 180.0 * dpi;
      VSOP2_logo(dist, dmax, theta, *pix_mas, src.flux);
      ADAF_disk (dist, dmax, theta, *pix_mas, src.flux);
    } else if (src.morphology == SRC_CC_COMP) {
      if (cc_read(ch_cc_file, dist, dmax, *pix_mas) == NG) {
        printf("ERROR: visibility_calc: cc_read returned ERROR.\n");
        free (dist);
        return (NG);
      }
    } else if (src.morphology == SRC_TWO_COMP) {
      flux[0] = 0.5;
      radius[0] = 0.02;
      xoff[0] = 0.0;
      yoff[0] = 0.0;
      string[0] = 'G';

      flux[1] = 0.5;
      radius[1] = 0.02;
      xoff[1] = 0.2;
      yoff[1] = 0.0;
      string[1] = 'G';

      source_model(dist, dmax, *pix_mas, 2, flux, radius, xoff, yoff, string);

    } else if (src.morphology == SRC_BHS_MOD) {
      if (bhs_model(dist, dmax, pix_mas, pix_uvl, ch_bhs_file) == NG) {
        printf("ERROR: visibility_calc: cc_read returned ERROR.\n");
        free (dist);
        return (NG);
      }
    } else if (src.morphology == SRC_ASCII_DATA) {
      if ((fp = fopen(ch_ascii_file, "r")) == NULL) {
        printf("ERROR: visibility_calc: ASCII DATA FILE cannot be found.\n");
        return (NG);
      }
      while (1) {
        if (fgets(string, sizeof(string), fp) == NULL) {
          break;
        }
        sscanf(string, "%d,%f", &itmp, &ftmp);
        dist[itmp] = ftmp;
      }
      fclose (fp);
    }

    if (src.morphology != SRC_CC_COMP &&
        src.morphology != SRC_BHS_MOD &&
        src.morphology != SRC_POINT) {
      t_flux = 0.0;
      for (i=0; i<dmax*dmax; i++) {
        t_flux += dist[i];
      }
      t_flux /= src.flux;
      for (i=0; i<dmax*dmax; i++) {
        dist[i] /= t_flux;
      }
    }

    get_vis(mapr, mapi, fmax, dist, dmax);
  }

  if (pgid != -1) {
    sprintf(string, "Source Image\0");
    DIST[0]  = dist;
    title[0] = string;
    s_x_cnt[0] = 0.0;
    s_y_cnt[0] = 0.0;
    s_x_w[0]   = 0.0;
    s_y_w[0]   = 0.0;
    cpgslct(pgid);
    cpgsci(0);
    cpgrect(0.0, 1.0, 0.24, 1.0);
    brightness_disp(1, dmax, dmax/2+1, dmax/2+1, *pix_mas, *pix_mas,
                    1.0 * *pix_mas *(float)dmax,
                    1.0 * *pix_mas *(float)dmax, 0.0, 0.0,
                    OFF, s_x_cnt, s_y_cnt, s_x_w, s_y_w, DIST,
                    "[mas]", title, TV_SWT, ON, OFF, OFF, ON, 128, "clr",
                    pmin, pmax, noise, err_x, err_y, delta_x, delta_y);

    sprintf(string, "Maximum Peak: %7.2E\n", pmax[0]);
    if (TV_SWT == ON) {
      cpgsvp(0.0, 1.0, 0.0, 1.0);
      cpgswin(0.0, 1.0, 0.0, 1.0);
      cpgsch(0.65);
      comment_disp(cmnt, comment, string, ON);
    } else {
      printf("%s", string);
    }
    sprintf(string,  "(X, Y)      : (%f, %f)\n", delta_x[0], delta_y[0]);
    if (TV_SWT == ON) {
      comment_disp(cmnt, comment, string, ON);
    } else {
      printf("%s", string);
    }
  }

/*
----------
*/

/********
  if (pgid != -1) {
    DIST[0] = mapr;
    DIST[1] = mapi;
    title[0] = string;
    title[1] = string;
    s_x_cnt[0] = 0.0;
    s_y_cnt[0] = 0.0;
    s_x_w[0]   = 0.0;
    s_y_w[0]   = 0.0;
    s_x_cnt[1] = 0.0;
    s_y_cnt[1] = 0.0;
    s_x_w[1]   = 0.0;
    s_y_w[1]   = 0.0;
    cpgslct(pgid);
    brightness_disp(2, fmax, fmax/2+1, fmax/2+1,
                    1.0, 1.0, (float)fmax, (float)fmax, 0.0, 0.0,
                    OFF, s_x_cnt, s_y_cnt, s_x_w, s_y_w, DIST,
                    "uv", title, TV_SWT, ON, OFF, ON, OFF, 64, "clr",
                    pmin, pmax, noise, err_x, err_y, delta_x, delta_y);
  }
********/

/*
----------
*/

  free (dist);
  return 1;
}
