#include <stdio.h>
#include <math.h>
#include <aris.h>

int  az_adjustment(int GRT_NUM, int nobs, struct st_observable *int_obs[],
                   struct antenna_parameter *ant_prm)
{
  static int    iant, iobs, I;
  static double az_diff;

  for (iant=0; iant<GRT_NUM; iant++) {
    I = iant * nobs;
    for (iobs=0; iobs<nobs; iobs++) {
      if (int_obs[0][I].el >= ant_prm[iant].ELLIM &&
          int_obs[1][I].el >= ant_prm[iant].ELLIM) {
        break;
      }
      I++;
    }

    I = iant * nobs + iobs;
    for (++iobs; iobs<nobs; iobs++) {
      az_diff = diff(int_obs[0][I].az, int_obs[1][I].az);
      if (fabs(az_diff) > dpi) {
        int_obs[1][I].az += 2.0 * dpi * (az_diff / fabs(az_diff));
      }
      I++;
    }
  }

  return 1;
}
