#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <mathtools.h>
#include <cpgplot.h>
#include <astrotools.h>
#include <aris.h>


void comment_init(struct comment_param  *cmnt, char comment[][NCOMLEN],
                  int TVSWT)
{
  static int    i, j;

  for (i=0; i<cmnt->ncol; i++) {
    for (j=0; j<NCOMLEN; j++) {
      comment[i][j] = 0;
    }
  }
  if (TVSWT == ON) {
    cpgsci(4);
    cpgrect(cmnt->xmin, cmnt->xmax, cmnt->ymin, cmnt->ymax);
    cpgsci(1);
  }
}
